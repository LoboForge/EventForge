"""Native Wan graph parameter extraction."""

from loboforge_worker.inference.wan.graph import extract_native_wan_params, normalize_wan_frames


def test_normalize_wan_frames_4n_plus_1():
    assert normalize_wan_frames(81) == 81
    assert normalize_wan_frames(82) == 81
    assert normalize_wan_frames(145) == 145


def test_extract_wan2_i2v_template_params():
    graph = {
        "93": {"class_type": "CLIPTextEncode", "inputs": {"text": "a cat on a boat"}},
        "89": {"class_type": "CLIPTextEncode", "inputs": {"text": "blurry"}},
        "98": {
            "class_type": "WanImageToVideo",
            "inputs": {"width": 512, "height": 768, "length": 145},
        },
        "86": {
            "class_type": "KSamplerAdvanced",
            "inputs": {"steps": 4, "cfg": 1.4, "noise_seed": 99},
        },
        "94": {"class_type": "CreateVideo", "inputs": {"fps": 16}},
    }
    p = extract_native_wan_params(graph)
    assert p["prompt"] == "a cat on a boat"
    assert p["negative_prompt"] == "blurry"
    assert p["width"] == 512
    assert p["height"] == 768
    assert p["num_frames"] == 145
    assert p["sampling_steps"] == 4
    assert p["seed"] == 99
    assert p["frame_rate"] == 16.0
