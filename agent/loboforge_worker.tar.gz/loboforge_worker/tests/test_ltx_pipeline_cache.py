"""Warm LTX pipeline reuse between native jobs."""

from __future__ import annotations

import sys
from types import ModuleType
from unittest.mock import patch

from loboforge_worker.inference.ltx import runner


def _layout() -> dict:
    return {
        "checkpoint": "/models/ltx-2.3-22b-dev-fp8.safetensors",
        "gemma_root": "/models/gemma",
        "spatial_upsampler": "/models/spatial.safetensors",
        "distilled_lora": "/models/distilled_lora.safetensors",
        "model_root": "/models",
    }


def test_pipeline_cache_key_changes_with_gemma_repo() -> None:
    layout_a = {**_layout(), "gemma_repo": "mlabonne/gemma-3-12b-it-qat-abliterated"}
    layout_b = {**_layout(), "gemma_repo": "google/gemma-3-12b-it-qat-q4_0-unquantized"}
    a = runner._pipeline_cache_key(
        layout_a,
        pipeline_kind=runner.PIPELINE_DISTILLED,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[],
    )
    b = runner._pipeline_cache_key(
        layout_b,
        pipeline_kind=runner.PIPELINE_DISTILLED,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[],
    )
    assert a != b


def test_pipeline_cache_key_changes_with_user_lora() -> None:
    base = runner._pipeline_cache_key(
        _layout(),
        pipeline_kind=runner.PIPELINE_DISTILLED,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[],
    )
    with_lora = runner._pipeline_cache_key(
        _layout(),
        pipeline_kind=runner.PIPELINE_DISTILLED,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[{"path": "/models/x.safetensors", "strength": 0.5, "name": "x"}],
    )
    assert base != with_lora


def test_pipeline_cache_key_differs_by_kind() -> None:
    distilled = runner._pipeline_cache_key(
        _layout(),
        pipeline_kind=runner.PIPELINE_DISTILLED,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[],
    )
    keyframe = runner._pipeline_cache_key(
        _layout(),
        pipeline_kind=runner.PIPELINE_KEYFRAME,
        checkpoint="/models/ckpt.safetensors",
        offload=None,
        quantization=None,
        user_loras=[],
    )
    assert distilled != keyframe


def test_is_keyframe_interpolation_requires_ff_and_lf() -> None:
    assert runner._is_keyframe_interpolation([("/ff.png", 0), ("/lf.png", -1)])
    assert not runner._is_keyframe_interpolation([("/ff.png", 0)])
    assert not runner._is_keyframe_interpolation([("/ff.png", 0), ("/mid.png", 60)])


def test_get_or_create_distilled_pipeline_reuses_same_instance() -> None:
    runner.clear_native_ltx_pipeline_cache()
    created: list[dict] = []

    fake_mod = ModuleType("ltx_pipelines.distilled")

    class FakePipeline:
        def __init__(self, **kwargs):
            created.append(kwargs)

    fake_mod.DistilledPipeline = FakePipeline
    sys.modules["ltx_pipelines"] = ModuleType("ltx_pipelines")
    sys.modules["ltx_pipelines.distilled"] = fake_mod

    try:
        with patch.object(runner, "_user_lora_ops", return_value=([], [])), patch.object(
            runner, "_distilled_lora_ops", return_value=[]
        ):
            p1 = runner._get_or_create_pipeline(
                _layout(),
                {},
                pipeline_kind=runner.PIPELINE_DISTILLED,
                checkpoint=str(_layout()["checkpoint"]),
                offload=None,
                quantization=None,
            )
            p2 = runner._get_or_create_pipeline(
                _layout(),
                {},
                pipeline_kind=runner.PIPELINE_DISTILLED,
                checkpoint=str(_layout()["checkpoint"]),
                offload=None,
                quantization=None,
            )
    finally:
        sys.modules.pop("ltx_pipelines.distilled", None)
        sys.modules.pop("ltx_pipelines", None)

    assert len(created) == 1
    assert p1 is p2
