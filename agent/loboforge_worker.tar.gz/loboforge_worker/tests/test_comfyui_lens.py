from loboforge_worker.provision.comfyui import mode_needs_lens


def test_mode_needs_lens():
    assert mode_needs_lens("image")
    assert mode_needs_lens("all")
    assert mode_needs_lens("both")
    assert mode_needs_lens("IMAGE")
    assert not mode_needs_lens("video")
    assert not mode_needs_lens("music")
