import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_run_subcommand_accepts_comfyui_token():
    proc = subprocess.run(
        [sys.executable, "-m", "loboforge_worker", "run", "--help"],
        capture_output=True,
        text=True,
        cwd=ROOT,
        check=False,
    )
    assert proc.returncode == 0
    assert "--comfyui-token" in proc.stdout


def test_run_forwards_comfyui_token_to_agent(monkeypatch):
    captured: list[list[str]] = []

    class FakeAgent:
        @staticmethod
        def main() -> None:
            captured.append(list(sys.argv))

    monkeypatch.setitem(sys.modules, "loboforge_agent", FakeAgent)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "loboforge_worker",
            "run",
            "--secret",
            "s",
            "--server",
            "wss://example.com",
            "--comfyui-token",
            "tok123",
        ],
    )
    from loboforge_worker.__main__ import main

    main()
    assert "--comfyui-token" in captured[0]
    assert "tok123" in captured[0]
