"""Native LTX checkpoint selection — distilled-1.1 only on fleet."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from loboforge_worker.inference.ltx.paths import (
    BF16_CHECKPOINT_REL,
    DISTILLED_CHECKPOINT_REL,
    FP8_CHECKPOINT_REL,
    resolve_native_checkpoint,
    use_distilled_checkpoint,
)


def test_distilled_is_default_checkpoint(tmp_path: Path) -> None:
    rel, _min_b, precision = resolve_native_checkpoint(tmp_path)
    assert use_distilled_checkpoint()
    assert rel == DISTILLED_CHECKPOINT_REL
    assert precision == "distilled"


def test_dev_variant_can_select_bf16_on_ampere(tmp_path: Path) -> None:
    with patch.dict("os.environ", {"LOBO_LTX_VARIANT": "dev"}):
        with patch("loboforge_worker.inference.ltx.paths.native_ltx_fp8_kernels_supported", return_value=False):
            rel, _min_b, precision = resolve_native_checkpoint(tmp_path)
    assert rel == BF16_CHECKPOINT_REL
    assert precision == "bf16"


def test_dev_variant_prefers_fp8_on_ada(tmp_path: Path) -> None:
    with patch.dict("os.environ", {"LOBO_LTX_VARIANT": "dev"}):
        with patch("loboforge_worker.inference.ltx.paths.native_ltx_fp8_kernels_supported", return_value=True):
            rel, _min_b, precision = resolve_native_checkpoint(tmp_path)
    assert rel == FP8_CHECKPOINT_REL
    assert precision == "fp8"
