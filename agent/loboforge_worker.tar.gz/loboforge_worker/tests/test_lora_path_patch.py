"""Comfy lora_name normalization (loras/ API prefix → bare filename)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import loboforge_agent as agent


def test_patch_graph_strips_loras_prefix_for_comfy():
    graph = {
        "2100": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {"lora_name": "loras/wan2.2-i2v-low-sex-smashcut-v1.0.safetensors"},
        },
    }
    models = {
        "loras": [
            "wan2.2-i2v-low-sex-smashcut-v1.0.safetensors",
            "other.safetensors",
        ],
    }
    agent.patch_graph_model_names(graph, models)
    assert graph["2100"]["inputs"]["lora_name"] == "wan2.2-i2v-low-sex-smashcut-v1.0.safetensors"


def test_patch_graph_keeps_subfolder_lora_paths():
    graph = {
        "1": {
            "class_type": "LoraLoader",
            "inputs": {"lora_name": "F2Klein/flux-klein.safetensors"},
        },
    }
    models = {"loras": ["F2Klein/flux-klein.safetensors"]}
    agent.patch_graph_model_names(graph, models)
    assert graph["1"]["inputs"]["lora_name"] == "F2Klein/flux-klein.safetensors"
