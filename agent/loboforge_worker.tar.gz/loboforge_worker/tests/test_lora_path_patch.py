"""Comfy lora_name normalization (loras/ API prefix → bare filename)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import loboforge_agent as agent


def test_patch_graph_strips_loras_prefix_for_comfy():
    graph = {
        "2100": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {"lora_name": "loras/wan2.2-i2v-low-sex-smashcut-v1.0.safetensors"},
        },
    }
    models = {
        "loras": [
            "wan2.2-i2v-low-sex-smashcut-v1.0.safetensors",
            "other.safetensors",
        ],
    }
    agent.patch_graph_model_names(graph, models)
    assert graph["2100"]["inputs"]["lora_name"] == "wan2.2-i2v-low-sex-smashcut-v1.0.safetensors"


def test_patch_graph_keeps_subfolder_lora_paths():
    graph = {
        "1": {
            "class_type": "LoraLoader",
            "inputs": {"lora_name": "F2Klein/flux-klein.safetensors"},
        },
    }
    models = {"loras": ["F2Klein/flux-klein.safetensors"]}
    agent.patch_graph_model_names(graph, models)
    assert graph["1"]["inputs"]["lora_name"] == "F2Klein/flux-klein.safetensors"


def test_wan_graph_with_lora_loader_is_not_ltx():
    """Wan i2v graphs use LoraLoaderModelOnly — must not hit LTX patch path."""
    graph = {
        "101": {"class_type": "LoraLoaderModelOnly", "inputs": {"lora_name": "x.safetensors"}},
        "98": {"class_type": "WanImageToVideo", "inputs": {}},
    }
    assert not agent.graph_has_ltx_nodes(graph)


def test_patch_graph_remaps_bare_unet_to_subfolder_inventory():
    """Comfy UNETLoader requires exact inventory paths, not bare basenames."""
    graph = {
        "200": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": "flux-2-klein-9b-fp8.safetensors", "weight_dtype": "default"},
        },
    }
    models = {"unets": ["F2Klein/flux-2-klein-9b-fp8.safetensors", "other.safetensors"]}
    agent.patch_graph_model_names(graph, models)
    assert graph["200"]["inputs"]["unet_name"] == "F2Klein/flux-2-klein-9b-fp8.safetensors"
