"""LoRA prefetch helpers (loboforge_agent_common)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import loboforge_agent_common as common


def test_extract_required_loras_from_lora_loader_nodes():
    payload = {
        "type": "assign_job",
        "graph": {
            "1": {
                "class_type": "LoraLoader",
                "inputs": {"lora_name": "loras/style.safetensors", "strength_model": 1.0},
            },
            "2": {
                "class_type": "LoraLoaderModelOnly",
                "inputs": {"lora_name": "wan/distilled-lora.safetensors"},
            },
            "3": {"class_type": "KSampler", "inputs": {}},
        },
    }
    names = common.extract_required_loras_from_assign(payload)
    assert len(names) == 2
    assert "loras/style.safetensors" in names
    assert "wan/distilled-lora.safetensors" in names


def test_extract_required_loras_dedupes_by_basename():
    payload = {
        "graph": {
            "1": {"class_type": "LoraLoader", "inputs": {"lora_name": "a/foo.safetensors"}},
            "2": {"class_type": "LoraLoader", "inputs": {"lora_name": "b/foo.safetensors"}},
        },
    }
    assert len(common.extract_required_loras_from_assign(payload)) == 1


def test_worker_has_lora_matches_known_and_models():
    state = {
        "known_loras": ["style.safetensors"],
        "models": {"loras": ["wan/distilled-lora.safetensors"]},
    }
    assert common.worker_has_lora(state, "loras/style.safetensors")
    assert common.worker_has_lora(state, "distilled-lora.safetensors")
    assert not common.worker_has_lora(state, "missing.safetensors")


def test_normalize_lora_basename_strips_path_and_strength_suffix():
    assert common._normalize_lora_basename("loras/foo.safetensors") == "foo.safetensors"
    assert common._normalize_lora_basename("foo.safetensors:0.8") == "foo.safetensors"
