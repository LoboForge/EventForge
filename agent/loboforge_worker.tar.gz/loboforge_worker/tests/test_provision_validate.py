import json
from pathlib import Path

from loboforge_worker.manifest import Manifest, load_local
from loboforge_worker.provision.validate import (
    PROVISION_STATE,
    clear_provision_state,
    is_provision_complete,
    missing_artifacts,
    provision_state_write,
)


def test_missing_artifacts_empty_when_files_present(tmp_path):
    manifest = load_local("ltx23_stack")
    assert manifest is not None
    for art in manifest.artifacts:
        dest = tmp_path / art.dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b"x" * max(art.min_bytes, 1024))
    assert missing_artifacts(tmp_path, [manifest]) == []


def test_is_provision_complete_false_when_marker_says_complete_but_files_missing(tmp_path, monkeypatch):
    manifest = load_local("ltx23_stack")
    assert manifest is not None
    state_path = tmp_path / ".loboforge-provision-done"
    monkeypatch.setattr(
        "loboforge_worker.provision.validate.PROVISION_STATE",
        state_path,
    )
    provision_state_write(
        mode="video",
        complete=True,
        downloaded=[],
        missing=[],
        errors=[],
    )
    assert not is_provision_complete(tmp_path, "video", "https://example.com", "secret")


def test_is_provision_complete_true_when_marker_and_files_ok(tmp_path, monkeypatch):
    manifest = load_local("ltx23_stack")
    assert manifest is not None
    for art in manifest.artifacts:
        dest = tmp_path / art.dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b"x" * max(art.min_bytes, 1024))
    state_path = tmp_path / ".loboforge-provision-done"
    monkeypatch.setattr(
        "loboforge_worker.provision.validate.PROVISION_STATE",
        state_path,
    )
    provision_state_write(
        mode="video",
        complete=True,
        downloaded=[a.dest for a in manifest.artifacts],
        missing=[],
        errors=[],
    )

    def fake_manifests(mode, base, secret):
        return [manifest]

    monkeypatch.setattr(
        "loboforge_worker.provision.validate.manifests_for_mode",
        fake_manifests,
    )
    assert is_provision_complete(tmp_path, "video", "https://example.com", "secret")


def test_clear_provision_state(tmp_path, monkeypatch):
    state_path = tmp_path / "done"
    monkeypatch.setattr("loboforge_worker.provision.validate.PROVISION_STATE", state_path)
    state_path.write_text("{}", encoding="utf-8")
    clear_provision_state()
    assert not state_path.exists()
