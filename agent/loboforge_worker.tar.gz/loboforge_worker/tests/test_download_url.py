"""Google Drive download helpers."""

from unittest.mock import patch

from loboforge_worker.provision.download_url import ensure_gdown, provision_python


def test_provision_python_prefers_venv():
    with patch.dict("os.environ", {"LOBO_PYTHON": ""}, clear=False):
        py = provision_python()
        assert py.endswith("python3") or "python" in py


def test_ensure_gdown_skips_when_import_works():
    with patch("loboforge_worker.provision.download_url.subprocess.run") as run:
        run.return_value.returncode = 0
        assert ensure_gdown("/venv/main/bin/python3") is True
        assert run.call_count == 1
