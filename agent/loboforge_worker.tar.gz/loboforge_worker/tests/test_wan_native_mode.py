"""Wan-native provision mode flags."""

from loboforge_worker.provision.disk import (
    mode_flags,
    should_sync_active_loras,
    should_sync_tool_loras,
)


def test_wan_native_mode_flags():
    img, vid, music = mode_flags("wan-native")
    assert img is False
    assert vid is True
    assert music is False


def test_wan_native_manifest_defaults_to_native_stack():
    from loboforge_worker.manifest import manifest_names_for_mode, load_local

    names = manifest_names_for_mode("wan-native")
    assert names == ["wan22_native_stack"]
    manifest = load_local(names[0])
    assert manifest is not None
    dests = {a.dest for a in manifest.artifacts}
    assert "loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors" in dests
    assert "loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors" in dests


def test_native_wan_syncs_loras():
    assert should_sync_tool_loras("wan-native") is True
    assert should_sync_active_loras("wan-native") is True
    assert should_sync_tool_loras("ltx-native") is False
    assert should_sync_tool_loras("video") is True
    assert should_sync_active_loras("video") is True


def test_lora_api_mode_passthrough():
    from loboforge_worker.provision.loras import lora_api_mode

    assert lora_api_mode("wan-native") == "video"
    assert lora_api_mode("video") == "video"
