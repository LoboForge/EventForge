"""Wan-native provision mode flags."""

from loboforge_worker.provision.disk import (
    mode_flags,
    should_sync_active_loras,
    should_sync_tool_loras,
)


def test_wan_native_mode_flags():
    img, vid, music = mode_flags("wan-native")
    assert img is False
    assert vid is True
    assert music is False


def test_wan_native_manifest_defaults_to_smoothmix():
    from loboforge_worker.manifest import manifest_names_for_mode, load_local

    names = manifest_names_for_mode("wan-native")
    assert names == ["wan_stack_smoothmix"]
    manifest = load_local(names[0])
    assert manifest is not None
    dests = {a.dest for a in manifest.artifacts}
    assert "diffusion_models/Wan2.2/smoothMixWan22I2VT2V_i2vHigh.safetensors" in dests
    assert "diffusion_models/Wan2.2/smoothMixWan22I2VT2V_i2vLow.safetensors" in dests


def test_dedicated_batch_skips_lora_prefetch():
    assert should_sync_tool_loras("wan-native") is False
    assert should_sync_active_loras("wan-native") is False
    assert should_sync_tool_loras("ltx-native") is False
    assert should_sync_tool_loras("video") is True
    assert should_sync_active_loras("video") is True


def test_lora_api_mode_passthrough():
    from loboforge_worker.provision.loras import lora_api_mode

    assert lora_api_mode("wan-native") == "wan-native"
    assert lora_api_mode("video") == "video"
