from unittest.mock import patch

import pytest

from loboforge_worker.provision.custom_nodes import ensure_power_lora_loader


@pytest.mark.asyncio
async def test_power_lora_restart_uses_hard_comfy_restart():
    calls: list[str] = []

    class Args:
        comfyui_http = "http://127.0.0.1:18188"

    async def fake_to_thread(fn, *a, **kw):
        calls.append(getattr(fn, "__name__", str(fn)))
        if fn.__name__ == "wait_for_comfyui":
            return True
        return {"ok": True}

    with patch(
        "loboforge_worker.provision.custom_nodes.power_lora_loader_registered",
        side_effect=[False, True],
    ):
        with patch(
            "loboforge_worker.provision.custom_nodes.resolve_vast_comfy_dir",
            return_value=__import__("pathlib").Path("/opt/workspace-internal/ComfyUI"),
        ):
            with patch("loboforge_worker.provision.custom_nodes.asyncio.to_thread", fake_to_thread):
                result = await ensure_power_lora_loader(Args())

    assert result["ok"] is True
    assert "restart_comfyui" in calls
    assert "install_rgthree" in calls
