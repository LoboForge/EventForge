from loboforge_worker.provision.ready import wait_until_ready
from loboforge_worker.provision.gpu_compat import derive_agent_hostname


def test_derive_hostname_for_fleet():
    hn = derive_agent_hostname(mode="image", label="loboforge-image", instance_id="38457416")
    assert hn.startswith("loboforge-image-")
    assert "38457416" in hn
