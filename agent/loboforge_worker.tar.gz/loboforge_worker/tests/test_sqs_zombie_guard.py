"""Regression: SQS workers must not park the fleet on invisible leases."""

import sys
from pathlib import Path
from unittest.mock import MagicMock

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import loboforge_agent_common as common
import loboforge_agent_sqs as sqs_agent
from forge_queue.worker import ForgeQueueWorker


def test_worker_can_poll_capability_skips_missing_probe_model():
    state = {"models": {"checkpoints": ["other.safetensors"]}}
    assert not common.worker_can_poll_capability(state, "zimage", hostname="test-image-1")
    assert common.worker_can_poll_capability(state, "caption", hostname="test-caption-1")


def test_worker_can_poll_capability_allows_when_probe_present():
    state = {"models": {"checkpoints": ["zimage_turbo.safetensors"]}}
    assert common.worker_can_poll_capability(state, "zimage", hostname="test-image-1")


def test_forge_worker_clamps_receive_visibility():
    worker = ForgeQueueWorker("zimage", receive_visibility_timeout=900, max_receive_visibility=120)
    assert worker.receive_visibility_timeout == 120
    worker_short = ForgeQueueWorker("zimage", receive_visibility_timeout=45)
    assert worker_short.receive_visibility_timeout == 45


def test_release_envelope_settles_guard():
    worker = MagicMock()
    envelope = MagicMock(job_id="abc-123")
    guard = sqs_agent._EnvelopeGuard(worker, envelope, "abc-123")
    with guard:
        sqs_agent._release_envelope(worker, envelope, reason="model foo not on worker", guard=guard)
    worker.release_message.assert_called_once()
    guard.release_unsettled("again")
    assert worker.release_message.call_count == 1


def test_envelope_guard_releases_on_unsettled_exit():
    worker = MagicMock()
    envelope = MagicMock(job_id="dead-beef")
    with sqs_agent._EnvelopeGuard(worker, envelope, "dead-beef"):
        pass
    worker.release_message.assert_called_once()


def test_make_sqs_workers_use_short_receive_visibility(monkeypatch):
    monkeypatch.setenv("FORGE_QUEUE_RECEIVE_VISIBILITY", "45")
    monkeypatch.setenv("FORGE_QUEUE_VISIBILITY", "300")
    args = MagicMock(hostname="loboforge-image-1")
    config = MagicMock()
    workers = sqs_agent._make_sqs_workers(("zimage",), args, config, ("normal",))
    assert len(workers) == 1
    assert workers[0].receive_visibility_timeout == 45
    assert workers[0].visibility_timeout == 300
