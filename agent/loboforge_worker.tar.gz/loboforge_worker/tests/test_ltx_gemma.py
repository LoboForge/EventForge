"""Tests for native LTX Gemma layout detection."""

from pathlib import Path

from loboforge_worker.inference.ltx.gemma import (
    COMFY_GEMMA_NAME,
    hf_gemma_ready,
    resolve_native_gemma_root,
)


def test_hf_gemma_ready_requires_config_and_shards(tmp_path: Path):
    root = tmp_path
    assert not hf_gemma_ready(root)

    gemma = root / "text_encoders/gemma-hf"
    gemma.mkdir(parents=True)
    (gemma / "config.json").write_text("{}", encoding="utf-8")
    assert not hf_gemma_ready(root)

    (gemma / "model-00001-of-00005.safetensors").write_bytes(b"x" * 1024)
    assert hf_gemma_ready(root)


def test_resolve_rejects_comfy_only_layout(tmp_path: Path):
    te = tmp_path / "text_encoders"
    te.mkdir(parents=True)
    (te / COMFY_GEMMA_NAME).write_bytes(b"x" * 1024)

    root, err = resolve_native_gemma_root(tmp_path)
    assert root is None
    assert err is not None
    assert "Comfy FP4" in err or COMFY_GEMMA_NAME in err


def test_resolve_prefers_hf_tree(tmp_path: Path):
    gemma = tmp_path / "text_encoders/gemma-hf"
    gemma.mkdir(parents=True)
    (gemma / "config.json").write_text("{}", encoding="utf-8")
    (gemma / "model.safetensors.index.json").write_text("{}", encoding="utf-8")
    (gemma / "model-00001-of-00005.safetensors").write_bytes(b"x" * 1024)

    root, err = resolve_native_gemma_root(tmp_path)
    assert err is None
    assert root == gemma
