from unittest.mock import patch

from loboforge_worker.provision.comfyui import restart_comfyui


def test_restart_skips_when_healthy_and_no_reload(tmp_path):
    with patch("loboforge_worker.provision.comfyui.comfyui_is_up", return_value=True):
        with patch("loboforge_worker.provision.comfyui.subprocess.run") as run:
            assert restart_comfyui(tmp_path) is False
            run.assert_not_called()


def test_restart_runs_when_reload_plugins(tmp_path):
    with patch("loboforge_worker.provision.comfyui.comfyui_is_up", return_value=True):
        with patch("loboforge_worker.provision.comfyui.subprocess.run") as run:
            with patch("loboforge_worker.provision.comfyui.time.sleep"):
                with patch("loboforge_worker.provision.comfyui.os.path.isfile", return_value=False):
                    restart_comfyui(tmp_path, reload_plugins=True)
            assert run.called
