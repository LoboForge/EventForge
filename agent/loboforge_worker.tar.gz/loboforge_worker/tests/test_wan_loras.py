"""Native Wan high/low LoRA routing."""

from pathlib import Path

from loboforge_worker.inference.wan.graph import extract_native_wan_loras
from loboforge_worker.inference.wan.loras import (
    builtin_lightning_loras,
    classify_wan_lora_stage,
    filter_loras_for_stage,
)


def test_classify_wan_lora_stage_from_filename():
    assert classify_wan_lora_stage("wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors") == "high"
    assert classify_wan_lora_stage("wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors") == "low"
    assert classify_wan_lora_stage("wan2.2-i2v-low-sex-smashcut-v1.0.safetensors") == "low"
    assert classify_wan_lora_stage("wan2.2-i2v-high-detail-v1.safetensors") == "high"


def test_filter_loras_for_stage_rejects_mismatched_pair():
    high_lora = {
        "path": "/tmp/high.safetensors",
        "name": "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
        "strength": 1.0,
    }
    low_lora = {
        "path": "/tmp/low.safetensors",
        "name": "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
        "strength": 1.0,
    }
    assert len(filter_loras_for_stage([high_lora, low_lora], "high")) == 1
    assert filter_loras_for_stage([high_lora, low_lora], "high")[0]["name"].endswith("high_noise.safetensors")
    assert len(filter_loras_for_stage([high_lora, low_lora], "low")) == 1


def test_builtin_lightning_loras_require_matching_names(tmp_path):
    root = tmp_path / "wan-models"
    loras = root / "loras"
    loras.mkdir(parents=True)
    high = loras / "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors"
    low = loras / "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors"
    high.write_bytes(b"x" * 100_000)
    low.write_bytes(b"x" * 100_000)
    layout = {"lightning_high": str(high), "lightning_low": str(low)}
    out = builtin_lightning_loras(layout)
    assert len(out["high"]) == 1
    assert len(out["low"]) == 1
    assert "high_noise" in out["high"][0]["name"]
    assert "low_noise" in out["low"][0]["name"]


def test_extract_native_wan_loras_routes_low_chain_by_unet(tmp_path):
    root = tmp_path / "wan-models"
    loras = root / "loras"
    loras.mkdir(parents=True)
    low_file = loras / "wan2.2-i2v-low-custom.safetensors"
    low_file.write_bytes(b"x" * 1000)

    graph = {
        "200": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors"},
        },
        "201": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["200", 0],
                "lora_name": "wan2.2-i2v-low-custom.safetensors",
                "strength_model": 0.8,
            },
        },
        "100": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors"},
        },
        "101": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "model": ["100", 0],
                "lora_name": "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
                "strength_model": 1.0,
            },
        },
    }

    out = extract_native_wan_loras(graph, root)
    assert out["high"] == []
    assert len(out["low"]) == 1
    assert out["low"][0]["name"] == "wan2.2-i2v-low-custom.safetensors"
    assert out["low"][0]["strength"] == 0.8


def test_extract_native_wan_loras_skips_builtin_lightning(tmp_path):
    root = tmp_path / "wan-models"
    loras = root / "loras"
    loras.mkdir(parents=True)
    for name in (
        "wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors",
        "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
    ):
        (loras / name).write_bytes(b"x" * 1000)

    graph = {
        "2100": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "lora_name": "wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors",
                "strength_model": 1.0,
            },
        },
    }
    out = extract_native_wan_loras(graph, root)
    assert out["high"] == []
    assert out["low"] == []
