"""Regression: health supervisor must not kill in-flight wan queue jobs early."""

from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock

import pytest

import loboforge_worker.health as health_mod
from loboforge_worker.health import HealthSupervisor, STUCK_CANARY_SEC, STUCK_NO_START_SEC


class _Args:
    hostname = "loboforge-wan-test"
    comfyui_http = "http://127.0.0.1:18188"


def test_health_module_has_no_stuck_job_sec():
    assert not hasattr(health_mod, "STUCK_JOB_SEC")


@pytest.mark.asyncio
async def test_in_flight_wan_job_not_cleared_at_150s():
    """Old STUCK_JOB_SEC=150 caused 'Queue job stuck after 2 minutes' — must not return."""
    state = {
        "current_job": "real-job-uuid",
        "current_job_since": time.time() - 150,
        "job_started": True,
    }
    sup = HealthSupervisor(
        session=MagicMock(),
        args=_Args(),
        agent_state=state,
        provision=None,
        comfy_is_healthy=AsyncMock(return_value=True),
        ensure_comfyui_running=AsyncMock(return_value=True),
        maybe_free_comfy_disk=lambda _a: None,
        model_count=lambda _m: 8,
    )
    await sup._maybe_clear_stuck_job()
    assert state["current_job"] == "real-job-uuid"


@pytest.mark.asyncio
async def test_in_flight_wan_job_not_cleared_at_five_minutes():
    """Healthy wan runs often have no WS events for several minutes."""
    state = {
        "current_job": "real-job-uuid",
        "current_job_since": time.time() - 299,
        "job_started": True,
    }
    sup = HealthSupervisor(
        session=MagicMock(),
        args=_Args(),
        agent_state=state,
        provision=None,
        comfy_is_healthy=AsyncMock(return_value=True),
        ensure_comfyui_running=AsyncMock(return_value=True),
        maybe_free_comfy_disk=lambda _a: None,
        model_count=lambda _m: 8,
    )
    await sup._maybe_clear_stuck_job()
    assert state["current_job"] == "real-job-uuid"


@pytest.mark.asyncio
async def test_job_never_started_cleared_after_90s():
    state = {
        "current_job": "job-1",
        "current_job_since": time.time() - (STUCK_NO_START_SEC + 5),
        "job_started": False,
    }
    session = MagicMock()
    session.send_json = AsyncMock()
    sup = HealthSupervisor(
        session=session,
        args=_Args(),
        agent_state=state,
        provision=None,
        comfy_is_healthy=AsyncMock(return_value=True),
        ensure_comfyui_running=AsyncMock(return_value=True),
        maybe_free_comfy_disk=lambda _a: None,
        model_count=lambda _m: 0,
    )
    await sup._maybe_clear_stuck_job()
    assert state.get("current_job") is None
    session.send_json.assert_awaited()


@pytest.mark.asyncio
async def test_canary_still_cleared_after_timeout():
    state = {
        "current_job": "canary-abc",
        "current_job_since": time.time() - (STUCK_CANARY_SEC + 10),
        "job_started": True,
    }
    session = MagicMock()
    session.send_json = AsyncMock()
    sup = HealthSupervisor(
        session=session,
        args=_Args(),
        agent_state=state,
        provision=None,
        comfy_is_healthy=AsyncMock(return_value=True),
        ensure_comfyui_running=AsyncMock(return_value=True),
        maybe_free_comfy_disk=lambda _a: None,
        model_count=lambda _m: 0,
    )
    await sup._maybe_clear_stuck_job()
    assert state.get("current_job") is None
