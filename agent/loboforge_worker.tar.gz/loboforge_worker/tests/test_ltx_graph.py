"""Tests for native LTX graph parameter extraction."""

from loboforge_worker.inference.ltx.graph import (
    extract_native_ltx_conditioning_image,
    extract_native_ltx_loras,
    extract_native_ltx_params,
    normalize_num_frames,
    snap_dimension,
)


def test_snap_dimension_rounds_down_to_multiple_of_64():
    assert snap_dimension(720) == 704
    assert snap_dimension(1280) == 1280
    assert snap_dimension(512) == 512


def test_extract_reads_template_node_ids_without_meta():
    """Server graphs strip _meta — patched PrimitiveInt values must still apply."""
    graph = {
        "267:266": {
            "class_type": "PrimitiveStringMultiline",
            "inputs": {"value": "loboforge queue canary, simple test image"},
        },
        "267:257": {"class_type": "PrimitiveInt", "inputs": {"value": 512}},
        "267:258": {"class_type": "PrimitiveInt", "inputs": {"value": 512}},
        "267:260": {"class_type": "PrimitiveInt", "inputs": {"value": 25}},
        "267:225": {"class_type": "PrimitiveInt", "inputs": {"value": 3}},
        "267:247": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": "blurry"},
        },
        "267:216": {"class_type": "RandomNoise", "inputs": {"noise_seed": 99}},
    }

    params = extract_native_ltx_params(graph)

    assert params["width"] == 512
    assert params["height"] == 512
    assert params["prompt"] == "loboforge queue canary, simple test image"
    assert params["negative_prompt"] == "blurry"
    assert params["seed"] == 99
    assert params["frame_rate"] == 25.0
    assert params["num_frames"] == normalize_num_frames(3 * 25 + 1)


def test_extract_snaps_invalid_default_resolution():
    """Fallback defaults must be pipeline-safe when template nodes are absent."""
    graph = {
        "267:266": {
            "class_type": "PrimitiveStringMultiline",
            "inputs": {"value": "test"},
        },
    }

    params = extract_native_ltx_params(graph)

    assert params["width"] % 64 == 0
    assert params["height"] % 64 == 0


def test_extract_native_ltx_loras_skips_builtin_and_resolves_user(tmp_path):
    loras_dir = tmp_path / "loras"
    loras_dir.mkdir()
    user_file = loras_dir / "my_style.safetensors"
    user_file.write_bytes(b"x" * 128)

    graph = {
        "267:232": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "lora_name": "ltx-2.3-22b-distilled-lora-384.safetensors",
                "strength_model": 0.5,
            },
        },
        "267:3000": {
            "class_type": "LoraLoaderModelOnly",
            "inputs": {
                "lora_name": "my_style.safetensors",
                "strength_model": 0.85,
            },
        },
    }

    found = extract_native_ltx_loras(graph, tmp_path)
    assert len(found) == 1
    assert found[0]["name"] == "my_style.safetensors"
    assert found[0]["path"] == str(user_file)
    assert found[0]["strength"] == 0.85


def test_extract_native_ltx_conditioning_image_reads_load_image(tmp_path):
    ref = tmp_path / "start.png"
    ref.write_bytes(b"\x89PNG\r\n\x1a\n")

    graph = {
        "267:325": {
            "class_type": "LoadImage",
            "inputs": {"image": str(ref)},
        },
    }

    assert extract_native_ltx_conditioning_image(graph) == str(ref)


def test_extract_native_ltx_conditioning_image_ignores_empty_image():
    graph = {
        "267:325": {
            "class_type": "EmptyImage",
            "inputs": {"width": 512, "height": 512},
        },
    }

    assert extract_native_ltx_conditioning_image(graph) is None
