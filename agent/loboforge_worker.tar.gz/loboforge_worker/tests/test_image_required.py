import json
from pathlib import Path

from loboforge_worker.manifest import load_local
from loboforge_worker.provision.validate import missing_required_artifacts


def test_image_stack_marks_zimage_core_required():
    manifest = load_local("image_stack")
    assert manifest is not None
    required = {a.dest for a in manifest.artifacts if a.required}
    assert "text_encoders/zImage_textEncoder.safetensors" in required
    assert "diffusion_models/Zimage/z_image_turbo_bf16_nsfw_v2.safetensors" in required


def test_missing_required_ignores_skip_cache(tmp_path, monkeypatch):
    manifest = load_local("image_stack")
    assert manifest is not None
    zte = next(a for a in manifest.artifacts if a.dest.endswith("zImage_textEncoder.safetensors"))
    skip_file = tmp_path / "skips.json"
    skip_file.write_text(json.dumps({zte.dest: "hf failed"}), encoding="utf-8")
    monkeypatch.setattr(
        "loboforge_worker.provision.validate.artifact_skip_reason",
        lambda dest: "hf failed" if dest == zte.dest else None,
    )
    missing = missing_required_artifacts(tmp_path, [manifest])
    assert zte.dest in missing
