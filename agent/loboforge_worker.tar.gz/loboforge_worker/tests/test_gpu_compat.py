import os

from loboforge_worker.provision.gpu_compat import (
    derive_agent_hostname,
    resolve_instance_suffix,
    sanitize_hostname_part,
    _looks_like_docker_id,
)


def test_sanitize_hostname_part():
    assert sanitize_hostname_part("loboforge-image") == "loboforge-image"
    assert sanitize_hostname_part("LOB OFORGE ALL") == "lob-oforge-all"


def test_resolve_instance_suffix_numeric_vast_id():
    assert resolve_instance_suffix(instance_id="38617234") == "38617234"
    assert len(resolve_instance_suffix(instance_id="123456789012")) == 8


def test_derive_agent_hostname_uses_label_and_instance():
    hn = derive_agent_hostname(
        mode="image",
        label="loboforge-image",
        instance_id="38701079",
        hostname_file="/tmp/lobo-test-hostname-38701079",
    )
    assert hn.startswith("loboforge-image-")
    assert "38701079" in hn or hn.endswith("701079")
    assert not _looks_like_docker_id(hn)
    os.remove("/tmp/lobo-test-hostname-38701079")


def test_docker_id_rejected():
    assert _looks_like_docker_id("9b34093b207b")
    assert not _looks_like_docker_id("loboforge-all-38617234")


def test_derive_hostname_rejects_docker_only_prefix(tmp_path):
    path = tmp_path / ".loboforge-hostname"
    path.write_text("abc123def456")
    hn = derive_agent_hostname(
        mode="all",
        label="loboforge-all",
        instance_id="38617234",
        hostname_file=path,
    )
    assert hn == "loboforge-all-38617234" or hn.startswith("loboforge-all-")
