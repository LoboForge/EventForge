"""Extract native Wan job parameters from Comfy workflow graphs."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

log = logging.getLogger("worker.wan.graph")

_WAN_I2V_TEMPLATE = {
    "prompt": "93",
    "negative": "89",
    "wan_i2v": "98",
    "fps": "94",
    "sampler_high": "86",
    "sampler_low": "85",
    "start_image": "97",
}


def normalize_wan_frames(raw: int) -> int:
    """Wan expects frame_num = 4n+1."""
    if raw < 1:
        return 81
    n = (raw - 1) // 4
    normalized = 4 * n + 1
    if normalized != raw:
        log.info("Adjusted frame_num %s -> %s (4n+1 rule)", raw, normalized)
    return normalized


def _node_inputs(graph: dict, node_id: str) -> dict:
    node = graph.get(node_id)
    if not isinstance(node, dict):
        return {}
    inputs = node.get("inputs")
    return inputs if isinstance(inputs, dict) else {}


def _text_from_clip_node(graph: dict, node_id: str, default: str = "") -> str:
    inputs = _node_inputs(graph, node_id)
    text = inputs.get("text")
    if isinstance(text, str) and text.strip():
        return text.strip()
    return default


def _int_input(inputs: dict, key: str, default: int) -> int:
    val = inputs.get(key)
    if isinstance(val, bool):
        return default
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


def _float_input(inputs: dict, key: str, default: float) -> float:
    val = inputs.get(key)
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _find_node_by_class(graph: dict, class_type: str) -> dict | None:
    for node in graph.values():
        if isinstance(node, dict) and node.get("class_type") == class_type:
            return node
    return None


def extract_native_wan_params(graph: dict, *, default_fps: float = 16.0) -> dict[str, Any]:
    """Parse wan2 / wan2flf Comfy graphs into native Wan2.2 generate() args."""
    tpl = _WAN_I2V_TEMPLATE
    prompt = _text_from_clip_node(graph, tpl["prompt"], "cinematic video")
    negative = _text_from_clip_node(graph, tpl["negative"], "")

    width, height, frames = 512, 768, 81
    wan_node = graph.get(tpl["wan_i2v"])
    if not isinstance(wan_node, dict):
        wan_node = _find_node_by_class(graph, "WanImageToVideo")
    if isinstance(wan_node, dict):
        inputs = wan_node.get("inputs") or {}
        width = _int_input(inputs, "width", width)
        height = _int_input(inputs, "height", height)
        frames = normalize_wan_frames(_int_input(inputs, "length", frames))

    fps = default_fps
    fps_node = graph.get(tpl["fps"])
    if isinstance(fps_node, dict):
        fps = _float_input(fps_node.get("inputs") or {}, "fps", fps)

    steps = 4
    cfg = 1.4
    seed = 42
    for sid in (tpl["sampler_high"], tpl["sampler_low"]):
        node = graph.get(sid)
        if not isinstance(node, dict):
            continue
        inputs = node.get("inputs") or {}
        steps = _int_input(inputs, "steps", steps)
        cfg = _float_input(inputs, "cfg", cfg)
        if "noise_seed" in inputs:
            seed = _int_input(inputs, "noise_seed", seed)

    shift = 5.0
    ms_node = _find_node_by_class(graph, "ModelSamplingSD3")
    if isinstance(ms_node, dict):
        shift = _float_input(ms_node.get("inputs") or {}, "shift", shift)

    return {
        "prompt": prompt,
        "negative_prompt": negative,
        "width": max(64, width),
        "height": max(64, height),
        "num_frames": frames,
        "frame_rate": float(fps),
        "seed": int(seed),
        "sampling_steps": int(steps),
        "guide_scale": (float(cfg), float(cfg)),
        "shift": float(shift),
        "task": "i2v-A14B",
    }


def extract_native_wan_conditioning_image(graph: dict) -> str | None:
    """Local path for i2v start frame after ref-image patching."""
    for node_id in (_WAN_I2V_TEMPLATE["start_image"],):
        node = graph.get(node_id)
        if not isinstance(node, dict) or node.get("class_type") != "LoadImage":
            continue
        img = (node.get("inputs") or {}).get("image")
        if not isinstance(img, str):
            continue
        img = img.strip()
        if not img or img.startswith("ref_"):
            continue
        path = Path(img)
        if path.is_file():
            return str(path)
        for base in (Path("/tmp/lobo-ref-images"), Path("input")):
            candidate = base / img
            if candidate.is_file():
                return str(candidate)
    for node in graph.values():
        if not isinstance(node, dict) or node.get("class_type") != "LoadImage":
            continue
        img = (node.get("inputs") or {}).get("image")
        if isinstance(img, str) and img.strip() and not img.startswith("ref_"):
            path = Path(img.strip())
            if path.is_file():
                return str(path)
    return None


_BUILTIN_WAN_LORA_MARKERS = (
    "lightx2v_4steps",
    "lightx2v",
)


def extract_native_wan_loras(graph: dict, model_root: str | Path) -> dict[str, list[dict[str, Any]]]:
    """
    User LoRAs from LoraLoaderModelOnly chains.
    Returns {"high": [...], "low": [...]} with path/strength/name.
    """
    root = Path(model_root)
    loras_dir = root / "loras"
    high: list[dict[str, Any]] = []
    low: list[dict[str, Any]] = []
    seen: set[str] = set()

    # Walk graph: nodes 101+ are high chain, 102+ low in canonical wan2 i2v template.
    high_chain = {"101"}
    low_chain = {"102"}
    for node_id, node in graph.items():
        if not isinstance(node, dict) or node.get("class_type") != "LoraLoaderModelOnly":
            continue
        inputs = node.get("inputs") or {}
        model_ref = inputs.get("model")
        parent = str(model_ref[0]) if isinstance(model_ref, list) and model_ref else ""
        try:
            nid = int(node_id)
        except ValueError:
            nid = 0
        stage = "both"
        if parent in high_chain or (2100 <= nid < 2200):
            stage = "high"
        elif parent in low_chain or (2200 <= nid < 2300):
            stage = "low"

        raw_name = str(inputs.get("lora_name") or "").strip()
        if not raw_name:
            continue
        lower = raw_name.lower()
        if any(m in lower for m in _BUILTIN_WAN_LORA_MARKERS):
            continue
        try:
            strength = float(inputs.get("strength_model", 1.0))
        except (TypeError, ValueError):
            strength = 1.0

        basename = Path(raw_name.replace("\\", "/")).name
        if not basename or basename in seen:
            continue
        seen.add(basename)

        candidates = [
            root / raw_name,
            loras_dir / basename,
            Path(raw_name) if Path(raw_name).is_absolute() else None,
        ]
        resolved = next((p for p in candidates if p is not None and p.is_file()), None)
        if resolved is None:
            log.warning("Native Wan: LoRA not on disk — %s", raw_name)
            continue
        entry = {"path": str(resolved), "strength": strength, "name": basename}
        if stage == "high":
            high.append(entry)
        elif stage == "low":
            low.append(entry)
        else:
            high.append(entry)
            low.append(entry)
    return {"high": high, "low": low}
