"""Native Wan 2.2 inference via Wan-Video/Wan2.2 (no ComfyUI)."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

from .graph import extract_native_wan_conditioning_image, extract_native_wan_loras, extract_native_wan_params
from .loras import apply_loras_to_model, builtin_lightning_loras
from .paths import (
    i2v_ready,
    load_layout,
    prefer_offload_during_generate,
    prefer_warm_pipeline,
    t2v_ready,
    vram_gb,
    wan_model_root,
    wan_repo_root,
)

log = logging.getLogger("worker.wan.runner")

_PIPELINE_CACHE: dict[str, Any] = {}

# GPUs below this threshold use expert-swap min-config (t5_cpu, init_on_cpu, no warm cache).
WAN_OFFLOAD_VRAM_GB = 48.0


def clear_native_wan_pipeline_cache() -> None:
    _PIPELINE_CACHE.clear()


def _wan_low_vram() -> bool:
    env = os.environ.get("WAN_LOW_VRAM", "").strip().lower()
    if env in ("1", "true", "yes"):
        return True
    gb = vram_gb()
    return gb <= 0 or gb < WAN_OFFLOAD_VRAM_GB


def _ensure_wan_imports(repo: Path) -> None:
    repo = repo.resolve()
    if not (repo / "wan").is_dir():
        raise RuntimeError(f"Wan2.2 repo missing at {repo}")
    s = str(repo)
    if s not in sys.path:
        sys.path.insert(0, s)


def _layout_ready(layout: dict[str, Any] | None) -> tuple[dict[str, Any], str | None]:
    if not layout:
        return {}, "layout.json missing — native Wan not provisioned"
    task = str(layout.get("task") or "i2v-A14B")
    root = Path(str(layout.get("model_root") or wan_model_root()))
    if task.startswith("i2v") and not i2v_ready(root):
        return layout, f"native Wan I2V checkpoint missing under {root}"
    if task.startswith("t2v") and not t2v_ready(root):
        return layout, f"native Wan T2V checkpoint missing under {root}"
    repo = Path(str(layout.get("wan_repo") or wan_repo_root()))
    if not (repo / "wan").is_dir():
        return layout, f"Wan2.2 repo missing at {repo}"
    return layout, None


def _pipeline_cache_key(
    layout: dict[str, Any],
    task: str,
    user_loras: dict[str, list[dict[str, Any]]],
) -> str:
    parts = [
        task,
        str(layout.get("i2v_checkpoint")),
        str(layout.get("t2v_checkpoint")),
    ]
    for stage in ("high", "low"):
        for e in user_loras.get(stage, []):
            parts.append(f"{e.get('name')}:{e.get('strength')}")
    return "|".join(parts)


def _clone_fresh_models(pipeline: Any, layout: dict[str, Any], user_loras: dict[str, list[dict[str, Any]]]) -> None:
    """Re-apply lightning + user loras on fresh WanI2V/WanT2V load."""
    builtin = builtin_lightning_loras(layout)
    for attr, stage in (("high_noise_model", "high"), ("low_noise_model", "low")):
        model = getattr(pipeline, attr, None)
        if model is None:
            continue
        entries = list(builtin.get(stage, [])) + list(user_loras.get(stage, []))
        apply_loras_to_model(model, entries)


def _create_pipeline(layout: dict[str, Any], task: str):
    import torch

    _ensure_wan_imports(Path(str(layout["wan_repo"])))
    from wan.configs import WAN_CONFIGS
    from wan.image2video import WanI2V
    from wan.text2video import WanT2V

    cfg = WAN_CONFIGS[task]
    ckpt = str(layout["i2v_checkpoint"] if task.startswith("i2v") else layout["t2v_checkpoint"])
    convert_dtype = True
    low_vram = _wan_low_vram()
    init_on_cpu = True if low_vram else not prefer_warm_pipeline()
    t5_cpu = True if low_vram else False
    common = dict(
        config=cfg,
        checkpoint_dir=ckpt,
        device_id=0,
        rank=0,
        t5_fsdp=False,
        dit_fsdp=False,
        use_sp=False,
        t5_cpu=t5_cpu,
        init_on_cpu=init_on_cpu,
        convert_model_dtype=convert_dtype,
    )
    if task.startswith("i2v"):
        pipeline = WanI2V(**common)
    else:
        pipeline = WanT2V(**common)

    if low_vram:
        try:
            pipeline.low_noise_model.cpu()
            pipeline.high_noise_model.cpu()
            torch.cuda.empty_cache()
            log.info(
                "Native Wan: experts parked on CPU (swap-per-timestep); t5_cpu=%s vram=%.1fGB",
                t5_cpu,
                vram_gb(),
            )
        except Exception as ex:
            log.warning("Native Wan CPU park failed: %s", ex)
    elif prefer_warm_pipeline() and torch.cuda.is_available():
        try:
            pipeline.low_noise_model.to(pipeline.device)
            pipeline.high_noise_model.to(pipeline.device)
        except Exception as ex:
            log.warning("Warm pipeline GPU move partial: %s", ex)

    return pipeline


def _get_or_create_pipeline(layout: dict[str, Any], user_loras: dict[str, list[dict[str, Any]]], task: str):
    key = _pipeline_cache_key(layout, task, user_loras)
    cached = _PIPELINE_CACHE.get(key)
    if cached is not None:
        return cached
    pipeline = _create_pipeline(layout, task)
    _clone_fresh_models(pipeline, layout, user_loras)
    if _wan_low_vram():
        clear_native_wan_pipeline_cache()
        return pipeline
    if prefer_warm_pipeline():
        _PIPELINE_CACHE.clear()
        _PIPELINE_CACHE[key] = pipeline
    return pipeline


def _filter_loras_for_vram(user_loras: dict[str, list[dict[str, Any]]], vram: float) -> dict[str, list[dict[str, Any]]]:
    if vram >= WAN_OFFLOAD_VRAM_GB or not user_loras:
        return user_loras
    filtered: dict[str, list[dict[str, Any]]] = {}
    for stage, items in user_loras.items():
        keep = [
            x
            for x in (items or [])
            if "lightx2v" in str(x.get("path") or x.get("name") or "").lower()
        ]
        if keep:
            filtered[stage] = keep
    if filtered != user_loras:
        log.warning(
            "Low-VRAM (<%.0fGB): dropping non-lightning LoRAs for native Wan (keep lightx2v only)",
            WAN_OFFLOAD_VRAM_GB,
        )
    return filtered or user_loras


def _apply_vram_caps(params: dict[str, Any], guide: Any, vram: float) -> Any:
    if vram >= WAN_OFFLOAD_VRAM_GB:
        return guide
    if vram < 28:
        if int(params.get("num_frames") or 0) > 5:
            log.warning("Capping frames %s -> 5 for %.0fGB GPU", params.get("num_frames"), vram)
            params["num_frames"] = 5
        w, h = int(params["width"]), int(params["height"])
        if w * h > 256 * 384:
            log.warning("Capping size %sx%s -> 256x384 for %.0fGB GPU", w, h, vram)
            if w >= h:
                params["width"], params["height"] = 256, 384
            else:
                params["width"], params["height"] = 384, 256
    else:
        if int(params.get("num_frames") or 0) > 9:
            log.warning("Capping frames %s -> 9 for %.0fGB GPU", params.get("num_frames"), vram)
            params["num_frames"] = 9
        w, h = int(params["width"]), int(params["height"])
        if w * h > 320 * 480:
            log.warning("Capping size %sx%s -> 320x480 for %.0fGB GPU", w, h, vram)
            if w >= h:
                params["width"], params["height"] = 320, 480
            else:
                params["width"], params["height"] = 480, 320
    log.warning("Forcing guide_scale=1.0 (single CFG pass) for %.0fGB GPU", vram)
    return 1.0


def _maybe_accelerate_offload(pipeline: Any, vram: float) -> None:
    if vram >= 28:
        return
    import types

    import torch
    from accelerate import cpu_offload

    log.warning("Enabling accelerate cpu_offload for %.0fGB GPU", vram)
    try:
        pipeline.high_noise_model.cpu()
        pipeline.low_noise_model.cpu()
        torch.cuda.empty_cache()
    except Exception:
        pass
    cpu_offload(pipeline.high_noise_model, execution_device=torch.device("cuda:0"))
    cpu_offload(pipeline.low_noise_model, execution_device=torch.device("cuda:0"))

    def _prep_offload(self, t, boundary, offload_model):
        if t.item() >= boundary:
            return self.low_noise_model
        return self.high_noise_model

    pipeline._prepare_model_for_timestep = types.MethodType(_prep_offload, pipeline)


def run_native_wan_sync(
    graph: dict,
    layout: dict[str, Any],
    output_path: Path,
    *,
    on_progress: Callable[[int, int], None] | None = None,
) -> Path:
    """Blocking GPU inference — call from a thread pool."""
    params = extract_native_wan_params(
        graph,
        default_fps=float(layout.get("fps") or 16),
    )
    task = str(params.get("task") or layout.get("task") or "i2v-A14B")
    if task.startswith("t2v"):
        raise RuntimeError("native Wan T2V not yet enabled on this box")

    img_path = extract_native_wan_conditioning_image(graph)
    if not img_path:
        raise RuntimeError("native Wan i2v requires a start image (ref image)")

    from PIL import Image

    img = Image.open(img_path).convert("RGB")

    root = Path(str(layout.get("model_root") or wan_model_root()))
    user_loras = extract_native_wan_loras(graph, root)
    _vram_gb = vram_gb() or 40.0
    user_loras = _filter_loras_for_vram(user_loras, _vram_gb)

    if on_progress:
        on_progress(1, 100)

    pipeline = _get_or_create_pipeline(layout, user_loras, task)

    steps = int(params.get("sampling_steps") or layout.get("sample_steps") or 4)
    shift = float(params.get("shift") or layout.get("sample_shift") or 5.0)
    guide = params.get("guide_scale") or layout.get("guide_scale") or (1.4, 1.4)
    if isinstance(guide, list):
        guide = tuple(float(x) for x in guide)
    offload = True if _wan_low_vram() else prefer_offload_during_generate()
    os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

    log.info(
        "Native Wan %s: %dx%d %d frames steps=%d seed=%s vram=%.1fGB offload=%s prompt=%r",
        task,
        params["width"],
        params["height"],
        params["num_frames"],
        steps,
        params["seed"],
        _vram_gb,
        offload,
        (params["prompt"][:80] + "…") if len(params["prompt"]) > 80 else params["prompt"],
    )

    if on_progress:
        on_progress(5, 100)

    if _wan_low_vram():
        try:
            import gc

            import torch

            pipeline.low_noise_model.cpu()
            pipeline.high_noise_model.cpu()
            gc.collect()
            torch.cuda.empty_cache()
            torch.cuda.ipc_collect()
            log.info("pre-generate expert park (swap-only)")
        except Exception as ex:
            log.warning("pre-generate expert park failed: %s", ex)

    guide = _apply_vram_caps(params, guide, _vram_gb)
    _maybe_accelerate_offload(pipeline, _vram_gb)

    max_area = int(params["width"]) * int(params["height"])
    video = pipeline.generate(
        params["prompt"],
        img,
        max_area=max_area,
        frame_num=int(params["num_frames"]),
        shift=shift,
        sample_solver="unipc",
        sampling_steps=steps,
        guide_scale=guide,
        n_prompt=params.get("negative_prompt") or "",
        seed=int(params["seed"]),
        offload_model=offload,
    )

    if on_progress:
        on_progress(90, 100)

    from wan.configs import WAN_CONFIGS
    from wan.utils.utils import save_video

    cfg = WAN_CONFIGS[task]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    save_video(
        tensor=video[None],
        save_file=str(output_path),
        fps=float(params["frame_rate"]),
        nrow=1,
        normalize=True,
        value_range=(-1, 1),
    )

    if on_progress:
        on_progress(100, 100)

    return output_path


async def run_native_wan_job(
    graph: dict,
    *,
    on_progress: Callable[[int, int], None] | None = None,
    on_activity: Callable[[], None] | None = None,
) -> tuple[bytes, str] | None:
    """Run native Wan generation asynchronously. Returns (file_bytes, filename)."""
    layout, err = _layout_ready(load_layout())
    if err:
        raise RuntimeError(err)

    tick_task: asyncio.Task | None = None
    if on_activity:

        async def _tick() -> None:
            while True:
                await asyncio.sleep(30)
                try:
                    on_activity()
                except Exception:
                    break

        tick_task = asyncio.create_task(_tick())

    loop = asyncio.get_running_loop()
    try:
        with tempfile.TemporaryDirectory(prefix="lobo-wan-") as tmp:
            out = Path(tmp) / "output.mp4"

            def _progress(step: int, total: int) -> None:
                if not on_progress:
                    return
                try:
                    result = on_progress(step, total)
                    if asyncio.iscoroutine(result):
                        asyncio.run_coroutine_threadsafe(result, loop).result(timeout=10)
                except Exception:
                    pass

            await asyncio.to_thread(run_native_wan_sync, graph, layout, out, on_progress=_progress)
            if not out.is_file() or out.stat().st_size < 1000:
                raise RuntimeError("native Wan produced no output video")
            return out.read_bytes(), out.name
    finally:
        if tick_task:
            tick_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await tick_task
