"""Native Wan 2.2 inference via Wan-Video/Wan2.2 (no ComfyUI)."""
