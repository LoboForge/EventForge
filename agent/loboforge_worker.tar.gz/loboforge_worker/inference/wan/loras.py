"""Apply Comfy-style LoRA safetensors to Wan DiT models."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Literal

log = logging.getLogger("worker.wan.loras")

WanNoiseStage = Literal["high", "low"]

_LORA_DOWN = re.compile(r"^(.*)\.(lora_down|lora_A)\.weight$")
_LORA_UP = re.compile(r"^(.*)\.(lora_up|lora_B)\.weight$")
_ALPHA = re.compile(r"^(.*)\.alpha$")

_BUILTIN_WAN_LORA_MARKERS = (
    "lightx2v_4steps",
    "lightx2v",
)


def classify_wan_lora_stage(name: str) -> WanNoiseStage | None:
    """Infer high/low noise stage from a LoRA or UNet filename."""
    n = (name or "").lower().replace("\\", "/")
    if not n:
        return None
    basename = Path(n).name
    if "high_noise" in basename or "high-noise" in basename:
        return "high"
    if "low_noise" in basename or "low-noise" in basename:
        return "low"
    # Custom Wan LoRAs often use -i2v-high- / -i2v-low- in the basename.
    if re.search(r"(?:^|[-_/])high(?:[-_/]|$)", basename) and "low" not in basename:
        return "high"
    if re.search(r"(?:^|[-_/])low(?:[-_/]|$)", basename):
        return "low"
    return None


def is_builtin_wan_lora(name: str) -> bool:
    lower = (name or "").lower()
    return any(m in lower for m in _BUILTIN_WAN_LORA_MARKERS)


def filter_loras_for_stage(
    entries: list[dict[str, Any]],
    stage: WanNoiseStage,
) -> list[dict[str, Any]]:
    """Keep only LoRAs that belong on this noise stage."""
    out: list[dict[str, Any]] = []
    for entry in entries:
        name = str(entry.get("name") or Path(str(entry.get("path") or "")).name)
        inferred = classify_wan_lora_stage(name)
        if inferred and inferred != stage:
            log.warning(
                "Skipping LoRA %s on %s_noise_model (belongs on %s_noise_model)",
                name,
                stage,
                inferred,
            )
            continue
        out.append(entry)
    return out


def _normalize_key(key: str) -> str:
    k = key
    if k.startswith("diffusion_model."):
        k = k[len("diffusion_model.") :]
    if k.startswith("model."):
        k = k[len("model.") :]
    return k


def _load_lora_tensors(path: str | Path) -> dict[str, Any]:
    from safetensors.torch import load_file

    return load_file(str(path), device="cpu")


def _collect_lora_pairs(lora_sd: dict[str, Any]) -> dict[str, tuple[Any, Any, float]]:
    downs: dict[str, str] = {}
    ups: dict[str, str] = {}
    alphas: dict[str, float] = {}
    for key in lora_sd:
        m = _LORA_DOWN.match(key)
        if m:
            downs[m.group(1)] = key
            continue
        m = _LORA_UP.match(key)
        if m:
            ups[m.group(1)] = key
            continue
        m = _ALPHA.match(key)
        if m:
            try:
                val = lora_sd[key]
                alphas[m.group(1)] = float(val.item() if hasattr(val, "item") else val)
            except (TypeError, ValueError):
                alphas[m.group(1)] = 1.0
    pairs: dict[str, tuple[Any, Any, float]] = {}
    for base, down_key in downs.items():
        up_key = ups.get(base)
        if not up_key:
            continue
        alpha = alphas.get(base, 1.0)
        pairs[_normalize_key(base)] = (lora_sd[down_key], lora_sd[up_key], alpha)
    return pairs


def _compute_delta(down, up, alpha: float, strength: float):
    import torch

    if down.ndim == 4:
        # conv: (out, in, k, k) — flatten for matmul
        delta = torch.mm(up.squeeze(), down.squeeze())
    else:
        delta = torch.mm(up, down)
    scale = strength * (alpha / max(down.shape[0], 1))
    return delta * scale


def merge_lora_into_module_weights(
    state_dict: dict[str, Any],
    lora_path: str | Path,
    strength: float = 1.0,
) -> int:
    """
    Merge one LoRA file into a WanModel state_dict in-place.
    Returns count of tensors patched.
    """
    import torch

    lora_sd = _load_lora_tensors(lora_path)
    pairs = _collect_lora_pairs(lora_sd)
    patched = 0
    for base, (down, up, alpha) in pairs.items():
        weight_key = f"{base}.weight"
        if weight_key not in state_dict:
            # try without blocks prefix variants
            alt_keys = [k for k in state_dict if k.endswith(f"{base.split('.')[-1]}.weight")]
            if len(alt_keys) == 1:
                weight_key = alt_keys[0]
            else:
                continue
        weight = state_dict[weight_key]
        if not isinstance(weight, torch.Tensor):
            continue
        try:
            delta = _compute_delta(down, up, alpha, strength)
            if delta.shape != weight.shape:
                continue
            state_dict[weight_key] = weight + delta.to(dtype=weight.dtype, device=weight.device)
            patched += 1
        except Exception as ex:
            log.debug("LoRA patch skip %s: %s", weight_key, ex)
    return patched


def apply_loras_to_model(model, lora_entries: list[dict[str, Any]]) -> int:
    """Apply LoRA list to a torch module; returns total patches."""
    if not lora_entries:
        return 0
    state = model.state_dict()
    total = 0
    for entry in lora_entries:
        path = entry.get("path")
        if not path:
            continue
        strength = float(entry.get("strength", 1.0))
        n = merge_lora_into_module_weights(state, path, strength)
        if n:
            log.info("Wan LoRA %s strength=%.2f patches=%d", entry.get("name", path), strength, n)
        total += n
    if total:
        model.load_state_dict(state, strict=False)
    return total


def builtin_lightning_loras(layout: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    """Built-in Wan 2.2 lightning LoRAs — one high + one low, each on the matching model."""
    out: dict[str, list[dict[str, Any]]] = {"high": [], "low": []}
    for key, stage in (("lightning_high", "high"), ("lightning_low", "low")):
        raw = layout.get(key)
        if not raw:
            continue
        path = Path(str(raw))
        if not path.is_file():
            log.warning("Native Wan lightning %s LoRA missing: %s", stage, path)
            continue
        inferred = classify_wan_lora_stage(path.name)
        if inferred and inferred != stage:
            log.error(
                "Lightning LoRA %s is named like %s_noise but layout slot is %s_noise — fix layout.json",
                path.name,
                inferred,
                stage,
            )
            continue
        out[stage].append({"path": str(path), "strength": 1.0, "name": path.name})
    return out


def apply_loras_to_pipeline_models(
    pipeline: Any,
    layout: dict[str, Any],
    user_loras: dict[str, list[dict[str, Any]]],
) -> dict[str, int]:
    """
    Merge built-in + user LoRAs onto Wan high_noise_model / low_noise_model.
    High-stage LoRAs never touch low_noise_model and vice versa.
    """
    builtin = builtin_lightning_loras(layout)
    applied: dict[str, int] = {"high": 0, "low": 0}
    for attr, stage in (("high_noise_model", "high"), ("low_noise_model", "low")):
        model = getattr(pipeline, attr, None)
        if model is None:
            continue
        entries = filter_loras_for_stage(
            list(builtin.get(stage, [])) + list(user_loras.get(stage, [])),
            stage,
        )
        applied[stage] = apply_loras_to_model(model, entries)
        if entries:
            names = ", ".join(e.get("name", "?") for e in entries)
            log.info("Wan %s_noise_model LoRAs: %s (%d patches)", stage, names, applied[stage])
    return applied
