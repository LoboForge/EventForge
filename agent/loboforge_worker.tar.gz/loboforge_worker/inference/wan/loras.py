"""Apply Comfy-style LoRA safetensors to Wan DiT models."""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

log = logging.getLogger("worker.wan.loras")

_LORA_DOWN = re.compile(r"^(.*)\.(lora_down|lora_A)\.weight$")
_LORA_UP = re.compile(r"^(.*)\.(lora_up|lora_B)\.weight$")
_ALPHA = re.compile(r"^(.*)\.alpha$")


def _normalize_key(key: str) -> str:
    k = key
    if k.startswith("diffusion_model."):
        k = k[len("diffusion_model.") :]
    if k.startswith("model."):
        k = k[len("model.") :]
    return k


def _load_lora_tensors(path: str | Path) -> dict[str, Any]:
    from safetensors.torch import load_file

    return load_file(str(path), device="cpu")


def _collect_lora_pairs(lora_sd: dict[str, Any]) -> dict[str, tuple[Any, Any, float]]:
    downs: dict[str, str] = {}
    ups: dict[str, str] = {}
    alphas: dict[str, float] = {}
    for key in lora_sd:
        m = _LORA_DOWN.match(key)
        if m:
            downs[m.group(1)] = key
            continue
        m = _LORA_UP.match(key)
        if m:
            ups[m.group(1)] = key
            continue
        m = _ALPHA.match(key)
        if m:
            try:
                val = lora_sd[key]
                alphas[m.group(1)] = float(val.item() if hasattr(val, "item") else val)
            except (TypeError, ValueError):
                alphas[m.group(1)] = 1.0
    pairs: dict[str, tuple[Any, Any, float]] = {}
    for base, down_key in downs.items():
        up_key = ups.get(base)
        if not up_key:
            continue
        alpha = alphas.get(base, 1.0)
        pairs[_normalize_key(base)] = (lora_sd[down_key], lora_sd[up_key], alpha)
    return pairs


def _compute_delta(down, up, alpha: float, strength: float):
    import torch

    if down.ndim == 4:
        # conv: (out, in, k, k) — flatten for matmul
        delta = torch.mm(up.squeeze(), down.squeeze())
    else:
        delta = torch.mm(up, down)
    scale = strength * (alpha / max(down.shape[0], 1))
    return delta * scale


def merge_lora_into_module_weights(
    state_dict: dict[str, Any],
    lora_path: str | Path,
    strength: float = 1.0,
) -> int:
    """
    Merge one LoRA file into a WanModel state_dict in-place.
    Returns count of tensors patched.
    """
    import torch

    lora_sd = _load_lora_tensors(lora_path)
    pairs = _collect_lora_pairs(lora_sd)
    patched = 0
    for base, (down, up, alpha) in pairs.items():
        weight_key = f"{base}.weight"
        if weight_key not in state_dict:
            # try without blocks prefix variants
            alt_keys = [k for k in state_dict if k.endswith(f"{base.split('.')[-1]}.weight")]
            if len(alt_keys) == 1:
                weight_key = alt_keys[0]
            else:
                continue
        weight = state_dict[weight_key]
        if not isinstance(weight, torch.Tensor):
            continue
        try:
            delta = _compute_delta(down, up, alpha, strength)
            if delta.shape != weight.shape:
                continue
            state_dict[weight_key] = weight + delta.to(dtype=weight.dtype, device=weight.device)
            patched += 1
        except Exception as ex:
            log.debug("LoRA patch skip %s: %s", weight_key, ex)
    return patched


def apply_loras_to_model(model, lora_entries: list[dict[str, Any]]) -> int:
    """Apply LoRA list to a torch module; returns total patches."""
    if not lora_entries:
        return 0
    state = model.state_dict()
    total = 0
    for entry in lora_entries:
        path = entry.get("path")
        if not path:
            continue
        strength = float(entry.get("strength", 1.0))
        n = merge_lora_into_module_weights(state, path, strength)
        if n:
            log.info("Wan LoRA %s strength=%.2f patches=%d", entry.get("name", path), strength, n)
        total += n
    if total:
        model.load_state_dict(state, strict=False)
    return total


def builtin_lightning_loras(layout: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    high = layout.get("lightning_high")
    low = layout.get("lightning_low")
    out: dict[str, list[dict[str, Any]]] = {"high": [], "low": []}
    if high and Path(str(high)).is_file():
        out["high"].append({"path": str(high), "strength": 1.0, "name": Path(str(high)).name})
    if low and Path(str(low)).is_file():
        out["low"].append({"path": str(low), "strength": 1.0, "name": Path(str(low)).name})
    return out
