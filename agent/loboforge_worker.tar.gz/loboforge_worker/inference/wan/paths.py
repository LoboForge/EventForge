"""Model paths for native Wan 2.2 — Wan-Video/Wan2.2 repo + HF I2V checkpoint."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

DEFAULT_WAN_MODEL_ROOT = Path("/workspace/wan-models")
DEFAULT_WAN_REPO = Path("/workspace/Wan2.2")
LAYOUT_FILE = "layout.json"

I2V_CKPT_DIR = "Wan2.2-I2V-A14B"
I2V_T5_FILE = "models_t5_umt5-xxl-enc-bf16.pth"
I2V_T5_MIN_BYTES = 10_000_000_000  # ~11GB on disk
I2V_TASK = "i2v-A14B"
T2V_CKPT_DIR = "Wan2.2-T2V-A14B"
T2V_TASK = "t2v-A14B"

LIGHTNING_HIGH = "loras/wan2.2_i2v_lightx2v_4steps_lora_v1_high_noise.safetensors"
LIGHTNING_LOW = "loras/wan2.2_i2v_lightx2v_4steps_lora_v1_low_noise.safetensors"

# Inventory names must match WorkerModelCompatibility / agent gating heuristics.
I2V_HIGH_INVENTORY = "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors"
I2V_LOW_INVENTORY = "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors"
T2V_HIGH_INVENTORY = "wan2.2_t2v_high_noise_14B_fp8_scaled.safetensors"
T2V_LOW_INVENTORY = "wan2.2_t2v_low_noise_14B_fp8_scaled.safetensors"


def wan_model_root() -> Path:
    raw = os.environ.get("WAN_MODEL_ROOT", "").strip()
    return Path(raw) if raw else DEFAULT_WAN_MODEL_ROOT


def wan_repo_root() -> Path:
    raw = os.environ.get("WAN_REPO", "").strip()
    return Path(raw) if raw else DEFAULT_WAN_REPO


def file_ok(path: Path, min_bytes: int = 1024) -> bool:
    try:
        return path.is_file() and path.stat().st_size >= min_bytes
    except OSError:
        return False


def dir_ok(path: Path, min_files: int = 1) -> bool:
    try:
        return path.is_dir() and len(list(path.iterdir())) >= min_files
    except OSError:
        return False


def i2v_checkpoint_dir(root: Path | None = None) -> Path:
    return (root or wan_model_root()) / I2V_CKPT_DIR


def t2v_checkpoint_dir(root: Path | None = None) -> Path:
    return (root or wan_model_root()) / T2V_CKPT_DIR


def i2v_ready(root: Path | None = None) -> bool:
    ckpt = i2v_checkpoint_dir(root)
    return (
        dir_ok(ckpt / "high_noise_model")
        and dir_ok(ckpt / "low_noise_model")
        and file_ok(ckpt / "Wan2.1_VAE.pth", 100_000_000)
        and file_ok(ckpt / I2V_T5_FILE, I2V_T5_MIN_BYTES)
    )


def t2v_ready(root: Path | None = None) -> bool:
    ckpt = t2v_checkpoint_dir(root)
    return dir_ok(ckpt / "high_noise_model") and dir_ok(ckpt / "low_noise_model")


def missing_artifacts(root: Path | None = None) -> list[str]:
    base = root or wan_model_root()
    out: list[str] = []
    repo = wan_repo_root()
    if not (repo / "wan").is_dir():
        out.append("Wan2.2 repo (wan package)")
    if not i2v_ready(base):
        out.append(I2V_CKPT_DIR)
    for rel, min_b in ((LIGHTNING_HIGH, 50_000), (LIGHTNING_LOW, 50_000)):
        if not file_ok(base / rel, min_b):
            out.append(rel)
    return out


def write_layout(root: Path | None = None, *, repo: Path | None = None) -> Path:
    base = root or wan_model_root()
    base.mkdir(parents=True, exist_ok=True)
    loras_dir = base / "loras"
    loras_dir.mkdir(parents=True, exist_ok=True)
    lightning_high = base / LIGHTNING_HIGH
    lightning_low = base / LIGHTNING_LOW

    layout: dict[str, Any] = {
        "executor": "native",
        "model_key": "wan2",
        "task": I2V_TASK,
        "model_root": str(base),
        "wan_repo": str(repo or wan_repo_root()),
        "i2v_checkpoint": str(i2v_checkpoint_dir(base)),
        "t2v_checkpoint": str(t2v_checkpoint_dir(base)),
        "lightning_high": str(lightning_high),
        "lightning_low": str(lightning_low),
        "user_loras_dir": str(loras_dir),
        "sample_steps": 4,
        "sample_shift": 5.0,
        "guide_scale": [1.4, 1.4],
        "fps": 16,
    }
    dest = base / LAYOUT_FILE
    dest.write_text(json.dumps(layout, indent=2), encoding="utf-8")
    return dest


def load_layout(root: Path | None = None) -> dict[str, Any] | None:
    base = root or wan_model_root()
    path = base / LAYOUT_FILE
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def vram_gb() -> float:
    try:
        import torch

        if torch.cuda.is_available():
            return torch.cuda.get_device_properties(0).total_memory / (1024**3)
    except Exception:
        pass
    return 0.0


def prefer_offload_during_generate() -> bool:
    """Offload inactive MoE expert during sampling on <=48GB GPUs."""
    gb = vram_gb()
    return gb <= 0 or gb <= 48


def prefer_warm_pipeline() -> bool:
    """Keep pipeline loaded between jobs when VRAM allows."""
    return os.environ.get("LOBO_UNLOAD_MODELS", "0").strip().lower() not in ("1", "true", "yes")
