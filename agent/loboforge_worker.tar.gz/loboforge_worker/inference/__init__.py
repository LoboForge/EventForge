"""Native inference runners (no ComfyUI)."""
