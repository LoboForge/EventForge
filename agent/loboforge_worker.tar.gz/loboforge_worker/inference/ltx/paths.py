"""Model paths for native LTX 2.3 — distilled-1.1 checkpoint + audio/video VAEs."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .gemma import GEMMA_HF_REPO, GEMMA_HF_SUBDIR, hf_gemma_ready, resolve_native_gemma_root

DEFAULT_LTX_MODEL_ROOT = Path("/workspace/ltx-models")
DEFAULT_LTX_REPO = Path("/workspace/LTX-2")
LAYOUT_FILE = "layout.json"

# Legacy dev checkpoints — not provisioned on native fleet (distilled-only).
FP8_CHECKPOINT_REL = "checkpoints/ltx-2.3-22b-dev-fp8.safetensors"
BF16_CHECKPOINT_REL = "checkpoints/ltx-2.3-22b-dev.safetensors"
DISTILLED_CHECKPOINT_REL = "checkpoints/ltx-2.3-22b-distilled-1.1.safetensors"
FP8_CHECKPOINT_MIN = 1_000_000_000
BF16_CHECKPOINT_MIN = 10_000_000_000
DISTILLED_CHECKPOINT_MIN = 5_000_000_000

SHARED_REQUIRED = (
    ("vae/LTX23_audio_vae_bf16.safetensors", 100_000_000),
    ("vae/LTX23_video_vae_bf16.safetensors", 100_000_000),
    ("latent_upscale_models/ltx-2.3-spatial-upscaler-x2-1.1.safetensors", 10_000_000),
)
DISTILLED_LORA_REL = "loras/ltx-2.3-22b-distilled-lora-384.safetensors"

DEV_CHECKPOINT_RELS = frozenset({FP8_CHECKPOINT_REL, BF16_CHECKPOINT_REL})


def use_distilled_checkpoint() -> bool:
    """Native fleet uses distilled-1.1 only unless LOBO_LTX_VARIANT=dev|fp8|bf16."""
    v = os.environ.get("LOBO_LTX_VARIANT", "distilled").strip().lower()
    return v not in ("dev", "fp8", "bf16", "full")


def ltx_model_root() -> Path:
    raw = os.environ.get("LTX_MODEL_ROOT", "").strip()
    return Path(raw) if raw else DEFAULT_LTX_MODEL_ROOT


def ltx_repo_root() -> Path:
    raw = os.environ.get("LTX_REPO", "").strip()
    return Path(raw) if raw else DEFAULT_LTX_REPO


def file_ok(path: Path, min_bytes: int) -> bool:
    try:
        return path.is_file() and path.stat().st_size >= min_bytes
    except OSError:
        return False


def native_ltx_fp8_kernels_supported() -> bool:
    """Whether fp8e4nv kernels work (Ada/Hopper). Informational only for distilled fleet."""
    try:
        import torch

        if not torch.cuda.is_available():
            return False
        major, minor = torch.cuda.get_device_capability(0)
        return major > 8 or (major == 8 and minor >= 9)
    except Exception:
        return False


def resolve_native_checkpoint(base: Path | None = None) -> tuple[str, int, str]:
    """Return (relative_path, min_bytes, precision label) for this box."""
    if use_distilled_checkpoint():
        return DISTILLED_CHECKPOINT_REL, DISTILLED_CHECKPOINT_MIN, "distilled"
    root = base or ltx_model_root()
    if native_ltx_fp8_kernels_supported() and file_ok(root / FP8_CHECKPOINT_REL, FP8_CHECKPOINT_MIN):
        return FP8_CHECKPOINT_REL, FP8_CHECKPOINT_MIN, "fp8"
    if file_ok(root / BF16_CHECKPOINT_REL, BF16_CHECKPOINT_MIN):
        return BF16_CHECKPOINT_REL, BF16_CHECKPOINT_MIN, "bf16"
    if native_ltx_fp8_kernels_supported():
        return FP8_CHECKPOINT_REL, FP8_CHECKPOINT_MIN, "fp8"
    return BF16_CHECKPOINT_REL, BF16_CHECKPOINT_MIN, "bf16"


def missing_artifacts(root: Path | None = None) -> list[str]:
    base = root or ltx_model_root()
    out: list[str] = []
    for rel, min_b in SHARED_REQUIRED:
        if not file_ok(base / rel, min_b):
            out.append(rel)
    if not use_distilled_checkpoint():
        if not file_ok(base / DISTILLED_LORA_REL, 100_000_000):
            out.append(DISTILLED_LORA_REL)
    ckpt_rel, ckpt_min, _ = resolve_native_checkpoint(base)
    if not file_ok(base / ckpt_rel, ckpt_min):
        out.append(ckpt_rel)
    if not hf_gemma_ready(base):
        out.append(f"{GEMMA_HF_SUBDIR}/config.json + model*.safetensors")
    return out


def write_layout(root: Path | None = None, *, repo: Path | None = None) -> Path:
    """Persist resolved paths for the native runner process."""
    base = root or ltx_model_root()
    base.mkdir(parents=True, exist_ok=True)
    loras_dir = base / "loras"
    loras_dir.mkdir(parents=True, exist_ok=True)

    gemma_root, gemma_err = resolve_native_gemma_root(base)
    if gemma_root is None:
        raise RuntimeError(gemma_err or "HF Gemma not provisioned")

    ckpt_rel, _, precision = resolve_native_checkpoint(base)
    ckpt_path = base / ckpt_rel

    layout: dict[str, Any] = {
        "executor": "native",
        "model_key": "ltx23-fp8",
        "precision": precision,
        "audio": True,
        "model_root": str(base),
        "ltx_repo": str(repo or ltx_repo_root()),
        "checkpoint": str(ckpt_path),
        "distilled_lora": str(base / DISTILLED_LORA_REL),
        "spatial_upsampler": str(base / "latent_upscale_models/ltx-2.3-spatial-upscaler-x2-1.1.safetensors"),
        "gemma": str(gemma_root),
        "gemma_root": str(gemma_root),
        "gemma_repo": GEMMA_HF_REPO,
        "audio_vae": str(base / "vae/LTX23_audio_vae_bf16.safetensors"),
        "video_vae": str(base / "vae/LTX23_video_vae_bf16.safetensors"),
        "user_loras_dir": str(loras_dir),
    }
    dest = base / LAYOUT_FILE
    dest.write_text(json.dumps(layout, indent=2), encoding="utf-8")
    return dest


def load_layout(root: Path | None = None) -> dict[str, Any] | None:
    base = root or ltx_model_root()
    path = base / LAYOUT_FILE
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
