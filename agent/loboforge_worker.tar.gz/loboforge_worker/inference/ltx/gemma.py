"""Gemma text-encoder layout helpers for native ltx-pipelines."""

from __future__ import annotations

from pathlib import Path

GEMMA_HF_REPO = "google/gemma-3-12b-it-qat-q4_0-unquantized"
GEMMA_HF_SUBDIR = "text_encoders/gemma-hf"
COMFY_GEMMA_NAME = "gemma_3_12B_it_fp4_mixed.safetensors"

# ltx-pipelines + transformers expect HF keys (language_model.model.*), not Comfy model.layers.* FP4.
COMFY_GEMMA_INCOMPATIBLE = (
    "Native LTX requires HuggingFace-format Gemma ({repo}), not the Comfy FP4 file "
    "({comfy}). ComfyUI loads FP4 via custom ops; ltx-pipelines does not."
)


def gemma_hf_dir(base: Path) -> Path:
    return base / GEMMA_HF_SUBDIR


def hf_gemma_ready(base: Path) -> bool:
    """True when the HF Gemma tree has config + at least one weight shard."""
    root = gemma_hf_dir(base)
    if not (root / "config.json").is_file():
        return False
    return any(root.glob("model*.safetensors"))


def is_comfy_gemma_checkpoint(path: Path) -> bool:
    """Detect Comfy-Org single-file FP4 layout (uint8 weights + comfy_quant siblings)."""
    if not path.is_file():
        return False
    try:
        from safetensors import safe_open

        with safe_open(str(path), framework="pt") as f:
            keys = list(f.keys())
            if not keys:
                return False
            if any(k.startswith("language_model.model.") for k in keys):
                return False
            if any("comfy_quant" in k for k in keys):
                return True
            sample = keys[0]
            if sample.startswith("model.layers.") or sample.startswith("vision_model."):
                return True
    except Exception:
        return path.name == COMFY_GEMMA_NAME
    return False


def resolve_native_gemma_root(base: Path) -> tuple[Path | None, str | None]:
    """
    Return (gemma_root, error).
    Prefer the HF model directory; reject Comfy-only layouts.
    """
    hf = gemma_hf_dir(base)
    if hf_gemma_ready(base):
        return hf, None

    comfy = base / "text_encoders" / COMFY_GEMMA_NAME
    if comfy.is_file():
        return None, COMFY_GEMMA_INCOMPATIBLE.format(repo=GEMMA_HF_REPO, comfy=COMFY_GEMMA_NAME)

    return None, (
        f"HF Gemma missing under {hf} — run provision or: "
        f"hf download {GEMMA_HF_REPO} --local-dir {hf}"
    )
