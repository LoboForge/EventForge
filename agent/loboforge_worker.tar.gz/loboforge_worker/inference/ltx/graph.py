"""Extract native LTX job parameters from Comfy workflow graphs."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

log = logging.getLogger("worker.ltx.graph")


def _node_title(node: dict) -> str:
    meta = node.get("_meta")
    if isinstance(meta, dict):
        return str(meta.get("title") or "")
    return ""


def _resolve_primitive_value(graph: dict, ref: Any, default: int | float) -> int | float:
    if isinstance(ref, (int, float)):
        return ref
    if not isinstance(ref, list) or not ref:
        return default
    nid = str(ref[0])
    node = graph.get(nid)
    if not isinstance(node, dict):
        return default
    val = (node.get("inputs") or {}).get("value")
    if isinstance(val, (int, float)):
        return val
    return default


def normalize_num_frames(raw: int) -> int:
    """LTX expects num_frames = (8 * K) + 1."""
    if raw < 1:
        return 121
    k = (raw - 1) // 8
    normalized = 8 * k + 1
    if normalized != raw:
        log.info("Adjusted num_frames %s -> %s (8K+1 rule)", raw, normalized)
    return normalized


def snap_dimension(value: int, *, multiple: int = 64, minimum: int = 64) -> int:
    """Two-stage LTX pipelines require width/height divisible by 64."""
    if value < minimum:
        return minimum
    snapped = (value // multiple) * multiple
    if snapped != value:
        log.info("Adjusted dimension %s -> %s (multiple of %s)", value, snapped, multiple)
    return max(snapped, minimum)


def _primitive_int(graph: dict, node_id: str, default: int) -> int:
    node = graph.get(node_id)
    if not isinstance(node, dict):
        return default
    val = (node.get("inputs") or {}).get("value")
    if isinstance(val, bool):
        return default
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


def _primitive_string(graph: dict, node_id: str, default: str = "") -> str:
    node = graph.get(node_id)
    if not isinstance(node, dict):
        return default
    return str((node.get("inputs") or {}).get("value") or default).strip()


# Official LTX 2.3 t2v template node ids (see Templates/ltx23_t2v.json).
_LTX_TEMPLATE_NODES = {
    "prompt": "267:266",
    "negative": "267:247",
    "width": "267:257",
    "height": "267:258",
    "frame_rate": "267:260",
    "duration": "267:225",
    "start_image": "267:325",
}


def extract_native_ltx_params(graph: dict) -> dict[str, Any]:
    """Parse prompt/resolution/timing from the server LTX Comfy graph template."""
    prompt = ""
    negative = ""
    width = 1280
    height = 704
    frame_rate = 25.0
    duration_sec = 5
    seed = 42
    num_frames = 121

    duration_ref: Any = None
    fps_ref: Any = None

    for node in graph.values():
        if not isinstance(node, dict):
            continue
        ct = node.get("class_type", "")
        title = _node_title(node)
        inputs = node.get("inputs") or {}

        if ct == "PrimitiveStringMultiline" and title == "Prompt":
            prompt = str(inputs.get("value") or "").strip()

        if ct == "PrimitiveInt":
            if title == "Width":
                width = int(inputs.get("value", width))
            elif title == "Height":
                height = int(inputs.get("value", height))
            elif title == "Frame Rate":
                frame_rate = float(inputs.get("value", frame_rate))
            elif title == "Duration":
                duration_sec = int(inputs.get("value", duration_sec))

        if ct == "CLIPTextEncode":
            text = inputs.get("text")
            if isinstance(text, str) and text.strip():
                negative = text.strip()
            elif isinstance(text, list) and text:
                ref = str(text[0])
                ref_node = graph.get(ref)
                if isinstance(ref_node, dict) and ref_node.get("class_type") == "PrimitiveStringMultiline":
                    prompt = str((ref_node.get("inputs") or {}).get("value") or prompt).strip()

        if ct == "ComfyMathExpression":
            expr = str(inputs.get("expression") or "").replace(" ", "")
            if expr == "a*b+1":
                duration_ref = inputs.get("values.a")
                fps_ref = inputs.get("values.b")

        if ct == "RandomNoise" and "noise_seed" in inputs and seed == 42:
            try:
                seed = int(inputs["noise_seed"])
            except (TypeError, ValueError):
                pass

    if duration_ref is not None and fps_ref is not None:
        dur = _resolve_primitive_value(graph, duration_ref, duration_sec)
        fps = _resolve_primitive_value(graph, fps_ref, frame_rate)
        try:
            num_frames = normalize_num_frames(int(float(dur) * float(fps) + 1))
        except (TypeError, ValueError):
            num_frames = normalize_num_frames(int(duration_sec * frame_rate + 1))
    else:
        num_frames = normalize_num_frames(int(duration_sec * frame_rate + 1))

    # Server JSON omits Comfy _meta titles — read canonical template node ids directly.
    tpl = _LTX_TEMPLATE_NODES
    tpl_prompt = _primitive_string(graph, tpl["prompt"])
    if tpl_prompt:
        prompt = tpl_prompt
    if tpl["width"] in graph:
        width = _primitive_int(graph, tpl["width"], width)
    if tpl["height"] in graph:
        height = _primitive_int(graph, tpl["height"], height)
    if tpl["frame_rate"] in graph:
        tpl_fps = _primitive_int(graph, tpl["frame_rate"], int(frame_rate))
        if tpl_fps > 0:
            frame_rate = float(tpl_fps)
    if tpl["duration"] in graph and duration_ref is None:
        tpl_duration = _primitive_int(graph, tpl["duration"], duration_sec)
        if tpl_duration > 0:
            duration_sec = tpl_duration
            num_frames = normalize_num_frames(int(duration_sec * frame_rate + 1))

    neg_node = graph.get(tpl["negative"])
    if isinstance(neg_node, dict) and neg_node.get("class_type") == "CLIPTextEncode":
        text = (neg_node.get("inputs") or {}).get("text")
        if isinstance(text, str) and text.strip():
            negative = text.strip()

    width = snap_dimension(int(width))
    height = snap_dimension(int(height))

    return {
        "prompt": prompt or "cinematic video",
        "negative_prompt": negative,
        "width": width,
        "height": height,
        "num_frames": num_frames,
        "frame_rate": float(frame_rate),
        "seed": int(seed),
    }


def extract_native_ltx_conditioning_image(graph: dict) -> str | None:
    """Return a local filesystem path for i2v start-frame conditioning, if patched."""
    node_id = _LTX_TEMPLATE_NODES["start_image"]
    node = graph.get(node_id)
    if not isinstance(node, dict):
        return None
    if node.get("class_type") == "EmptyImage":
        return None
    if node.get("class_type") != "LoadImage":
        return None

    img = (node.get("inputs") or {}).get("image")
    if not isinstance(img, str):
        return None
    img = img.strip()
    if not img or img.startswith("ref_"):
        return None

    path = Path(img)
    if path.is_file():
        return str(path)

    for base in (Path("/tmp/lobo-ref-images"), Path("input")):
        candidate = base / img
        if candidate.is_file():
            return str(candidate)
    return None


_BUILTIN_LTX_LORA_MARKERS = (
    "distilled-lora-384",
    "ltx-2.3-22b-distilled-lora",
)


def extract_native_ltx_loras(graph: dict, model_root: str | Path) -> list[dict[str, Any]]:
    """User LoRAs from LoraLoaderModelOnly nodes — skips built-in distilled LoRA."""
    root = Path(model_root)
    loras_dir = root / "loras"
    out: list[dict[str, Any]] = []
    seen: set[str] = set()

    for node in graph.values():
        if not isinstance(node, dict) or node.get("class_type") != "LoraLoaderModelOnly":
            continue
        inputs = node.get("inputs") or {}
        raw_name = str(inputs.get("lora_name") or "").strip()
        if not raw_name:
            continue
        lower = raw_name.lower()
        if any(m in lower for m in _BUILTIN_LTX_LORA_MARKERS):
            continue
        try:
            strength = float(inputs.get("strength_model", 1.0))
        except (TypeError, ValueError):
            strength = 1.0

        basename = Path(raw_name.replace("\\", "/")).name
        if not basename or basename in seen:
            continue
        seen.add(basename)

        candidates = [
            root / raw_name,
            root / raw_name.lstrip("/"),
            loras_dir / basename,
            Path(raw_name) if Path(raw_name).is_absolute() else None,
        ]
        resolved = next((p for p in candidates if p is not None and p.is_file()), None)
        if resolved is None:
            log.warning("Native LTX: LoRA not on disk — %s (tried %s)", raw_name, loras_dir / basename)
            continue
        out.append({"path": str(resolved), "strength": strength, "name": basename})
    return out
