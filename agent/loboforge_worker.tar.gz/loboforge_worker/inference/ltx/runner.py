"""Native LTX 2.3 inference via Lightricks ltx-pipelines (no ComfyUI)."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable

from .gemma import resolve_native_gemma_root
from .graph import extract_native_ltx_conditioning_image, extract_native_ltx_loras, extract_native_ltx_params
from .paths import (
    BF16_CHECKPOINT_REL,
    load_layout,
    ltx_repo_root,
    missing_artifacts,
    native_ltx_fp8_kernels_supported,
)

log = logging.getLogger("worker.ltx.runner")


def _ensure_ltx_imports(layout: dict[str, Any]) -> None:
    repo = Path(layout.get("ltx_repo") or ltx_repo_root())
    for sub in ("ltx-core/src", "ltx-pipelines/src"):
        src = repo / "packages" / sub
        if src.is_dir():
            s = str(src)
            if s not in sys.path:
                sys.path.insert(0, s)
    _patch_ltx_runtime()


def _patch_ltx_runtime() -> None:
    """Work around transformers 5.2 + Blackwell (sm_120) gaps in upstream ltx-core."""
    if getattr(_patch_ltx_runtime, "_done", False):
        return

    import ltx_core.text_encoders.gemma.encoders.encoder_configurator as ec

    # transformers 5.x still nests SiglipVisionModel.vision_model; v5 key remap drops it.
    ops = ec._build_gemma_llm_key_ops(transformers_v5=False)
    ec.GEMMA_LLM_KEY_OPS = ops
    import ltx_core.text_encoders.gemma as g

    g.GEMMA_LLM_KEY_OPS = ops

    try:
        import torch
        from ltx_core.model.transformer import attention as attn

        if torch.cuda.is_available():
            major = torch.cuda.get_device_capability(0)[0]
            # xFormers bf16 masked attention needs sm_80+; Blackwell (sm_120) also rejects xFormers.
            if major >= 10 or major < 8:
                attn.memory_efficient_attention = None
                attn._select_masked_attention = attn._sdpa_full_priority
                attn._select_primary_attention = attn._sdpa_full_priority
                attn.automatic_masked_attention.cache_clear()
                attn.automatic_attention.cache_clear()
                log.info("Native LTX: xFormers disabled, attention via SDPA (sm_%d0)", major)
    except Exception as ex:
        log.debug("LTX attention patch skipped: %s", ex)

    # FP8 checkpoints ship *_scale / input_scale siblings that are folded at load time.
    # Block streaming scans keys via apply_to_key (no kv-ops), so scale-only names must
    # be filtered or pinned-source build raises KeyError on to_gate_logits.input_scale.
    try:
        import ltx_core.block_streaming.builder as block_builder

        if not getattr(block_builder, "_loboforge_scan_patch", False):
            _orig_scan = block_builder._scan_checkpoint_keys

            def _scan_without_scale_keys(paths, sd_ops, blocks_prefix):
                block_key_map, non_block_keys = _orig_scan(paths, sd_ops, blocks_prefix)
                cleaned: dict[int, list[tuple[str, str]]] = {}
                for idx, entries in block_key_map.items():
                    cleaned[idx] = [
                        (sft_key, param_name)
                        for sft_key, param_name in entries
                        if not (param_name.endswith("_scale") or param_name.endswith(".input_scale"))
                    ]
                return cleaned, non_block_keys

            block_builder._scan_checkpoint_keys = _scan_without_scale_keys
            block_builder._loboforge_scan_patch = True  # type: ignore[attr-defined]
    except Exception as ex:
        log.debug("LTX block-streaming scan patch skipped: %s", ex)

    # CPU offload pins all transformer blocks (~36 GB RAM). On 24 GB VRAM boxes we still
    # need Gemma CPU streaming, but the diffusion transformer should use disk slots.
    try:
        from ltx_core.block_streaming import DISK_CPU_SLOTS
        from ltx_pipelines.utils import blocks as pipe_blocks

        if not getattr(pipe_blocks, "_loboforge_hybrid_stream_patch", False):
            _orig_streaming = pipe_blocks._streaming_model

            @contextmanager
            def _hybrid_streaming(builder, offload_mode, target_device, dtype):
                if getattr(builder, "blocks_prefix", "") == "transformer_blocks":
                    wrapped = builder.build(
                        target_device=target_device,
                        dtype=dtype,
                        cpu_slots_count=DISK_CPU_SLOTS,
                    )
                    try:
                        yield wrapped
                    finally:
                        wrapped.teardown()
                        wrapped.to("meta")
                        pipe_blocks.cleanup_memory()
                else:
                    with _orig_streaming(builder, offload_mode, target_device, dtype) as wrapped:
                        yield wrapped

            pipe_blocks._streaming_model = _hybrid_streaming
            pipe_blocks._loboforge_hybrid_stream_patch = True  # type: ignore[attr-defined]
    except Exception as ex:
        log.debug("LTX hybrid streaming patch skipped: %s", ex)

    _patch_ltx_runtime._done = True  # type: ignore[attr-defined]


def _layout_ready(layout: dict[str, Any] | None) -> tuple[dict[str, Any], str | None]:
    if not layout:
        return {}, "layout.json missing — native LTX not provisioned"
    root = Path(layout.get("model_root") or "/workspace/ltx-models")
    miss = missing_artifacts(root)
    if miss:
        return layout, f"native LTX artifacts missing: {', '.join(miss[:3])}"
    for key in ("checkpoint", "spatial_upsampler"):
        if not Path(str(layout.get(key) or "")).is_file():
            return layout, f"layout path missing: {key}"
    ckpt_name = Path(str(layout.get("checkpoint") or "")).name.lower()
    needs_distilled_lora = not ("distilled" in ckpt_name and "lora" not in ckpt_name)
    if needs_distilled_lora and not Path(str(layout.get("distilled_lora") or "")).is_file():
        return layout, "layout path missing: distilled_lora"
    gemma_root, gemma_err = resolve_native_gemma_root(root)
    if gemma_root is None:
        return layout, gemma_err or "HF Gemma text encoder not ready"
    layout = {**layout, "gemma_root": str(gemma_root), "gemma": str(gemma_root)}
    return layout, None


def _offload_mode_for_vram():
    """Stream weights on <=26GB GPUs — full model + Gemma do not fit in VRAM."""
    try:
        import torch
        from ltx_pipelines.utils.types import OffloadMode

        if torch.cuda.is_available():
            total_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
            if total_gb <= 26:
                log.info("Native LTX: layer streaming enabled (%.1f GB VRAM)", total_gb)
                return OffloadMode.CPU
        return OffloadMode.NONE
    except Exception:
        return None


def _quantization_for_checkpoint(checkpoint_path: str):
    """FP8 safetensors need fp8_cast folding on Ada+; bf16 checkpoints run without quantization."""
    name = Path(checkpoint_path).name.lower()
    if "fp8" not in name:
        return None
    if not native_ltx_fp8_kernels_supported():
        log.warning(
            "Native LTX: FP8 checkpoint on Ampere — use %s instead",
            BF16_CHECKPOINT_REL,
        )
        return None
    try:
        from ltx_pipelines.utils.quantization_factory import QuantizationKind

        return QuantizationKind.FP8_CAST.to_policy(checkpoint_path)
    except Exception as ex:
        log.warning("Native LTX: quantization policy detection failed: %s", ex)
    return None


def run_native_ltx_sync(
    graph: dict,
    layout: dict[str, Any],
    output_path: Path,
    *,
    on_progress: Callable[[int, int], None] | None = None,
) -> Path:
    """Blocking GPU inference — call from a thread pool."""
    _ensure_ltx_imports(layout)

    import torch
    from ltx_core.loader import LTXV_LORA_COMFY_RENAMING_MAP, LoraPathStrengthAndSDOps
    from ltx_core.model.video_vae import TilingConfig, get_video_chunks_number
    from ltx_pipelines.distilled import DistilledPipeline
    from ltx_pipelines.utils.args import ImageConditioningInput
    from ltx_pipelines.utils.media_io import encode_video

    params = extract_native_ltx_params(graph)
    log.info(
        "Native LTX: %dx%d %d frames @ %.1ffps seed=%s prompt=%r",
        params["width"],
        params["height"],
        params["num_frames"],
        params["frame_rate"],
        params["seed"],
        (params["prompt"][:80] + "…") if len(params["prompt"]) > 80 else params["prompt"],
    )

    if on_progress:
        on_progress(1, 100)

    gemma_root = layout["gemma_root"]
    checkpoint = str(layout["checkpoint"])
    offload = _offload_mode_for_vram()
    quantization = _quantization_for_checkpoint(checkpoint)
    ckpt_name = Path(checkpoint).name.lower()
    loras: list[Any] = []
    if not ("distilled" in ckpt_name and "lora" not in ckpt_name):
        loras.append(
            LoraPathStrengthAndSDOps(
                str(layout["distilled_lora"]),
                1.0,
                LTXV_LORA_COMFY_RENAMING_MAP,
            )
        )
    root = Path(str(layout.get("model_root") or "/workspace/ltx-models"))
    user_entries = extract_native_ltx_loras(graph, root)
    for entry in user_entries:
        loras.append(
            LoraPathStrengthAndSDOps(
                entry["path"],
                float(entry["strength"]),
                LTXV_LORA_COMFY_RENAMING_MAP,
            )
        )
    if user_entries:
        log.info(
            "Native LTX: user LoRAs (%d) — %s",
            len(user_entries),
            ", ".join(f"{e['name']}@{e['strength']}" for e in user_entries),
        )

    pipeline_kwargs: dict[str, Any] = {
        "distilled_checkpoint_path": checkpoint,
        "gemma_root": str(gemma_root),
        "spatial_upsampler_path": str(layout["spatial_upsampler"]),
        "loras": loras,
    }
    if offload is not None:
        pipeline_kwargs["offload_mode"] = offload
    if quantization is not None:
        pipeline_kwargs["quantization"] = quantization
    pipeline = DistilledPipeline(**pipeline_kwargs)

    if on_progress:
        on_progress(5, 100)

    tiling_config = TilingConfig.default()
    video_chunks_number = get_video_chunks_number(params["num_frames"], tiling_config)

    conditioning_path = extract_native_ltx_conditioning_image(graph)
    images: list[Any] = []
    if conditioning_path:
        images = [ImageConditioningInput(path=conditioning_path, frame_idx=0, strength=1.0, crf=33)]
        log.info("Native LTX i2v: conditioning on %s", conditioning_path)

    # no_grad (not inference_mode): block-streaming + VAE tiled decode fail with
    # "Inference tensors do not track version counter" under inference_mode.
    with torch.no_grad():
        video, audio = pipeline(
            prompt=params["prompt"],
            seed=params["seed"],
            height=params["height"],
            width=params["width"],
            num_frames=params["num_frames"],
            frame_rate=params["frame_rate"],
            images=images,
            tiling_config=tiling_config,
        )

    if on_progress:
        on_progress(90, 100)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with torch.no_grad():
        encode_video(
            video=video,
            fps=params["frame_rate"],
            audio=audio,
            output_path=str(output_path),
            video_chunks_number=video_chunks_number,
        )

    if on_progress:
        on_progress(100, 100)

    return output_path


async def run_native_ltx_job(
    graph: dict,
    *,
    on_progress: Callable[[int, int], None] | None = None,
    on_activity: Callable[[], None] | None = None,
) -> tuple[bytes, str] | None:
    """
    Run native LTX generation asynchronously.
    Returns (file_bytes, filename) or None on failure.
    """
    layout, err = _layout_ready(load_layout())
    if err:
        raise RuntimeError(err)
    ckpt = Path(str(layout.get("checkpoint") or ""))
    if ckpt.name.lower().endswith("-fp8.safetensors") and not native_ltx_fp8_kernels_supported():
        bf16 = ckpt.parent / Path(BF16_CHECKPOINT_REL).name
        if bf16.is_file():
            layout = {**layout, "checkpoint": str(bf16), "precision": "bf16"}
        else:
            raise RuntimeError(
                f"Ampere GPU needs bf16 checkpoint {BF16_CHECKPOINT_REL} — provision still downloading"
            )

    tick_task: asyncio.Task | None = None
    if on_activity:
        async def _tick() -> None:
            while True:
                await asyncio.sleep(30)
                try:
                    on_activity()
                except Exception:
                    break

        tick_task = asyncio.create_task(_tick())

    loop = asyncio.get_running_loop()

    try:
        with tempfile.TemporaryDirectory(prefix="lobo-ltx-") as tmp:
            out = Path(tmp) / "output.mp4"

            def _progress(step: int, total: int) -> None:
                if not on_progress:
                    return
                try:
                    result = on_progress(step, total)
                    if asyncio.iscoroutine(result):
                        asyncio.run_coroutine_threadsafe(result, loop).result(timeout=10)
                except Exception:
                    pass

            await asyncio.to_thread(run_native_ltx_sync, graph, layout, out, on_progress=_progress)
            if not out.is_file() or out.stat().st_size < 1000:
                raise RuntimeError("native LTX produced no output video")
            return out.read_bytes(), out.name
    finally:
        if tick_task:
            tick_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await tick_task
