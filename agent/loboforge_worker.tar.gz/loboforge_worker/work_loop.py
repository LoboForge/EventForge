"""LoRA prefetch loop — HTTP/WS request-work returns download_lora or empty only (never assign_job)."""

from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path
from typing import Any

from .models_sync import refresh_and_push

log = logging.getLogger("worker.work_loop")


class LoraPrefetchLoop:
    """Idle-time LoRA prefetch only. Gen jobs come from forge-queue SQS, not the API."""

    def __init__(
        self,
        session: Any,
        args: Any,
        agent_state: dict,
        *,
        download_model,
        get_vram_free,
        get_disk_free_mb,
    ) -> None:
        self.session = session
        self.args = args
        self.state = agent_state
        self._download_model = download_model
        self._get_vram_free = get_vram_free
        self._get_disk_free_mb = get_disk_free_mb

    async def run_forever(self) -> None:
        empty_backoff = 2.0
        while True:
            if self.state.get("current_job") is not None:
                await asyncio.sleep(1.0)
                continue
            if self.session.waiting:
                await asyncio.sleep(0.5)
                continue
            try:
                await self.session.send_json({
                    "type": "request_work",
                    "node_uuid": self.args.node_uuid,
                    "hostname": self.args.hostname,
                    "vram_free": self._get_vram_free(),
                    "disk_free_mb": self._get_disk_free_mb(),
                    "known_loras": self.state.get("known_loras", []),
                })
                msg = await self.session.wait_response({"download_lora", "empty"}, 120.0)
            except asyncio.TimeoutError:
                continue
            except Exception as ex:
                log.warning("request_work failed: %s", ex)
                await asyncio.sleep(empty_backoff)
                empty_backoff = min(empty_backoff * 1.5, 15.0)
                continue

            empty_backoff = 2.0
            mtype = msg.get("type", "")

            if mtype == "empty":
                await asyncio.sleep(empty_backoff)
                continue

            if mtype == "download_lora":
                await self._handle_prefetch(msg)
                continue

            if mtype == "assign_job":
                log.error("request-work returned assign_job — ignored (jobs are SQS-only)")

    async def _handle_prefetch(self, msg: dict) -> None:
        await self._download_model(self.session.ws, msg, self.args)
        await refresh_and_push(self.session, self.args, self.state)
        basename = msg.get("lora_basename") or Path(msg.get("dest_path", "")).name
        if basename:
            known = self.state.setdefault("known_loras", [])
            if basename not in known:
                known.append(basename)


# Back-compat alias — old imports only; never returns assign_job.
PullWorkLoop = LoraPrefetchLoop
