"""Self-healing health supervisor — Comfy, disk, LoRA inventory, stuck jobs."""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from .models_sync import refresh_and_push

log = logging.getLogger("worker.health")

COMFY_INTERVAL = 30
LORA_SYNC_INTERVAL = 600
STUCK_NO_START_SEC = 90
STUCK_CANARY_SEC = 240


class HealthSupervisor:
    def __init__(
        self,
        session: Any,
        args: Any,
        agent_state: dict,
        provision: Any,
        *,
        comfy_is_healthy,
        ensure_comfyui_running,
        maybe_free_comfy_disk,
        model_count,
    ) -> None:
        self.session = session
        self.args = args
        self.state = agent_state
        self.provision = provision
        self._comfy_is_healthy = comfy_is_healthy
        self._ensure_comfyui_running = ensure_comfyui_running
        self._maybe_free_comfy_disk = maybe_free_comfy_disk
        self._model_count = model_count
        self._last_disk_mb = -1

    def _mode(self) -> str:
        if self.provision:
            return self.provision.state.mode
        hn = (getattr(self.args, "hostname", "") or "").lower()
        if "video" in hn:
            return "video"
        if "image" in hn:
            return "image"
        return "all"

    async def run_forever(self) -> None:
        tick = 0
        while True:
            await asyncio.sleep(COMFY_INTERVAL)
            tick += 1
            busy = self.state.get("current_job") is not None
            if busy:
                await self._maybe_clear_stuck_job()

            from loboforge_agent import get_disk_free_mb  # type: ignore
            disk_mb = get_disk_free_mb()
            if not busy or disk_mb < 2048:
                before = getattr(self, "_last_disk_mb", -1)
                self._maybe_free_comfy_disk(self.args)
                after = get_disk_free_mb()
                self._last_disk_mb = after
                if before >= 0 and before < 2048 and after >= 2048:
                    from .protocol import worker_event
                    log.info("Disk recovered (%sMB → %sMB) — notifying server", before, after)
                    await self.session.send_json(worker_event("disk.recovered", {
                        "disk_free_mb_before": before,
                        "disk_free_mb_after": after,
                    }))

            healthy = await self._comfy_is_healthy(self.args.comfyui_http)
            if not healthy:
                if busy:
                    await self._maybe_clear_stuck_job(force_comfy_restart=True)
                    log.warning("ComfyUI unhealthy during active job — clearing hold + restarting")
                    if not await self._ensure_comfyui_running(self.args):
                        continue
                elif not await self._ensure_comfyui_running(self.args):
                    continue
                healthy = True

            if self.state.pop("comfy_needs_restart", False) and not self.state.get("current_job"):
                await self._ensure_comfyui_running(self.args)

            if healthy and not busy:
                await self._ensure_power_lora_loader()

            if healthy and not busy and self._model_count(self.state.get("models", {})) == 0:
                try:
                    await refresh_and_push(self.session, self.args, self.state)
                except Exception as ex:
                    log.warning("models refresh failed: %s", ex)

            if not busy and tick * COMFY_INTERVAL >= LORA_SYNC_INTERVAL:
                tick = 0
                await self._maybe_sync_loras()

    async def _maybe_clear_stuck_job(self, *, force_comfy_restart: bool = False) -> None:
        """Release agent busy latch when a job never started Comfy or hung mid-run."""
        job_id = self.state.get("current_job")
        since = self.state.get("current_job_since")
        if not job_id or since is None:
            return

        elapsed = time.time() - float(since)
        started = bool(self.state.get("job_started"))
        is_canary = str(job_id).startswith("canary-")

        if not started and elapsed >= STUCK_NO_START_SEC:
            reason = f"Job never started on worker after {int(elapsed)}s"
        elif is_canary and elapsed >= STUCK_CANARY_SEC:
            reason = f"Canary stuck after {int(elapsed // 60)} minutes"
        elif force_comfy_restart and elapsed >= STUCK_NO_START_SEC:
            reason = "ComfyUI unhealthy during job"
        else:
            return

        log.warning("Clearing stuck job %s — %s", job_id, reason)
        try:
            await self.session.send_json({
                "type": "job_failed",
                "job_uuid": job_id,
                "reason": reason,
            })
        except Exception as ex:
            log.warning("Could not report stuck job failure: %s", ex)
        self.state["current_job"] = None
        self.state.pop("current_job_since", None)
        self.state.pop("job_started", None)

    async def _maybe_sync_loras(self) -> None:
        if not self.provision or self.provision.state.running:
            return
        mode = self._mode()
        try:
            if mode in ("video", "all", "both"):
                log.info("Periodic tool LoRA sync (mode=%s)", mode)
                await self.provision.sync_tool_loras()
            if mode in ("image", "all", "both", "video"):
                await self.provision.sync_loras(mode)
            await refresh_and_push(self.session, self.args, self.state)
            from .protocol import worker_event
            await self.session.send_json(worker_event("loras.periodic_sync", {"mode": mode}))
        except Exception as ex:
            log.warning("Periodic LoRA sync failed: %s", ex)

    async def _ensure_power_lora_loader(self) -> None:
        from .provision.custom_nodes import ensure_power_lora_loader, power_lora_loader_registered

        http = getattr(self.args, "comfyui_http", "http://127.0.0.1:18188")
        if power_lora_loader_registered(http):
            return
        result = await ensure_power_lora_loader(self.args)
        if result.get("ok"):
            log.info("Power Lora Loader registered (restarted=%s)", result.get("restarted"))
            try:
                await refresh_and_push(self.session, self.args, self.state)
            except Exception as ex:
                log.warning("models refresh after rgthree failed: %s", ex)
        else:
            log.warning("Power Lora Loader still missing: %s", result.get("error"))
