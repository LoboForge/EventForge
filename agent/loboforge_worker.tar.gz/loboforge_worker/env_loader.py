"""Load persisted fleet env from /workspace/.loboforge-env into os.environ."""

from __future__ import annotations

import os
from pathlib import Path

_LOADED = False


def load_loboforge_env(agent_dir: str | Path | None = None) -> bool:
    """
    Parse export KEY="value" lines from .loboforge-env.

    Called at agent/worker startup so Python sees LOBO_EXECUTOR=native even when
    the process was not launched from a shell that sourced the file.
    """
    global _LOADED
    root = Path(agent_dir or os.environ.get("LOBO_AGENT_DIR", "/workspace"))
    path = root / ".loboforge-env"
    if not path.is_file():
        return False

    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        val = val.strip().strip('"').strip("'")
        if key:
            os.environ[key] = val

    _LOADED = True
    return True


def ensure_loboforge_env(agent_dir: str | Path | None = None) -> None:
    if not _LOADED:
        load_loboforge_env(agent_dir)
