"""Detect native LTX executor mode (no ComfyUI)."""

from __future__ import annotations

import os

from .env_loader import ensure_loboforge_env


def _hostname_hint() -> str:
    for key in ("LOBO_HOSTNAME", "HOSTNAME"):
        val = os.environ.get(key, "").strip().lower()
        if val:
            return val
    try:
        import socket

        return socket.gethostname().strip().lower()
    except OSError:
        return ""


def is_native_ltx_hostname(hostname: str | None = None) -> bool:
    hn = (hostname or _hostname_hint()).lower()
    return hn.startswith("loboforge-ltx-") or hn.startswith("loboforge-ltx")


def is_native_wan_hostname(hostname: str | None = None) -> bool:
    hn = (hostname or _hostname_hint()).lower()
    return hn.startswith("loboforge-wan-native") or hn.startswith("loboforge-wan-")


def is_native_executor() -> bool:
    ensure_loboforge_env()
    if os.environ.get("LOBO_EXECUTOR", "").strip().lower() == "native":
        return True
    return is_native_ltx_hostname() or is_native_wan_hostname()


def is_skip_comfy() -> bool:
    return is_native_executor() or os.environ.get("LOBO_SKIP_COMFY", "").strip() == "1"
