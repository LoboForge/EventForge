"""CLI entry: python -m loboforge_worker run|bootstrap|provision|sync-loras"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

# Ensure repo root is importable when running from /workspace
_ROOT = Path(__file__).resolve().parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "provision-ltx-native":
        from loboforge_worker.provision.ltx_native import run_provision_ltx_native_cli

        raise SystemExit(run_provision_ltx_native_cli())

    if len(sys.argv) > 1 and sys.argv[1] == "provision-ollama-native":
        from loboforge_worker.provision.ollama_native import run_provision_ollama_native_cli

        raise SystemExit(run_provision_ollama_native_cli())

    parser = argparse.ArgumentParser(description="LoboForge GPU Worker")
    sub = parser.add_subparsers(dest="cmd", required=True)

    run_p = sub.add_parser("run", help="Run GPU agent (same as loboforge_agent.py)")
    run_p.add_argument("--server", default="wss://www.loboforge.com")
    run_p.add_argument("--secret", required=True)
    run_p.add_argument("--hostname", default=None)
    run_p.add_argument("--node-uuid", default=None)
    run_p.add_argument("--comfyui-http", default="http://127.0.0.1:18188")
    run_p.add_argument("--comfyui-ws", default="ws://127.0.0.1:18188")
    run_p.add_argument("--hf-token", default=os.environ.get("HF_TOKEN"))
    run_p.add_argument("--comfyui-token", default=os.environ.get("LOBO_COMFYUI_TOKEN"))
    run_p.add_argument("--debug", action="store_true")

    boot_p = sub.add_parser("bootstrap", help="Fresh Vast box: Comfy prep + agent tmux (downloads via runtime)")
    boot_p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    boot_p.add_argument("--mode", default=os.environ.get("MODE", os.environ.get("LOBO_MODE", "all")))
    boot_p.add_argument("--server", default=os.environ.get("LOBO_SERVER", "wss://www.loboforge.com"))
    boot_p.add_argument("--base-url", default=os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com"))
    boot_p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", ""))
    boot_p.add_argument("--label", default=os.environ.get("LOBO_LABEL", ""))
    boot_p.add_argument("--hf-token", default=os.environ.get("HF_TOKEN", ""))
    boot_p.add_argument("--agent-dir", default="/workspace")
    boot_p.add_argument("--comfyui-http", default=os.environ.get("LOBO_COMFYUI_HTTP", "http://127.0.0.1:18188"))
    boot_p.add_argument("--comfyui-ws", default=os.environ.get("LOBO_COMFYUI_WS", "ws://127.0.0.1:18188"))

    prov_p = sub.add_parser("provision", help="Run provision manifests once (no agent)")
    prov_p.add_argument("--secret", required=True)
    prov_p.add_argument("--mode", default="video")
    prov_p.add_argument("--hostname", default="worker")
    prov_p.add_argument("--manifest", action="append", default=[])

    lora_p = sub.add_parser("sync-loras", help="Pull active LoRAs from server")
    lora_p.add_argument("--secret", required=True)
    lora_p.add_argument("--mode", default="all")
    lora_p.add_argument("--base-url", default="https://www.loboforge.com")
    lora_p.add_argument("--include-tools", action="store_true")

    tool_lora_p = sub.add_parser("sync-tool-loras", help="Pull tool + story LoRA pairs from server")
    tool_lora_p.add_argument("--secret", required=True)
    tool_lora_p.add_argument("--base-url", default="https://www.loboforge.com")

    up_p = sub.add_parser("upgrade", help="Fetch latest agent + loboforge_worker from server")
    up_p.add_argument("--agent-dir", default="/workspace")
    up_p.add_argument("--base-url", default="https://www.loboforge.com")
    up_p.add_argument("--force-worker", action="store_true")
    up_p.add_argument("--install-deps", action="store_true")

    pre_p = sub.add_parser("preflight-gpu", help="GPU compatibility + P100 torch + hostname (no downloads)")
    pre_p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    pre_p.add_argument("--mode", default=os.environ.get("LOBO_MODE", "all"))
    pre_p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", ""))

    lens_p = sub.add_parser("ensure-lens-comfyui", help="Upgrade ComfyUI master if Lens CLIP type missing")
    lens_p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    lens_p.add_argument("--mode", default=os.environ.get("LOBO_MODE", "all"))
    lens_p.add_argument("--comfyui-http", default=os.environ.get("LOBO_COMFYUI_HTTP", "http://127.0.0.1:18188"))
    lens_p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", ""))

    ver_p = sub.add_parser("verify", help="Check loboforge_worker import + optional log line")
    ver_p.add_argument("--agent-dir", default="/workspace")
    ver_p.add_argument("--log", default="/workspace/loboforge-agent.log")

    ready_p = sub.add_parser("ready", help="Block until Comfy+GPU+models pass (same as agent startup gate)")
    ready_p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    ready_p.add_argument("--mode", default=os.environ.get("LOBO_MODE", "all"))
    ready_p.add_argument("--comfyui-http", default=os.environ.get("LOBO_COMFYUI_HTTP", "http://127.0.0.1:18188"))
    ready_p.add_argument("--max-wait", type=int, default=900)

    args = parser.parse_args()

    if args.cmd == "run":
        import loboforge_agent
        sys.argv = ["loboforge_agent.py", "--secret", args.secret, "--server", args.server,
                    "--comfyui-http", args.comfyui_http, "--comfyui-ws", args.comfyui_ws]
        if args.hostname:
            sys.argv += ["--hostname", args.hostname]
        if args.node_uuid:
            sys.argv += ["--node-uuid", args.node_uuid]
        if args.hf_token:
            sys.argv += ["--hf-token", args.hf_token]
        if args.comfyui_token:
            sys.argv += ["--comfyui-token", args.comfyui_token]
        if args.debug:
            sys.argv += ["--debug"]
        loboforge_agent.main()
        return

    if args.cmd == "bootstrap":
        if not args.secret:
            raise SystemExit("LOBO_SECRET / --secret required")
        from loboforge_worker.provision.bootstrap_box import BootstrapArgs, bootstrap_fresh_box

        boot = BootstrapArgs(
            secret=args.secret,
            server=args.server,
            base_url=args.base_url,
            provision_mode=args.mode,
            instance_id=args.instance_id,
            label=args.label,
            hf_token=args.hf_token,
            agent_dir=args.agent_dir,
            comfyui_http=args.comfyui_http,
            comfyui_ws=args.comfyui_ws,
        )

        async def _run():
            result = await bootstrap_fresh_box(boot)
            print(result)
            if not result.get("ok"):
                raise SystemExit(1)

        asyncio.run(_run())
        return

    if args.cmd == "provision":
        class A:
            secret = args.secret
            hostname = args.hostname
            node_uuid = "cli-provision"
            server = "wss://www.loboforge.com"
            comfyui_dir = None
            comfyui_http = os.environ.get("LOBO_COMFYUI_HTTP", "http://127.0.0.1:18188")
            comfyui_ws = os.environ.get("LOBO_COMFYUI_WS", "ws://127.0.0.1:18188")
            hf_token = os.environ.get("HF_TOKEN")
            provision_mode = args.mode

        async def _run():
            from loboforge_worker.provision.runner import ProvisionRunner
            r = ProvisionRunner(A())
            print(await r.run_once(args.manifest or None))

        asyncio.run(_run())
        return

    if args.cmd == "sync-loras":
        from loboforge_worker.paths import models_dir, find_comfy_dir
        from loboforge_worker.provision.loras import sync_active_loras, sync_tool_loras
        comfy = find_comfy_dir()
        if not comfy:
            raise SystemExit("ComfyUI not found")
        root = models_dir(comfy)
        print(sync_active_loras(root, base_url=args.base_url, secret=args.secret, mode=args.mode))
        if args.include_tools:
            print(sync_tool_loras(root, base_url=args.base_url, secret=args.secret))
        return

    if args.cmd == "sync-tool-loras":
        from loboforge_worker.paths import models_dir, find_comfy_dir
        from loboforge_worker.provision.loras import sync_tool_loras
        comfy = find_comfy_dir()
        if not comfy:
            raise SystemExit("ComfyUI not found")
        print(sync_tool_loras(models_dir(comfy), base_url=args.base_url, secret=args.secret))
        return

    if args.cmd == "upgrade":
        from loboforge_worker.bootstrap import install_agent_deps, refresh_from_server
        if args.install_deps:
            install_agent_deps()
        print(refresh_from_server(args.agent_dir, base_url=args.base_url, force_worker=args.force_worker))
        return

    if args.cmd == "ready":
        class A:
            secret = args.secret
            server = "wss://www.loboforge.com"
            comfyui_http = args.comfyui_http
            provision_mode = args.mode
            hostname = os.environ.get("LOBO_HOSTNAME")

        async def _run():
            from loboforge_worker.provision.ready import wait_until_ready
            result = await wait_until_ready(A(), mode=args.mode, max_wait_sec=args.max_wait)
            print(result)
            if not result.get("ok"):
                raise SystemExit(1)

        asyncio.run(_run())
        return

    if args.cmd == "preflight-gpu":
        from loboforge_worker.provision.gpu_compat import run_gpu_preflight

        class A:
            secret = args.secret
            node_uuid = args.instance_id or "cli"
            server = "wss://www.loboforge.com"
            provision_mode = args.mode

        result = run_gpu_preflight(A(), mode=args.mode, instance_id=args.instance_id or None)
        print(result)
        if not result.get("ok"):
            raise SystemExit(1)
        return

    if args.cmd == "ensure-lens-comfyui":
        from loboforge_worker.provision.comfyui import ensure_lens_support

        class A:
            secret = args.secret
            node_uuid = args.instance_id or "cli"
            server = "wss://www.loboforge.com"
            comfyui_http = args.comfyui_http
            provision_mode = args.mode

        result = ensure_lens_support(A(), mode=args.mode)
        print(result)
        if not result.get("ok"):
            raise SystemExit(1)
        return

    if args.cmd == "verify":
        from loboforge_worker.bootstrap import agent_log_has_hardened_runtime, verify_hardened
        result = verify_hardened(args.agent_dir)
        if args.log:
            result["log_hardened"] = agent_log_has_hardened_runtime(args.log)
        print(result)
        if not result.get("ok"):
            raise SystemExit(1)
        return


if __name__ == "__main__":
    main()
