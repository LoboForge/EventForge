"""Self-upgrade agent + loboforge_worker package from the LoboForge server."""

from __future__ import annotations

import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

from .http_util import urlopen as agent_urlopen

DEFAULT_BASE_URL = "https://www.loboforge.com"
AGENT_FILES = ("loboforge_agent.py", "loboforge_agent_sqs.py", "loboforge_agent_common.py", "wd14_tagger.py")


def http_base(server: str | None = None) -> str:
    if not server:
        return DEFAULT_BASE_URL
    if server.startswith("ws"):
        return "https://" + server.split("://", 1)[1]
    return server.replace("wss://", "https://").replace("ws://", "http://").rstrip("/")


def _fetch(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with agent_urlopen(url, timeout=120) as resp:
        data = resp.read()
    part = dest.with_suffix(dest.suffix + ".part")
    part.write_bytes(data)
    part.replace(dest)


def refresh_from_server(
    agent_dir: Path | str,
    *,
    base_url: str = DEFAULT_BASE_URL,
    force_worker: bool = False,
) -> dict:
    """Download latest agent scripts + worker tar onto a GPU box."""
    root = Path(agent_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    base = base_url.rstrip("/")
    updated: list[str] = []

    for name in AGENT_FILES:
        dest = root / name
        _fetch(f"{base}/agent/{name}", dest)
        updated.append(name)

    worker_init = root / "loboforge_worker" / "__init__.py"
    if force_worker or not worker_init.is_file():
        with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
            tar_path = Path(tmp.name)
        try:
            _fetch(f"{base}/agent/loboforge_worker.tar.gz", tar_path)
            with tarfile.open(tar_path, "r:gz") as tar:
                tar.extractall(path=root)
            updated.append("loboforge_worker.tar.gz")
        finally:
            tar_path.unlink(missing_ok=True)

    sqs_imports = verify_sqs_agent_imports(root)
    verify = verify_hardened(root)
    return {
        "agent_dir": str(root),
        "updated": updated,
        "worker_ok": verify["ok"],
        "worker_version": verify.get("version"),
        "worker_error": verify.get("error"),
        "sqs_imports_ok": sqs_imports.get("ok"),
        "sqs_imports_error": sqs_imports.get("error"),
    }



def verify_sqs_agent_imports(agent_dir: Path | str) -> dict:
    """Ensure loboforge_agent_common is present (required by loboforge_agent_sqs)."""
    root = Path(agent_dir).expanduser().resolve()
    common = root / "loboforge_agent_common.py"
    if not common.is_file():
        return {"ok": False, "error": "loboforge_agent_common.py missing"}
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        import loboforge_agent_common  # noqa: WPS433
        import loboforge_agent_sqs  # noqa: WPS433
        return {"ok": True}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}

def verify_hardened(agent_dir: Path | str) -> dict:
    """Return whether loboforge_worker imports with PYTHONPATH=agent_dir."""
    root = Path(agent_dir).expanduser().resolve()
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        import loboforge_worker  # noqa: WPS433

        return {"ok": True, "version": getattr(loboforge_worker, "__version__", "?")}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}


def install_agent_deps(python: str | None = None) -> None:
    py = python or shutil.which("python3") or sys.executable
    subprocess.run(
        [py, "-m", "pip", "install", "-q", "-U", "websockets", "aiohttp", "gdown", "huggingface_hub"],
        check=False,
    )
    for packages in (
        ["onnxruntime-gpu", "Pillow", "numpy"],
        ["onnxruntime", "Pillow", "numpy"],
    ):
        if subprocess.run(
            [py, "-m", "pip", "install", "-q", "-U", *packages],
            capture_output=True,
        ).returncode == 0:
            break


def agent_log_has_hardened_runtime(log_path: Path | str, *, tail_lines: int = 80) -> bool:
    path = Path(log_path)
    if not path.is_file():
        return False
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return False
    snippet = "\n".join(lines[-tail_lines:])
    return "loboforge_worker runtime active" in snippet
