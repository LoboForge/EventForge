"""Central GPU worker runtime — provision, health, LoRA prefetch loop."""

from __future__ import annotations

import asyncio
import os
import logging
from typing import Any

from .events import EventBus
from .health import HealthSupervisor
from .models_sync import refresh_and_push
from .protocol import worker_event
from .provision.runner import ProvisionRunner
from .work_loop import LoraPrefetchLoop

log = logging.getLogger("worker.runtime")


class WorkerRuntime:
    """Owns background tasks for a connected agent session."""

    def __init__(self, session: Any, args: Any, agent_state: dict) -> None:
        self.session = session
        self.args = args
        self.state = agent_state
        self.bus = EventBus()
        self.provision = ProvisionRunner(args, self.bus)
        self._tasks: list[asyncio.Task] = []
        self._provision_done = asyncio.Event()
        self._wire_provision_events()

    def _wire_provision_events(self) -> None:
        async def _send(evt: str, **payload: Any) -> None:
            self.state["provisioning"] = evt not in ("provision.complete", "provision.skipped")
            if "step" in payload:
                self.state["provision_step"] = payload["step"]
            if "pct" in payload:
                self.state["provision_pct"] = int(payload["pct"])
            try:
                await self.session.send_json(worker_event(evt, payload))
            except Exception as ex:
                log.debug("provision event %s failed: %s", evt, ex)

        async def on_start(**payload: Any) -> None:
            self.state["provisioning"] = True
            self.state["provision_step"] = payload.get("step") or "starting"
            self.state["provision_pct"] = int(payload.get("pct") or 0)
            await _send("provision.start", step=self.state["provision_step"], pct=self.state["provision_pct"])

        async def on_progress(**payload: Any) -> None:
            step = payload.get("step") or self.state.get("provision_step", "")
            if step:
                self.state["provision_step"] = step
            if "pct" in payload:
                self.state["provision_pct"] = int(payload["pct"])
            await _send(
                "provision.progress",
                step=step,
                pct=payload.get("pct") or self.state.get("provision_pct", 0),
            )

        async def on_complete(**payload: Any) -> None:
            self.state["provisioning"] = False
            self.state["provision_step"] = "ready"
            self.state["provision_pct"] = 100
            await _send("provision.complete", step="ready", pct=100, **payload)

        async def on_failed(**payload: Any) -> None:
            self.state["provisioning"] = True
            self.state["provision_step"] = payload.get("step") or "error"
            await _send("provision.failed", **payload)

        async def on_artifact_downloaded(**payload: Any) -> None:
            try:
                await refresh_and_push(self.session, self.args, self.state)
            except Exception as ex:
                log.warning(
                    "models_update after %s failed: %s",
                    payload.get("dest") or "artifact",
                    ex,
                )

        self.bus.on("provision.start", on_start)
        self.bus.on("provision.progress", on_progress)
        self.bus.on("provision.complete", on_complete)
        self.bus.on("provision.failed", on_failed)
        self.bus.on("artifact.downloaded", on_artifact_downloaded)

    def start(self) -> list[asyncio.Task]:
        from .provision.validate import is_provision_complete
        from .paths import find_models_root

        base = self.args.server.replace("wss://", "https://").replace("ws://", "http://")
        mode = getattr(self.args, "provision_mode", None) or os.environ.get("LOBO_MODE", "all")
        root = find_models_root(self.args)
        if is_provision_complete(root, mode, base, self.args.secret):
            self.state["provisioning"] = False
            self.state["provision_step"] = "ready"
            self.state["provision_pct"] = 100
            log.info("Provision already complete — skipping background downloads")
        else:
            self.state.setdefault("provisioning", True)
            self.state.setdefault("provision_step", "starting")
            self.state.setdefault("provision_pct", 0)
            self.provision.start_background()
            self._tasks.append(asyncio.create_task(self._on_provision_complete()))
        self._tasks.append(asyncio.create_task(self._start_health()))
        self._tasks.append(asyncio.create_task(self._start_lora_prefetch_loop()))
        self._tasks.append(asyncio.create_task(self._install_wd14_background()))
        return self._tasks

    async def _install_wd14_background(self) -> None:
        """WD14 deps are optional — never block pool join."""
        from .bootstrap import install_agent_deps
        from .gpu_compat import resolve_comfy_python

        try:
            await asyncio.to_thread(install_agent_deps, resolve_comfy_python())
        except Exception as ex:
            log.debug("Background WD14 deps install failed: %s", ex)

    async def _on_provision_complete(self) -> None:
        retrying = False
        try:
            if self.provision._task:
                result = await self.provision._task
                if isinstance(result, dict) and result.get("ok") and result.get("complete", True):
                    log.info("Provision complete — refreshing models on server")
                    try:
                        await refresh_and_push(self.session, self.args, self.state)
                    except Exception as ex:
                        log.warning("Post-provision models_update failed: %s", ex)
                elif isinstance(result, dict) and result.get("complete") is False:
                    miss = result.get("required_missing") or result.get("missing") or []
                    log.warning("Provision incomplete (%s) — retrying in 60s", miss[:5])
                    retrying = True
                    await asyncio.sleep(60)
                    self.provision.start_background()
                    self._tasks.append(asyncio.create_task(self._on_provision_complete()))
                    return
                elif isinstance(result, dict):
                    err = result.get("error") or "provision failed"
                    log.warning("Provision finished with error: %s", err)
                    await self.bus.emit(
                        "provision.failed",
                        step=result.get("step") or self.provision.state.last_step or "error",
                        error=err,
                    )
                    # Disk/GPU hard failures also retry so boxes self-heal after transient issues.
                    retrying = True
                    await asyncio.sleep(120)
                    self.provision.start_background()
                    self._tasks.append(asyncio.create_task(self._on_provision_complete()))
                    return
        except asyncio.CancelledError:
            raise
        except Exception as ex:
            if "ComfyUI" in str(ex) and "not found" in str(ex):
                log.info("Provision skipped: %s", ex)
                await self.bus.emit("provision.complete", step="ready", skipped=True, reason=str(ex))
            else:
                log.warning("Provision task error: %s", ex)
                await self.bus.emit(
                    "provision.failed",
                    step=self.provision.state.last_step or "error",
                    error=str(ex),
                )
        finally:
            if not retrying:
                self._provision_done.set()

    async def _start_health(self) -> None:
        from loboforge_agent import (  # type: ignore
            comfyui_is_healthy,
            ensure_comfyui_running,
            maybe_free_comfy_disk,
            model_count,
        )

        supervisor = HealthSupervisor(
            self.session,
            self.args,
            self.state,
            self.provision,
            comfy_is_healthy=comfyui_is_healthy,
            ensure_comfyui_running=ensure_comfyui_running,
            maybe_free_comfy_disk=maybe_free_comfy_disk,
            model_count=model_count,
        )
        await supervisor.run_forever()

    async def _start_lora_prefetch_loop(self) -> None:
        from loboforge_agent import (  # type: ignore
            get_disk_free_mb,
            get_vram_free,
            handle_download_model,
        )

        loop = LoraPrefetchLoop(
            self.session,
            self.args,
            self.state,
            download_model=handle_download_model,
            get_vram_free=get_vram_free,
            get_disk_free_mb=get_disk_free_mb,
        )
        await loop.run_forever()
