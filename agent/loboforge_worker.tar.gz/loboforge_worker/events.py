"""Lightweight async event bus for worker subsystems."""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict
from typing import Any, Callable, Coroutine

log = logging.getLogger("worker.events")

Listener = Callable[..., Coroutine[Any, Any, None]]


class EventBus:
    def __init__(self) -> None:
        self._listeners: dict[str, list[Listener]] = defaultdict(list)

    def on(self, event: str, handler: Listener) -> None:
        self._listeners[event].append(handler)

    async def emit(self, event: str, **payload: Any) -> None:
        for handler in list(self._listeners.get(event, [])):
            try:
                await handler(**payload)
            except Exception as ex:
                log.warning("Event handler %s for %s failed: %s", handler, event, ex)

    def emit_background(self, event: str, **payload: Any) -> None:
        asyncio.create_task(self.emit(event, **payload))
