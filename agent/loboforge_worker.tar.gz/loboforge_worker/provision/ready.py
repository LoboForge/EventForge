"""Connect + Comfy prep — boxes join the pool immediately as 'provisioning'."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from .gpu_compat import derive_agent_hostname, run_gpu_preflight
from .stack import ensure_comfy_stack_ready

log = logging.getLogger("worker.provision.ready")


async def prepare_for_connect(args: Any, *, mode: str | None = None) -> dict[str, Any]:
    """
    Best-effort checks before hello — never hide the box from the pool for minutes.

    Returns ok=True once GPU is reachable; Comfy stack may still be fixing in background.
    """
    from loboforge_agent import (  # type: ignore
        comfyui_is_healthy,
        ensure_p100_pytorch,
        get_available_models,
        model_count,
    )

    mode = mode or getattr(args, "provision_mode", None) or "all"
    hn = derive_agent_hostname(
        mode=mode,
        label=getattr(args, "label", None),
        instance_id=getattr(args, "instance_id", None),
    )
    if hn:
        if not getattr(args, "hostname", None) or len(getattr(args, "hostname", "")) == 12:
            args.hostname = hn

    gpu = await asyncio.to_thread(run_gpu_preflight, args, mode=mode)
    if not gpu.get("ok"):
        return {"ok": False, "error": gpu.get("error") or "GPU preflight failed", "hostname": hn}

    if not await ensure_p100_pytorch(args):
        log.warning("P100 PyTorch fix failed — joining pool anyway for troubleshooting")

    base = _http_base(args)
    secret = getattr(args, "secret", "")
    node_uuid = getattr(args, "node_uuid", None)
    await ensure_comfy_stack_ready(
        args, mode=mode, base_url=base, secret=secret, node_uuid=node_uuid,
    )

    comfy_ok = False
    models: dict = {}
    http = getattr(args, "comfyui_http", "http://127.0.0.1:18188")
    for attempt in range(18):
        if await comfyui_is_healthy(http):
            comfy_ok = True
            try:
                models = await get_available_models(http)
            except Exception:
                models = {}
            break
        if attempt == 0:
            log.info("ComfyUI not ready yet — joining pool as provisioning")
        await asyncio.sleep(10)

    return {
        "ok": True,
        "hostname": getattr(args, "hostname", hn),
        "gpu": gpu,
        "comfy_ok": comfy_ok,
        "models": models,
        "model_count": model_count(models),
        "provisioning": not comfy_ok or model_count(models) <= 0,
    }


async def upgrade_comfy_stack(args: Any, *, mode: str | None = None) -> dict[str, Any]:
    """ComfyUI git/Lens upgrade — always run BEFORE model downloads."""
    from .comfyui import ensure_lens_support

    mode = mode or getattr(args, "provision_mode", None) or "all"
    return await asyncio.to_thread(ensure_lens_support, args, mode=mode)


async def wait_until_ready(args: Any, *, mode: str | None = None, max_wait_sec: int = 900, poll_sec: int = 10) -> dict[str, Any]:
    return await prepare_for_connect(args, mode=mode)


def _http_base(args: Any) -> str:
    server = getattr(args, "server", "wss://www.loboforge.com")
    if server.startswith("ws"):
        return "https://" + server.split("://", 1)[1]
    return server.replace("wss://", "https://").replace("ws://", "http://")
