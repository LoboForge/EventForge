"""ComfyUI auth token auto-detect (mirrors provision_gpu.sh probes)."""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path

log = logging.getLogger("worker.provision.comfy_token")

ENV_CANDIDATES = ("LOBO_COMFYUI_TOKEN", "OPEN_BUTTON_TOKEN", "COMFYUI_TOKEN", "AUTH_TOKEN", "JUPYTER_TOKEN")
FILE_CANDIDATES = (
    "/etc/vast-auth/comfyui-token",
    "/etc/vast-auth/auth_token",
    "/etc/portal-token",
    "/etc/jupyter/token",
    "/root/.cache/comfyui-auth/auth_token",
    "/root/.cache/comfyui/auth_token",
    "/workspace/.vast/comfyui-token",
    "/workspace/comfyui-auth/auth_token",
    "/workspace/comfyui/auth_token",
    "/workspace/auth.txt",
    "/var/run/comfyui/token",
)
_HEX_TOKEN = re.compile(r"\b([0-9a-fA-F]{32,128})\b")


def detect_comfyui_token() -> tuple[str, str]:
    for name in ENV_CANDIDATES:
        val = (os.environ.get(name) or "").strip()
        if val:
            return val, f"env:{name}"

    for path in FILE_CANDIDATES:
        p = Path(path)
        if not p.is_file():
            continue
        try:
            raw = p.read_text(encoding="utf-8", errors="ignore").strip()
        except OSError:
            continue
        if path.endswith(".json"):
            try:
                data = json.loads(raw)
                for key in ("token", "auth_token", "Token", "password"):
                    if isinstance(data.get(key), str) and data[key].strip():
                        return data[key].strip(), f"file:{path}#{key}"
            except json.JSONDecodeError:
                pass
        token = raw.split()[0][:256] if raw else ""
        if token:
            return token, f"file:{path}"

    for directory in ("/etc", "/workspace", "/root/.cache", "/root/.config"):
        d = Path(directory)
        if not d.is_dir():
            continue
        try:
            for path in d.rglob("*"):
                if not path.is_file() or path.stat().st_size > 65536:
                    continue
                name = path.name.lower()
                if "token" not in name and "auth" not in name:
                    continue
                try:
                    text = path.read_text(encoding="utf-8", errors="ignore")
                except OSError:
                    continue
                m = _HEX_TOKEN.search(text)
                if m:
                    return m.group(1), f"grep:{path}"
        except OSError:
            continue

    return "", ""
