"""Pull LoRAs from LoboForge API onto local Comfy models dir."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from ..http_util import urlopen as agent_urlopen
from .download_url import download_to, normalize_lora_rel

log = logging.getLogger("worker.provision.loras")

MIN_LORA_BYTES = 1_000_000


def _fetch_json(url: str, timeout: int = 120) -> list:
    with agent_urlopen(url, timeout=timeout) as resp:
        raw = json.loads(resp.read().decode())
    return raw if isinstance(raw, list) else []


def pull_lora_items(models_root: Path, items: list, *, hf_token: str | None = None) -> dict:
    """Download LoRA rows ({file_path, source_url, ...}) onto models_root."""
    pulled = skipped = failed = 0
    loras_dir = models_root / "loras"
    loras_dir.mkdir(parents=True, exist_ok=True)
    token = hf_token or os.environ.get("HF_TOKEN")
    for la in items:
        fp = (la.get("file_path") or "").strip()
        su = (la.get("source_url") or "").strip()
        if not fp or not su:
            continue
        rel = normalize_lora_rel(fp)
        dest = models_root / rel
        if dest.is_file() and dest.stat().st_size > MIN_LORA_BYTES:
            skipped += 1
            continue
        log.info("Pull LoRA %s", rel)
        if download_to(su, dest, hf_token=token):
            pulled += 1
        else:
            failed += 1
    return {"pulled": pulled, "skipped": skipped, "failed": failed}


def sync_active_loras(
    models_root: Path,
    *,
    base_url: str,
    secret: str,
    mode: str = "all",
    hf_token: str | None = None,
) -> dict:
    url = f"{base_url.rstrip('/')}/api/agent/active-loras?modes={mode}&secret={secret}"
    items = _fetch_json(url)
    result = pull_lora_items(models_root, items, hf_token=hf_token)
    result["mode"] = mode
    result["source"] = "active-loras"
    return result


def sync_tool_loras(
    models_root: Path,
    *,
    base_url: str,
    secret: str,
    hf_token: str | None = None,
) -> dict:
    url = f"{base_url.rstrip('/')}/api/agent/tool-loras?secret={secret}"
    items = _fetch_json(url)
    result = pull_lora_items(models_root, items, hf_token=hf_token)
    result["source"] = "tool-loras"
    return result
