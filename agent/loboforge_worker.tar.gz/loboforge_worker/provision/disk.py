"""Disk preflight and post-download headroom checks (mirrors provision_gpu.sh)."""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Any

log = logging.getLogger("worker.provision.disk")

MODE_NOTE_FILE = Path("/workspace/.loboforge-provision-mode-note.txt")


def mode_flags(mode: str) -> tuple[bool, bool, bool]:
    """Return (want_image, want_video, want_music) for a provision mode string."""
    m = (mode or "all").strip().lower()
    if m in ("all", "both"):
        return True, True, True
    if m == "image":
        return True, False, True
    if m == "video":
        return False, True, True
    if m == "music":
        return False, False, True
    if m in ("wan-native", "ltx-native"):
        return False, m == "wan-native", False
    parts = {p.strip() for p in m.split(",") if p.strip()}
    if not parts:
        return True, True, True
    return (
        "image" in parts or "all" in parts,
        "video" in parts or "all" in parts,
        "music" in parts or "all" in parts,
    )


def required_container_gb(mode: str) -> int:
    m = (mode or "all").strip().lower()
    if m in ("wan-native", "ltx-native"):
        return 120
    want_image, want_video, _ = mode_flags(mode)
    if want_image and want_video:
        return 130
    if want_image or want_video:
        return 100
    return 50


def required_headroom_mb(mode: str) -> int:
    want_image, want_video, _ = mode_flags(mode)
    if want_image and want_video:
        return 15360
    if want_image:
        return 7168
    if want_video:
        return 8192
    return 5120


def _infer_downgrade_target(label: str, hostname: str) -> str:
    """Pick image vs video when mode=all does not fit on disk."""
    blob = f"{label} {hostname}".lower()
    if "video" in blob and "image" not in blob:
        return "video"
    if "image" in blob and "video" not in blob:
        return "image"
    if os.environ.get("LOBO_WAN", "1").strip().lower() in ("0", "false", "no"):
        return "image"
    return "video"


def resolve_mode_for_disk(
    mode: str,
    *,
    label: str = "",
    hostname: str = "",
) -> tuple[str, str | None]:
    """
    When mode=all/both cannot fit, downgrade to image or video with an explanatory note.
    Returns (effective_mode, note_or_none).
    """
    requested = (mode or "all").strip().lower()
    if requested not in ("all", "both"):
        return requested, None

    try:
        total_gb = shutil.disk_usage("/").total // (1024**3)
    except OSError:
        return requested, None

    if total_gb >= required_container_gb("all"):
        return requested, None

    primary = _infer_downgrade_target(label, hostname)
    secondary = "image" if primary == "video" else "video"

    for target in (primary, secondary):
        need = required_container_gb(target)
        if total_gb >= need:
            note = (
                f"Disk {total_gb}GB too small for mode=all (needs ≥130GB). "
                f"Downgraded to mode={target} (≥{need}GB)."
            )
            log.warning(note)
            return target, note

    return requested, None


def persist_mode_note(note: str) -> None:
    try:
        MODE_NOTE_FILE.write_text(note.strip(), encoding="utf-8")
    except OSError as ex:
        log.warning("Could not write mode note: %s", ex)


def apply_effective_mode(mode: str, note: str | None = None) -> None:
    os.environ["LOBO_MODE"] = mode
    os.environ["MODE"] = mode
    if note:
        persist_mode_note(note)


def disk_preflight(
    mode: str,
    *,
    label: str = "",
    hostname: str = "",
) -> dict[str, Any]:
    requested = (mode or "all").strip().lower()
    effective, note = resolve_mode_for_disk(requested, label=label, hostname=hostname)

    try:
        usage = shutil.disk_usage("/")
        total_gb = usage.total // (1024**3)
        free_mb = usage.free // (1024 * 1024)
    except OSError:
        return {"ok": True, "skipped": True, "mode": effective, "requested_mode": requested}

    need_gb = required_container_gb(effective)
    log.info(
        "Container disk: %sGB total, %sMB free (requested=%s effective=%s need ≥%sGB)",
        total_gb,
        free_mb,
        requested,
        effective,
        need_gb,
    )

    result: dict[str, Any] = {
        "ok": total_gb >= need_gb,
        "total_gb": total_gb,
        "free_mb": free_mb,
        "need_gb": need_gb,
        "mode": effective,
        "requested_mode": requested,
    }
    if note:
        result["downgraded"] = True
        result["note"] = note
    if not result["ok"]:
        result["error"] = (
            f"Container is only {total_gb}GB but mode={effective} needs ≥{need_gb}GB. "
            f"Re-rent with larger disk (image/video≥120GB, all≥150GB)."
        )
    return result


def assert_disk_headroom(mode: str) -> dict[str, Any]:
    min_free = required_headroom_mb(mode)
    try:
        free_mb = shutil.disk_usage("/").free // (1024 * 1024)
    except OSError:
        return {"ok": True, "skipped": True}

    log.info("Root disk free: %sMB (want ≥%sMB after models for mode=%s)", free_mb, min_free, mode)
    if free_mb < min_free:
        return {
            "ok": False,
            "error": (
                f"Only {free_mb}MB free on / after model downloads — need ≥{min_free // 1024}GB headroom. "
                f"Re-rent with more disk."
            ),
            "free_mb": free_mb,
            "min_mb": min_free,
        }
    return {"ok": True, "free_mb": free_mb, "min_mb": min_free}


def should_sync_tool_loras(mode: str) -> bool:
    m = (mode or "").strip().lower()
    return m not in ("ltx-native",)


def should_sync_active_loras(mode: str) -> bool:
    m = (mode or "").strip().lower()
    return m in ("video", "wan-native", "all", "both", "image")
