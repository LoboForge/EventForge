"""Background provision orchestrator."""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..events import EventBus
from ..manifest import load_local, manifests_for_mode, _filter_manifests
from ..paths import find_models_root
from .artifact_skips import clear_skip, skip_reason
from .custom_nodes import ensure_ace_step_visible
from .disk import apply_effective_mode, assert_disk_headroom, disk_preflight, mode_flags
from .downloads import ensure_artifact, file_ok, link_ltx_audio_checkpoint
from .gpu_compat import run_gpu_preflight
from .hf_cli import ensure_hf_cli
from .loras import sync_active_loras, sync_tool_loras
from .stack import ensure_comfy_stack_ready
from .status import post_status
from .validate import missing_artifacts, missing_required_artifacts, provision_state_write

log = logging.getLogger("worker.provision.runner")

KLEIN_UNET_DEST = "diffusion_models/F2Klein/flux-2-klein-9b-fp8.safetensors"

PROVISION_DONE = Path("/workspace/.loboforge-provision-done")


@dataclass
class ProvisionState:
    running: bool = False
    mode: str = "all"
    completed: list[str] = field(default_factory=list)
    failed: str = ""
    last_step: str = ""


class ProvisionRunner:
    def __init__(self, args: Any, bus: EventBus | None = None) -> None:
        self.args = args
        self.bus = bus or EventBus()
        self.state = ProvisionState(mode=getattr(args, "provision_mode", None) or _detect_mode(args))
        self._task: asyncio.Task | None = None

    def start_background(self) -> None:
        if self._task and not self._task.done():
            return
        self._task = asyncio.create_task(self.run_once())

    async def run_once(self, manifest_names: list[str] | None = None) -> dict:
        if self.state.running:
            return {"ok": False, "error": "Provision already running"}
        self.state.running = True
        self.state.failed = ""
        downloaded: list[str] = []
        download_errors: list[str] = []
        base = _http_base(self.args)
        secret = self.args.secret
        mode = self.state.mode

        try:
            disk = await asyncio.to_thread(
                disk_preflight,
                mode,
                label=getattr(self.args, "label", None) or os.environ.get("LOBO_LABEL", ""),
                hostname=getattr(self.args, "hostname", None) or "",
            )
            if disk.get("downgraded"):
                mode = disk["mode"]
                self.state.mode = mode
                if hasattr(self.args, "provision_mode"):
                    self.args.provision_mode = mode
                note = disk.get("note") or ""
                apply_effective_mode(mode, note)
                post_status(
                    "disk.preflight",
                    "warn",
                    note,
                    base_url=base,
                    secret=secret,
                    node_uuid=self.args.node_uuid,
                )
            elif not disk.get("ok"):
                err = disk.get("error") or "Disk preflight failed"
                self.state.failed = err
                post_status(
                    "disk.preflight",
                    "error",
                    err,
                    base_url=base,
                    secret=secret,
                    node_uuid=self.args.node_uuid,
                )
                await self.bus.emit("provision.failed", step="disk.preflight", error=err)
                return {"ok": False, "error": err, "disk": disk}

            await self.bus.emit("provision.start", step="gpu.preflight", pct=0)
            self.state.last_step = "gpu.preflight"
            skip_gpu = os.environ.get("LOBO_SKIP_GPU_PREFLIGHT", "").strip().lower() in (
                "1", "true", "yes",
            )
            if skip_gpu:
                log.warning("LOBO_SKIP_GPU_PREFLIGHT=1 — skipping CUDA smoke test before downloads")
                gpu = {"ok": True, "skipped": True}
            else:
                gpu = await asyncio.to_thread(run_gpu_preflight, self.args, mode=mode)
            if not gpu.get("ok"):
                err = gpu.get("error") or "GPU preflight failed"
                self.state.failed = err
                await self.bus.emit("provision.failed", step="gpu.preflight", error=err)
                return {"ok": False, "error": err, "gpu": gpu}

            # Comfy stack preflight — rgthree, Lens, Power Lora Loader (mirrors provision_gpu.sh).
            self.state.last_step = "comfy.stack"
            await self.bus.emit("provision.progress", step="comfy.stack", pct=5)
            stack = await ensure_comfy_stack_ready(
                self.args,
                mode=mode,
                base_url=base,
                secret=secret,
                node_uuid=self.args.node_uuid,
            )
            if not stack.get("ok"):
                log.warning("Comfy stack preflight incomplete: %s", stack.get("steps"))

            root = find_models_root(self.args)
            if not root:
                msg = "No local models directory — skipping manifest downloads"
                log.info(msg)
                post_status(
                    "provision.skipped", "ok", msg,
                    base_url=base, secret=secret, node_uuid=self.args.node_uuid, pct=100,
                )
                lora_result = await self._sync_loras_optional(mode)
                tool_result = None
                _, want_video, _ = mode_flags(mode)
                if want_video:
                    tool_result = await self._sync_tool_loras_optional()
                out: dict = {"ok": True, "skipped": True, "downloaded": [], "loras": lora_result}
                if tool_result is not None:
                    out["tool_loras"] = tool_result
                await self.bus.emit("provision.complete", skipped=True)
                return out

            manifests = manifests_for_mode(mode, base, secret)
            for manifest in manifests:
                for art in manifest.artifacts:
                    if art.required and not file_ok(root / art.dest, art.min_bytes):
                        clear_skip(art.dest)
            if manifest_names:
                by_name = {m.name: m for m in manifests}
                for name in manifest_names:
                    if name not in by_name:
                        local = load_local(name)
                        if local:
                            by_name[name] = local
                manifests = _filter_manifests(
                    [by_name[n] for n in manifest_names if n in by_name],
                    mode,
                )
            total = sum(len(m.artifacts) for m in manifests)
            done = 0
            hf_token = getattr(self.args, "hf_token", None) or os.environ.get("HF_TOKEN")
            await asyncio.to_thread(ensure_hf_cli)

            heartbeat_task: asyncio.Task | None = None
            heartbeat_step = "models.download"
            klein_loras_synced = False
            klein_lora_task: asyncio.Task | None = None

            async def _heartbeat() -> None:
                while True:
                    await asyncio.sleep(60)
                    try:
                        free_mb = shutil.disk_usage("/").free // (1024 * 1024)
                    except OSError:
                        free_mb = -1
                    post_status(
                        heartbeat_step,
                        "ok",
                        f"downloading free_mb={free_mb}",
                        base_url=base,
                        secret=secret,
                        node_uuid=self.args.node_uuid,
                    )

            heartbeat_task = asyncio.create_task(_heartbeat())

            try:
                for manifest in manifests:
                    heartbeat_step = f"models.{manifest.name}"
                    for art in manifest.artifacts:
                        step = f"{manifest.name}.{Path(art.dest).name}"
                        self.state.last_step = step
                        pct = int(done / max(total, 1) * 100)
                        await self.bus.emit("provision.progress", step=step, pct=max(pct, 10))
                        cached = skip_reason(art.dest) if not art.required else None
                        if cached:
                            log.debug("Skipping %s — cached failure: %s", art.dest, cached)
                            done += 1
                            continue
                        post_status(
                            step, "ok", f"checking {art.dest}",
                            base_url=base, secret=secret, node_uuid=self.args.node_uuid, pct=pct,
                        )
                        try:
                            if await asyncio.to_thread(ensure_artifact, art, root, hf_token):
                                downloaded.append(art.dest)
                                self.bus.emit_background("artifact.downloaded", dest=art.dest)
                            if (
                                not klein_loras_synced
                                and art.dest == KLEIN_UNET_DEST
                                and (root / art.dest).is_file()
                                and (root / art.dest).stat().st_size >= art.min_bytes
                            ):
                                klein_loras_synced = True
                                post_status(
                                    "models.klein", "ok", "Flux Klein ready; early LoRA sync",
                                    base_url=base, secret=secret, node_uuid=self.args.node_uuid, pct=max(pct, 25),
                                )
                                klein_lora_task = asyncio.create_task(self._sync_loras_optional(mode))
                                log.info("Klein stack ready — early LoRA sync started")
                        except Exception as ex:
                            download_errors.append(f"{art.dest}: {ex}")
                            log.warning("Download failed for %s — will not retry: %s", art.dest, ex)
                            post_status(
                                step, "warn", str(ex),
                                base_url=base, secret=secret, node_uuid=self.args.node_uuid,
                            )
                        done += 1
            finally:
                if heartbeat_task:
                    heartbeat_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await heartbeat_task

            if any(m.name == "ltx23_stack" for m in manifests):
                await asyncio.to_thread(link_ltx_audio_checkpoint, root)

            _, _, want_music = mode_flags(mode)
            if want_music:
                ace = await ensure_ace_step_visible(self.args)
                if not ace.get("ok"):
                    log.warning("ACE-Step not visible after downloads: %s", ace.get("error"))

            headroom = await asyncio.to_thread(assert_disk_headroom, mode)
            post_status(
                "disk.check",
                "ok" if headroom.get("ok") else "warn",
                str(headroom),
                base_url=base,
                secret=secret,
                node_uuid=self.args.node_uuid,
            )

            self.state.completed = downloaded
            post_status(
                "provision.complete", "ok", f"downloaded={len(downloaded)}",
                base_url=base, secret=secret, node_uuid=self.args.node_uuid, pct=100,
            )
            if klein_lora_task and not klein_lora_task.done():
                with contextlib.suppress(Exception):
                    await klein_lora_task
            lora_result = await self.sync_loras(mode)
            tool_result: dict | None = None
            _, want_video, _ = mode_flags(mode)
            if want_video:
                tool_result = await self.sync_tool_loras()
            out = {"ok": True, "downloaded": downloaded, "loras": lora_result}
            if download_errors:
                out["download_errors"] = download_errors
            if disk.get("downgraded"):
                out["downgraded"] = True
                out["downgrade_note"] = disk.get("note")
            if not headroom.get("ok"):
                out["disk_warning"] = headroom.get("error")
            if tool_result is not None:
                out["tool_loras"] = tool_result
            missing = missing_artifacts(root, manifests, hf_token=hf_token)
            required_missing = missing_required_artifacts(root, manifests, hf_token=hf_token)
            complete = not required_missing
            try:
                provision_state_write(
                    mode=mode,
                    complete=complete,
                    downloaded=downloaded,
                    missing=missing,
                    errors=download_errors,
                )
            except OSError as ex:
                log.warning("Could not write provision state: %s", ex)
            if not complete:
                msg = f"required missing ({len(required_missing)}): {required_missing[:5]}"
                log.warning("Provision incomplete — %s", msg)
                post_status(
                    "provision.incomplete", "warn", msg,
                    base_url=base, secret=secret, node_uuid=self.args.node_uuid,
                )
                out["ok"] = False
                out["complete"] = False
                out["missing"] = missing
                out["required_missing"] = required_missing
                await self.bus.emit("provision.incomplete", missing=required_missing)
                return out
            await self.bus.emit("provision.complete", downloaded=len(downloaded))
            out["complete"] = True
            return out
        finally:
            self.state.running = False

    async def sync_loras(self, mode: str | None = None, *, include_tools: bool = False) -> dict:
        root = find_models_root(self.args)
        if not root:
            raise FileNotFoundError("ComfyUI models directory not found")
        mode = mode or self.state.mode
        hf_token = getattr(self.args, "hf_token", None) or os.environ.get("HF_TOKEN")
        result = await asyncio.to_thread(
            sync_active_loras, root, base_url=_http_base(self.args), secret=self.args.secret, mode=mode,
            hf_token=hf_token,
        )
        if include_tools:
            tool_result = await self.sync_tool_loras()
            result = {**result, "tool_loras": tool_result}
        await self.bus.emit("loras.synced", **result)
        return result

    async def sync_tool_loras(self) -> dict:
        root = find_models_root(self.args)
        if not root:
            raise FileNotFoundError("ComfyUI models directory not found")
        hf_token = getattr(self.args, "hf_token", None) or os.environ.get("HF_TOKEN")
        result = await asyncio.to_thread(
            sync_tool_loras, root, base_url=_http_base(self.args), secret=self.args.secret,
            hf_token=hf_token,
        )
        await self.bus.emit("tool_loras.synced", **result)
        return result

    async def _sync_loras_optional(self, mode: str | None = None) -> dict:
        try:
            return await self.sync_loras(mode)
        except FileNotFoundError:
            log.info("Skipping LoRA sync — no local models directory")
            return {"skipped": True}

    async def _sync_tool_loras_optional(self) -> dict:
        try:
            return await self.sync_tool_loras()
        except FileNotFoundError:
            log.info("Skipping tool LoRA sync — no local models directory")
            return {"skipped": True}

    def status_dict(self) -> dict:
        return {
            "running": self.state.running,
            "mode": self.state.mode,
            "last_step": self.state.last_step,
            "failed": self.state.failed,
            "completed_count": len(self.state.completed),
        }


def _http_base(args: Any) -> str:
    server = getattr(args, "server", "wss://www.loboforge.com")
    if server.startswith("ws"):
        return "https://" + server.split("://", 1)[1]
    return server.replace("wss://", "https://").replace("ws://", "http://")


def _detect_mode(args: Any) -> str:
    hn = (getattr(args, "hostname", "") or "").lower()
    if "video" in hn:
        return "video"
    if "image" in hn:
        return "image"
    if "music" in hn:
        return "music"
    return os.environ.get("LOBO_MODE", "all")
