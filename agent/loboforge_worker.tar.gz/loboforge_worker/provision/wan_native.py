"""Provision dedicated Wan 2.2 native boxes — Wan-Video/Wan2.2, no ComfyUI."""

from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..bootstrap import install_agent_deps, refresh_from_server
from ..inference.wan.paths import (
    I2V_CKPT_DIR,
    i2v_ready,
    missing_artifacts,
    write_layout,
    wan_model_root,
    wan_repo_root,
)
from ..manifest import load_local, manifests_for_mode
from .bootstrap_box import (
    BootstrapArgs,
    export_hf_token,
    launch_agent_tmux,
    resolve_hf_token,
    resolve_python,
)
from .downloads import file_ok
from .gpu_compat import derive_agent_hostname, run_gpu_preflight
from .hf_cli import ensure_hf_cli
from .ltx_native import native_hf_download
from .status import post_status
from .validate import provision_state_write

log = logging.getLogger("worker.provision.wan_native")

PROVISION_MODE = "wan-native"
WAN_REPO_URL = "https://github.com/Wan-Video/Wan2.2.git"
I2V_HF_REPO = "Wan-AI/Wan2.2-I2V-A14B"


@dataclass
class WanNativeProvisionArgs:
    secret: str
    server: str = "wss://www.loboforge.com"
    base_url: str = "https://www.loboforge.com"
    instance_id: str = ""
    label: str = "loboforge-wan-native"
    hf_token: str = ""
    agent_dir: str = "/workspace"
    wan_model_root: str = ""
    wan_repo: str = ""


def _models_root(args: WanNativeProvisionArgs) -> Path:
    raw = args.wan_model_root or os.environ.get("WAN_MODEL_ROOT", "")
    return Path(raw) if raw else wan_model_root()


def _repo_root(args: WanNativeProvisionArgs) -> Path:
    raw = args.wan_repo or os.environ.get("WAN_REPO", "")
    return Path(raw) if raw else wan_repo_root()


def _detect_vram_gb() -> float:
    """Best-effort GPU VRAM total (GiB) for provision-time offload defaults."""
    try:
        import subprocess

        out = subprocess.run(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
        if out.returncode == 0 and out.stdout.strip():
            mib = float(out.stdout.strip().splitlines()[0].strip())
            return mib / 1024.0
    except Exception:
        pass
    try:
        from ..inference.wan.paths import vram_gb

        gb = vram_gb()
        if gb > 0:
            return gb
    except Exception:
        pass
    return 0.0


def _wan_offload_defaults() -> tuple[str, str]:
    """Return (LOBO_UNLOAD_MODELS, WAN_LOW_VRAM) for .loboforge-env on this box."""
    gb = _detect_vram_gb()
    if gb <= 0 or gb < 48:
        return "1", "1"
    return "0", "0"



def write_native_env(args: WanNativeProvisionArgs, *, hostname: str) -> None:
    root = _models_root(args)
    repo = _repo_root(args)
    env_path = Path(args.agent_dir) / ".loboforge-env"
    lines = [
        'export LOBO_EXECUTOR="native"',
        'export LOBO_SKIP_COMFY="1"',
        f'export LOBO_SECRET="{args.secret}"',
        f'export LOBO_SERVER="{args.server}"',
        f'export LOBO_BASE_URL="{args.base_url}"',
        f'export LOBO_MODE="{PROVISION_MODE}"',
        f'export MODE="{PROVISION_MODE}"',
        'export LOBO_WAN="1"',
        'export LOBO_LTX23="0"',
        'export LOBO_MUSIC="0"',
        f'export LOBO_UNLOAD_MODELS="{_wan_offload_defaults()[0]}"',
        f'export WAN_LOW_VRAM="{_wan_offload_defaults()[1]}"',
        f'export WAN_VRAM_GB="{_detect_vram_gb():.1f}"',
        f'export WAN_MODEL_ROOT="{root}"',
        f'export WAN_REPO="{repo}"',
        f'export LOBO_LABEL="{args.label}"',
        f'export LOBO_HOSTNAME="{hostname}"',
    ]
    if args.hf_token:
        lines.append(f'export HF_TOKEN="{args.hf_token}"')
        lines.append(f'export HUGGINGFACE_HUB_TOKEN="{args.hf_token}"')
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    log.info("Wrote %s", env_path)


def install_wan_repo(repo: Path, python: str) -> dict[str, Any]:
    """Clone Wan-Video/Wan2.2 and install requirements."""
    repo.parent.mkdir(parents=True, exist_ok=True)
    if not (repo / ".git").is_dir():
        log.info("Cloning %s -> %s", WAN_REPO_URL, repo)
        r = subprocess.run(
            ["git", "clone", "--depth", "1", WAN_REPO_URL, str(repo)],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or r.stdout or "git clone failed")[:500]}

    req = repo / "requirements.txt"
    if req.is_file():
        # flash_attn needs a pre-built torch and often fails on Vast boxes; Wan runs without it.
        skip = {"flash_attn", "flash-attn"}
        lines = [
            ln.strip()
            for ln in req.read_text(encoding="utf-8").splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        filtered = [ln for ln in lines if ln.split("==")[0].split("[")[0].strip().lower() not in skip]
        log.info("pip install Wan2.2 deps (%d packages, flash_attn skipped)", len(filtered))
        r = subprocess.run(
            [python, "-m", "pip", "install", "-q", *filtered],
            capture_output=True,
            text=True,
            timeout=1800,
        )
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or r.stdout or "pip failed")[:400]}

    verify = subprocess.run(
        [python, "-c", "import sys; sys.path.insert(0, %r); import wan" % str(repo)],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if verify.returncode != 0:
        detail = (verify.stderr or verify.stdout or "import failed")[:400]
        return {"ok": False, "error": f"wan import failed: {detail}"}
    return {"ok": True, "repo": str(repo)}


def download_i2v_checkpoint(root: Path, hf_token: str | None = None) -> None:
    dest = root / I2V_CKPT_DIR
    marker = dest / ".hf_complete"
    if i2v_ready(root) and marker.is_file():
        log.info("I2V checkpoint already present at %s", dest)
        return
    if not ensure_hf_cli():
        raise RuntimeError("hf CLI not available")
    env = None
    if hf_token:
        env = {**os.environ, "HF_TOKEN": hf_token, "HUGGINGFACE_HUB_TOKEN": hf_token}
    dest.mkdir(parents=True, exist_ok=True)
    cmd = ["hf", "download", I2V_HF_REPO, "--local-dir", str(dest)]
    log.info("Downloading %s -> %s", I2V_HF_REPO, dest)
    subprocess.run(cmd, check=True, env=env, timeout=14_400, capture_output=True, text=True)
    if not i2v_ready(root):
        raise RuntimeError(f"I2V checkpoint incomplete under {dest}")
    marker.write_text("ok\n", encoding="utf-8")


async def download_native_stack(
    args: WanNativeProvisionArgs,
    *,
    node_uuid: str,
) -> dict[str, Any]:
    root = _models_root(args)
    root.mkdir(parents=True, exist_ok=True)
    base = args.base_url.rstrip("/")
    secret = args.secret
    python = resolve_python()
    repo = _repo_root(args)

    repo_result = await asyncio.to_thread(install_wan_repo, repo, python)
    if not repo_result.get("ok"):
        return {"ok": False, "error": repo_result.get("error"), "downloaded": [], "missing": ["wan_repo"]}

    manifests = manifests_for_mode(PROVISION_MODE, base, secret)
    if not manifests:
        local = load_local("wan22_native_stack")
        manifests = [local] if local else []

    await asyncio.to_thread(ensure_hf_cli)
    hf_token = args.hf_token or os.environ.get("HF_TOKEN")
    downloaded: list[str] = []
    errors: list[str] = []

    post_status(
        "models.wan_native",
        "ok",
        f"downloading {I2V_HF_REPO}",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=30,
    )
    try:
        await asyncio.to_thread(download_i2v_checkpoint, root, hf_token)
        downloaded.append(I2V_CKPT_DIR)
    except Exception as ex:
        log.warning("I2V checkpoint download failed: %s", ex)
        errors.append(I2V_CKPT_DIR)

    total = sum(len(m.artifacts) for m in manifests)
    done = 0
    for manifest in manifests:
        for art in manifest.artifacts:
            done += 1
            pct = 40 + int(done / max(total, 1) * 45)
            post_status(
                "models.wan_native",
                "ok",
                f"downloading {art.dest} ({done}/{total})",
                base_url=base,
                secret=secret,
                node_uuid=node_uuid,
                pct=pct,
            )
            dest = root / art.dest
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                await asyncio.to_thread(native_hf_download, art, root, hf_token)
                if file_ok(dest, art.min_bytes):
                    downloaded.append(art.dest)
                else:
                    errors.append(art.dest)
            except Exception as ex:
                log.warning("Download failed %s: %s", art.dest, ex)
                errors.append(art.dest)

    missing = missing_artifacts(root)
    try:
        write_layout(root, repo=repo)
    except Exception as ex:
        log.warning("Could not write layout.json yet: %s", ex)

    return {
        "ok": not missing and not errors,
        "downloaded": downloaded,
        "missing": missing,
        "errors": errors,
    }



def write_start_wan_agent_script(args: WanNativeProvisionArgs) -> Path:
    """Persist /workspace/start-wan-agent.sh for watchdog restarts."""
    unload, low = _wan_offload_defaults()
    script = Path(args.agent_dir) / "start-wan-agent.sh"
    script.write_text(
        """#!/bin/bash
set -euo pipefail
cd /workspace
set -a
source /workspace/.loboforge-env
set +a
export PYTHONPATH=/workspace${PYTHONPATH:+:$PYTHONPATH}
export LOBO_EXECUTOR=native
export LOBO_SKIP_COMFY=1
export LOBO_WAN=1
export LOBO_LTX23=0
export LOBO_MUSIC=0
export LOBO_UNLOAD_MODELS=""" + unload + """
export WAN_LOW_VRAM=""" + low + """
export MODE=wan-native
export LOBO_MODE=wan-native
export WAN_MODEL_ROOT=/workspace/wan-models
export WAN_REPO=/workspace/Wan2.2
export HF_HUB_DISABLE_XET=1
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"
unset HF_ENDPOINT
: "${LOBO_SECRET:?LOBO_SECRET missing}"
HN="${LOBO_HOSTNAME:-loboforge-wan-native-${CONTAINER_ID:-box}}"
pids=$(pgrep -f '[l]oboforge_agent_eventforge.py' || true)
if [ -n "${pids:-}" ]; then kill $pids 2>/dev/null || true; sleep 1; kill -9 $pids 2>/dev/null || true; fi
tmux kill-session -t loboforge-agent 2>/dev/null || true
sleep 1
nohup /venv/main/bin/python3 /workspace/loboforge_agent_eventforge.py \
  --secret "${LOBO_SECRET}" \
  --hostname "${HN}" \
  --capability wan >> /workspace/agent.log 2>&1 &
echo "agent_pid=$! hostname=${HN}"
""",
        encoding="utf-8",
    )
    script.chmod(0o755)
    log.info("Wrote %s (unload=%s low_vram=%s)", script, unload, low)
    return script


async def connect_native_box(args: WanNativeProvisionArgs) -> dict[str, Any]:
    """Join fleet immediately — agent tmux; downloads may continue in background."""
    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"
    python = resolve_python()

    os.environ["LOBO_EXECUTOR"] = "native"
    os.environ["LOBO_SKIP_COMFY"] = "1"
    os.environ["WAN_MODEL_ROOT"] = str(_models_root(args))
    os.environ["WAN_REPO"] = str(_repo_root(args))

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)
    install_agent_deps(python)

    hn = derive_agent_hostname(
        mode=PROVISION_MODE,
        label=args.label,
        instance_id=args.instance_id,
    )
    write_native_env(args, hostname=hn)
    await asyncio.to_thread(write_start_wan_agent_script, args)

    gpu = await asyncio.to_thread(
        run_gpu_preflight,
        args,
        mode=PROVISION_MODE,
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        instance_id=args.instance_id or None,
    )
    if not gpu.get("ok"):
        err = gpu.get("error") or "GPU preflight failed"
        post_status("gpu.preflight", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    refresh = refresh_from_server(Path(args.agent_dir), base_url=base, force_worker=True)
    if not refresh.get("worker_ok"):
        log.warning("Worker package verify: %s", refresh.get("worker_error"))

    boot = BootstrapArgs(
        secret=secret,
        server=args.server,
        base_url=base,
        provision_mode=PROVISION_MODE,
        instance_id=args.instance_id,
        label=args.label,
        hostname=hn,
        hf_token=args.hf_token,
        agent_dir=args.agent_dir,
    )
    agent = launch_agent_tmux(boot, hostname=hn)
    if not agent.get("ok"):
        err = agent.get("error") or "agent tmux launch failed"
        post_status("agent.launch", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    post_status(
        "online.checkin",
        "ok",
        f"native Wan agent connected hostname={hn}",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=5,
    )
    return {"ok": True, "hostname": hn, "gpu": gpu, "agent": agent, "worker_refresh": refresh}


async def provision_wan_native_box(
    args: WanNativeProvisionArgs,
    *,
    connect_only: bool = False,
    skip_agent_launch: bool = False,
) -> dict[str, Any]:
    if connect_only:
        return await connect_native_box(args)

    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)

    if not skip_agent_launch:
        early = await connect_native_box(args)
        if not early.get("ok"):
            return early

    post_status(
        "provision.wan_native",
        "ok",
        "downloading Wan2.2 repo + I2V-A14B + lightning LoRAs",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=15,
    )

    dl = await download_native_stack(args, node_uuid=node_uuid)
    missing = dl.get("missing") or []
    complete = dl.get("ok", False)
    provision_state_write(
        mode=PROVISION_MODE,
        complete=complete,
        downloaded=list(dl.get("downloaded") or []),
        missing=missing,
        errors=list(dl.get("errors") or []),
    )

    hn = derive_agent_hostname(mode=PROVISION_MODE, label=args.label, instance_id=args.instance_id)
    write_native_env(args, hostname=hn)
    await asyncio.to_thread(write_start_wan_agent_script, args)

    post_status(
        "provision.complete",
        "ok" if complete else "warn",
        "native Wan box ready" if complete else f"missing: {', '.join(missing[:3])}",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=100,
    )
    return {"ok": complete, "hostname": hn, "download": dl, "missing": missing}


def run_provision_wan_native_cli(argv: list[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(description="Provision Wan 2.2 native box (Wan-Video/Wan2.2, no ComfyUI)")
    p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    p.add_argument("--server", default=os.environ.get("LOBO_SERVER", "wss://www.loboforge.com"))
    p.add_argument("--base-url", default=os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com"))
    p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", os.environ.get("CONTAINER_ID", "")))
    p.add_argument("--label", default=os.environ.get("LOBO_LABEL", "loboforge-wan-native"))
    p.add_argument("--hf-token", default=os.environ.get("HF_TOKEN", ""))
    p.add_argument("--agent-dir", default="/workspace")
    p.add_argument("--connect-only", action="store_true")
    p.add_argument("--skip-agent-launch", action="store_true")
    if argv is None:
        argv = sys.argv[1:]
        if argv and argv[0] == "provision-wan-native":
            argv = argv[1:]
    ns = p.parse_args(argv)
    if not ns.secret:
        print("ERROR: --secret or LOBO_SECRET required", file=sys.stderr)
        return 1

    args = WanNativeProvisionArgs(
        secret=ns.secret,
        server=ns.server,
        base_url=ns.base_url,
        instance_id=ns.instance_id,
        label=ns.label,
        hf_token=ns.hf_token,
        agent_dir=ns.agent_dir,
    )
    result = asyncio.run(
        provision_wan_native_box(
            args,
            connect_only=ns.connect_only,
            skip_agent_launch=ns.skip_agent_launch,
        )
    )
    if not result.get("ok"):
        print("FAILED:", result.get("error") or result.get("missing"), file=sys.stderr)
        return 1
    print("OK hostname=", result.get("hostname"))
    return 0
