"""Provision dedicated Wan 2.2 batch boxes — warm Comfy, models stay in VRAM."""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..bootstrap import install_agent_deps, refresh_from_server
from ..manifest import manifests_for_mode
from ..paths import find_comfy_dir, models_dir
from .bootstrap_box import (
    BootstrapArgs,
    export_hf_token,
    launch_agent_tmux,
    resolve_hf_token,
    resolve_python,
)
from .gpu_compat import derive_agent_hostname, run_gpu_preflight
from .stack import ensure_comfy_stack_ready
from .status import post_status
from .validate import is_provision_complete, missing_artifacts, provision_state_write

log = logging.getLogger("worker.provision.wan_native")

PROVISION_MODE = "wan-native"
WAN_I2V_HIGH_REL = "diffusion_models/Wan2.2/smoothMixWan22I2VT2V_i2vHigh.safetensors"


@dataclass
class WanNativeProvisionArgs:
    secret: str
    server: str = "wss://www.loboforge.com"
    base_url: str = "https://www.loboforge.com"
    instance_id: str = ""
    label: str = "loboforge-wan-native"
    hf_token: str = ""
    agent_dir: str = "/workspace"


def _apply_wan_native_env() -> None:
    os.environ.setdefault("LOBO_WAN", "1")
    os.environ.setdefault("LOBO_LTX23", "0")
    os.environ.setdefault("LOBO_MUSIC", "0")
    os.environ.setdefault("LOBO_UNLOAD_MODELS", "0")
    os.environ.setdefault("LOBO_HOT_MODEL", "wan")
    os.environ.setdefault("LOBO_WAN_STACK", "smoothmix")
    os.environ.setdefault("LOBO_EXECUTOR", "comfy")
    os.environ.setdefault("MODE", PROVISION_MODE)
    os.environ.setdefault("LOBO_MODE", PROVISION_MODE)


def _models_root(args: WanNativeProvisionArgs) -> Path:
    comfy = find_comfy_dir()
    if comfy:
        return models_dir(comfy)
    return Path(args.agent_dir) / "ComfyUI" / "models"


def write_wan_native_env(args: WanNativeProvisionArgs, *, hostname: str) -> None:
    env_path = Path(args.agent_dir) / ".loboforge-env"
    exports = {
        "LOBO_MODE": PROVISION_MODE,
        "MODE": PROVISION_MODE,
        "LOBO_WAN": "1",
        "LOBO_LTX23": "0",
        "LOBO_MUSIC": "0",
        "LOBO_UNLOAD_MODELS": "0",
        "LOBO_HOT_MODEL": "wan",
        "LOBO_EXECUTOR": "comfy",
        "LOBO_LABEL": args.label or "loboforge-wan-native",
        "HF_TOKEN": args.hf_token or os.environ.get("HF_TOKEN", ""),
    }
    lines = [f'export {k}="{v}"' for k, v in exports.items() if v is not None]
    try:
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as ex:
        log.warning("Could not write %s: %s", env_path, ex)


async def _download_wan_stack(args: WanNativeProvisionArgs) -> dict[str, Any]:
    from .runner import ProvisionRunner

    class _A:
        secret = args.secret
        hostname = derive_agent_hostname(
            mode=PROVISION_MODE,
            label=args.label,
            instance_id=args.instance_id,
        )
        node_uuid = args.instance_id or "unknown"
        server = args.server
        base_url = args.base_url
        comfyui_dir = None
        comfyui_http = os.environ.get("LOBO_COMFYUI_HTTP", "http://127.0.0.1:18188")
        comfyui_ws = os.environ.get("LOBO_COMFYUI_WS", "ws://127.0.0.1:18188")
        hf_token = args.hf_token
        provision_mode = PROVISION_MODE

    runner = ProvisionRunner(_A())
    return await runner.run_once()


async def connect_wan_native_box(args: WanNativeProvisionArgs) -> dict[str, Any]:
    """Join fleet immediately — Comfy + agent; downloads may continue in background."""
    _apply_wan_native_env()
    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"
    python = resolve_python()

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)
    install_agent_deps(python)

    hn = derive_agent_hostname(
        mode=PROVISION_MODE,
        label=args.label,
        instance_id=args.instance_id,
    )
    write_wan_native_env(args, hostname=hn)

    gpu = await asyncio.to_thread(
        run_gpu_preflight,
        args,
        mode=PROVISION_MODE,
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        instance_id=args.instance_id or None,
    )
    if not gpu.get("ok"):
        err = gpu.get("error") or "GPU preflight failed"
        post_status("gpu.preflight", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    refresh = refresh_from_server(Path(args.agent_dir), base_url=base, force_worker=True)
    if not refresh.get("worker_ok"):
        log.warning("Worker package verify: %s", refresh.get("worker_error"))

    boot = BootstrapArgs(
        secret=secret,
        server=args.server,
        base_url=base,
        provision_mode=PROVISION_MODE,
        instance_id=args.instance_id,
        label=args.label,
        hostname=hn,
        hf_token=args.hf_token,
        agent_dir=args.agent_dir,
    )

    from loboforge_agent import ensure_comfyui_running  # type: ignore

    if not await ensure_comfyui_running(boot):
        post_status(
            "comfy.start",
            "warn",
            "ComfyUI not up yet — joining pool as provisioning",
            base_url=base,
            secret=secret,
            node_uuid=node_uuid,
        )

    await ensure_comfy_stack_ready(
        boot,
        mode=PROVISION_MODE,
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
    )

    agent = launch_agent_tmux(boot, hostname=hn)
    if not agent.get("ok"):
        err = agent.get("error") or "agent tmux launch failed"
        post_status("agent.launch", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    post_status(
        "online.checkin",
        "ok",
        f"Wan batch agent connected hostname={hn} — warm models (no unload)",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=5,
    )
    return {"ok": True, "hostname": hn, "gpu": gpu, "agent": agent, "worker_refresh": refresh}


async def provision_wan_native_box(
    args: WanNativeProvisionArgs,
    *,
    connect_only: bool = False,
    skip_agent_launch: bool = False,
) -> dict[str, Any]:
    _apply_wan_native_env()
    if connect_only:
        return await connect_wan_native_box(args)

    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"
    root = _models_root(args)

    if is_provision_complete(root, PROVISION_MODE, base, secret):
        log.info("Wan native provision already complete")
        if skip_agent_launch:
            return {"ok": True, "skipped": "already_provisioned"}
        return await connect_wan_native_box(args)

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)

    if not skip_agent_launch:
        early = await connect_wan_native_box(args)
        if not early.get("ok"):
            return early

    post_status(
        "provision.wan_native",
        "ok",
        "downloading Smooth Mix Wan 2.2 stack (i2v high/low MoE + VAE + UMT5)",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=20,
    )

    dl = await _download_wan_stack(args)
    root = _models_root(args)
    manifests = manifests_for_mode(PROVISION_MODE, base, secret)
    miss = missing_artifacts(root, manifests, hf_token=args.hf_token)
    complete = not miss and dl.get("ok", True)
    provision_state_write(
        mode=PROVISION_MODE,
        complete=complete,
        downloaded=list(dl.get("downloaded") or []),
        missing=miss,
        errors=list(dl.get("errors") or []),
    )

    hn = derive_agent_hostname(mode=PROVISION_MODE, label=args.label, instance_id=args.instance_id)
    write_wan_native_env(args, hostname=hn)

    post_status(
        "provision.complete",
        "ok" if complete else "warn",
        "Wan batch box ready" if complete else f"missing: {', '.join(miss[:3])}",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=100,
    )
    return {"ok": complete, "hostname": hn, "download": dl, "missing": miss}


def run_provision_wan_native_cli(argv: list[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(description="Provision Wan 2.2 batch box (warm Comfy, no model unload)")
    p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    p.add_argument("--server", default=os.environ.get("LOBO_SERVER", "wss://www.loboforge.com"))
    p.add_argument("--base-url", default=os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com"))
    p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", os.environ.get("CONTAINER_ID", "")))
    p.add_argument("--label", default=os.environ.get("LOBO_LABEL", "loboforge-wan-native"))
    p.add_argument("--hf-token", default=os.environ.get("HF_TOKEN", ""))
    p.add_argument("--agent-dir", default="/workspace")
    p.add_argument("--connect-only", action="store_true")
    p.add_argument("--skip-agent-launch", action="store_true")
    if argv is None:
        argv = sys.argv[1:]
        if argv and argv[0] == "provision-wan-native":
            argv = argv[1:]
    ns = p.parse_args(argv)
    if not ns.secret:
        print("ERROR: --secret or LOBO_SECRET required", file=sys.stderr)
        return 1

    args = WanNativeProvisionArgs(
        secret=ns.secret,
        server=ns.server,
        base_url=ns.base_url,
        instance_id=ns.instance_id,
        label=ns.label,
        hf_token=ns.hf_token,
        agent_dir=ns.agent_dir,
    )
    result = asyncio.run(
        provision_wan_native_box(
            args,
            connect_only=ns.connect_only,
            skip_agent_launch=ns.skip_agent_launch,
        )
    )
    if not result.get("ok"):
        print("FAILED:", result.get("error") or result.get("missing"), file=sys.stderr)
        return 1
    print("OK hostname=", result.get("hostname"))
    return 0
