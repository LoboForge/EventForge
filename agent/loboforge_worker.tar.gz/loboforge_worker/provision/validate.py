"""Verify manifest artifacts on disk — never claim provision done with missing files."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from ..manifest import Manifest, manifests_for_mode
from .artifact_skips import skip_reason as artifact_skip_reason
from .downloads import file_ok

log = logging.getLogger("worker.provision.validate")

PROVISION_STATE = Path("/workspace/.loboforge-provision-done")


def missing_artifacts(
    models_root: Path,
    manifests: list[Manifest],
    *,
    hf_token: str | None = None,
) -> list[str]:
    """Return dest paths still missing or under min_bytes."""
    missing: list[str] = []
    for manifest in manifests:
        for art in manifest.artifacts:
            dest = models_root / art.dest
            if file_ok(dest, art.min_bytes):
                continue
            if artifact_skip_reason(art.dest) and not art.required:
                continue
            missing.append(art.dest)
    return missing


def provision_state_read() -> dict[str, Any] | None:
    if not PROVISION_STATE.is_file():
        return None
    try:
        return json.loads(PROVISION_STATE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {"legacy": True}


def provision_state_write(
    *,
    mode: str,
    complete: bool,
    downloaded: list[str],
    missing: list[str],
    errors: list[str],
) -> None:
    payload = {
        "mode": mode,
        "complete": complete,
        "downloaded": downloaded,
        "missing": missing,
        "errors": errors,
    }
    PROVISION_STATE.write_text(json.dumps(payload, indent=0), encoding="utf-8")



def missing_required_artifacts(
    models_root: Path,
    manifests: list,
    *,
    hf_token: str | None = None,
) -> list[str]:
    """Required manifest artifacts still missing (skip cache ignored)."""
    missing: list[str] = []
    for manifest in manifests:
        for art in manifest.artifacts:
            if not art.required:
                continue
            dest = models_root / art.dest
            if file_ok(dest, art.min_bytes):
                continue
            missing.append(art.dest)
    return missing


def is_provision_complete(models_root: Path | None, mode: str, base_url: str, secret: str) -> bool:
    """True only when state file says complete and every required artifact exists."""
    if (mode or "").strip().lower() == "ltx-native":
        from ..inference.ltx.paths import missing_artifacts as ltx_missing

        state = provision_state_read()
        if not state or not state.get("complete"):
            return False
        root = models_root
        if root is None:
            from ..paths import find_ltx_models_root

            root = find_ltx_models_root()
        if root is None:
            return False
        miss = ltx_missing(root)
        if miss:
            log.warning("LTX native provision incomplete: %s", miss[:5])
            return False
        layout = root / "layout.json"
        return layout.is_file()

    state = provision_state_read()
    if not state:
        return False
    if state.get("legacy"):
        if not models_root:
            return False
        missing = missing_artifacts(models_root, manifests_for_mode(mode, base_url, secret))
        if missing:
            log.warning("Legacy provision marker but missing: %s", missing[:5])
            return False
        return True
    if not state.get("complete"):
        return False
    if state.get("missing") or state.get("errors"):
        return False
    if not models_root:
        return True
    missing = missing_artifacts(models_root, manifests_for_mode(mode, base_url, secret))
    if missing:
        log.warning("Provision marked complete but missing on disk: %s", missing[:8])
        return False
    return True


def clear_provision_state() -> None:
    PROVISION_STATE.unlink(missing_ok=True)
