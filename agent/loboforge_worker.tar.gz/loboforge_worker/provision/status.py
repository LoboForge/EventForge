"""POST provision progress to LoboForge (best-effort)."""

from __future__ import annotations

import json
import logging
import os

from ..http_util import urlopen as agent_urlopen

log = logging.getLogger("worker.provision.status")


def post_status(
    step: str,
    level: str,
    detail: str,
    *,
    base_url: str | None = None,
    secret: str | None = None,
    instance_id: str | None = None,
    node_uuid: str | None = None,
    pct: int = 0,
) -> None:
    secret = secret or os.environ.get("LOBO_SECRET", "")
    if not secret:
        return
    base = (base_url or os.environ.get("LOBO_BASE_URL") or "https://www.loboforge.com").rstrip("/")
    iid = instance_id or os.environ.get("LOBO_INSTANCE_ID") or os.environ.get("CONTAINER_ID") or "unknown"
    q = f"secret={secret}&instance_id={iid}"
    if node_uuid:
        q += f"&node_uuid={node_uuid}"
    url = f"{base}/api/agent/provision-status?{q}"
    body = json.dumps(
        {
            "step": step,
            "level": level,
            "detail": detail[:500],
            "pct": pct,
            "message": detail[:500],
            "nodeUuid": node_uuid or "",
        }
    ).encode()
    try:
        agent_urlopen(
            url,
            timeout=15,
            method="POST",
            data=body,
            headers={"Content-Type": "application/json"},
        )
    except Exception as ex:
        log.debug("provision-status post failed: %s", ex)
