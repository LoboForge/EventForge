"""Persist artifacts that permanently failed so provision does not retry in a loop."""

from __future__ import annotations

import json
import logging
from pathlib import Path

log = logging.getLogger("worker.provision.artifact_skips")

SKIP_CACHE = Path("/workspace/.loboforge-artifact-skips.json")


def _load() -> dict[str, str]:
    if not SKIP_CACHE.is_file():
        return {}
    try:
        raw = json.loads(SKIP_CACHE.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def skip_reason(dest: str) -> str | None:
    return _load().get(dest)


def mark_skipped(dest: str, reason: str) -> None:
    data = _load()
    if dest in data:
        return
    data[dest] = reason[:500]
    try:
        SKIP_CACHE.parent.mkdir(parents=True, exist_ok=True)
        SKIP_CACHE.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as ex:
        log.warning("Could not write artifact skip cache: %s", ex)


def is_placeholder_repo(repo: str) -> bool:
    r = (repo or "").strip()
    return not r or r.startswith("REPLACE_") or "REPLACE_WITH" in r
