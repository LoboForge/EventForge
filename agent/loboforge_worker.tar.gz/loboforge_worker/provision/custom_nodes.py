"""ComfyUI custom nodes required before the agent accepts graph jobs."""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any
from ..http_util import urlopen as agent_urlopen

from ..paths import resolve_vast_comfy_dir
from .comfyui import DEFAULT_COMFY_PORT, restart_comfyui, wait_for_comfyui, resolve_comfy_python
from .status import post_status

log = logging.getLogger("worker.provision.custom_nodes")

RGTHREE_REPO = "https://github.com/rgthree/rgthree-comfy.git"
POWER_LORA_NODE = "Power Lora Loader (rgthree)"


def install_rgthree(comfy_dir: Path | str, *, python: str | None = None) -> dict:
    """Clone/update rgthree-comfy under ComfyUI custom_nodes."""
    root = Path(comfy_dir)
    custom = root / "custom_nodes"
    custom.mkdir(parents=True, exist_ok=True)
    rgthree = custom / "rgthree-comfy"

    if (rgthree / ".git").is_dir():
        log.info("rgthree-comfy already present — pulling")
        subprocess.run(["git", "-C", str(rgthree), "pull", "--ff-only"], check=False, capture_output=True)
    else:
        log.info("Cloning rgthree-comfy")
        r = subprocess.run(
            ["git", "clone", "--depth", "1", RGTHREE_REPO, str(rgthree)],
            capture_output=True,
            text=True,
        )
        if r.returncode != 0:
            return {"ok": False, "error": r.stderr or "git clone failed"}

    py = python or shutil.which("python3") or "/venv/main/bin/python3"
    req = rgthree / "requirements.txt"
    if Path(py).is_file() and req.is_file():
        subprocess.run([py, "-m", "pip", "install", "-q", "-r", str(req)], check=False)

    return {"ok": True, "path": str(rgthree)}


def power_lora_loader_registered(comfyui_http: str) -> bool:
    url = f"{comfyui_http.rstrip('/')}/object_info"
    try:
        with agent_urlopen(url, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        return POWER_LORA_NODE in data
    except Exception:
        return False


async def ensure_power_lora_loader(args: Any) -> dict:
    """Install rgthree into the live Comfy tree and hard-restart Comfy to load it."""
    http = getattr(args, "comfyui_http", "http://127.0.0.1:18188")
    if power_lora_loader_registered(http):
        return {"ok": True, "registered": True}

    comfy = resolve_vast_comfy_dir(getattr(args, "comfyui_dir", None), args)
    if not comfy:
        return {"ok": False, "error": "ComfyUI directory not found"}

    rg = await asyncio.to_thread(install_rgthree, comfy, python=resolve_comfy_python(comfy))
    if not rg.get("ok"):
        return {"ok": False, "error": rg.get("error") or "rgthree install failed"}

    port = DEFAULT_COMFY_PORT
    if "://" in http and ":" in http.rsplit("://", 1)[-1]:
        try:
            port = int(http.rsplit(":", 1)[-1].split("/", 1)[0])
        except ValueError:
            port = DEFAULT_COMFY_PORT

    log.warning("Power Lora Loader missing — hard-restarting ComfyUI to load rgthree")
    await asyncio.to_thread(restart_comfyui, comfy, port=port)
    if not await asyncio.to_thread(wait_for_comfyui, http, timeout_sec=120, poll_sec=3):
        return {"ok": False, "error": "ComfyUI did not respond after rgthree restart"}

    if power_lora_loader_registered(http):
        return {"ok": True, "registered": True, "restarted": True}

    return {"ok": False, "error": f"{POWER_LORA_NODE} not registered after restart"}


def ace_step_checkpoint_listed(comfyui_http: str) -> bool:
    url = f"{comfyui_http.rstrip('/')}/object_info/CheckpointLoaderSimple"
    try:
        with agent_urlopen(url, timeout=8) as resp:
            data = json.loads(resp.read().decode())
        vals = data.get("CheckpointLoaderSimple", {}).get("input", {}).get("required", {}).get("ckpt_name", [[]])
        names = vals[0] if vals else []
        return any("ace_step" in str(v).lower() for v in names)
    except Exception:
        return False


async def ensure_ace_step_visible(args: Any) -> dict:
    """Restart Comfy if ace_step checkpoint is on disk but not in CheckpointLoaderSimple list."""
    from loboforge_agent import comfyui_is_healthy, ensure_comfyui_running  # type: ignore
    from ..paths import find_models_root

    http = getattr(args, "comfyui_http", "http://127.0.0.1:18188")
    if ace_step_checkpoint_listed(http):
        return {"ok": True, "listed": True}

    root = find_models_root(args)
    ckpt = (root / "checkpoints/ace_step_v1_3.5b.safetensors") if root else None
    if not ckpt or not ckpt.is_file():
        return {"ok": False, "skipped": True, "error": "ace_step checkpoint not downloaded yet"}

    log.warning("ACE-Step checkpoint on disk but not listed — restarting ComfyUI")
    await ensure_comfyui_running(args, allow_restart=True)
    import asyncio

    for _ in range(12):
        if await comfyui_is_healthy(http) and ace_step_checkpoint_listed(http):
            return {"ok": True, "listed": True, "restarted": True}
        await asyncio.sleep(5)

    return {"ok": False, "error": "ace_step_v1_3.5b.safetensors not in ComfyUI checkpoint list"}


def install_rgthree_for_args(args: Any, *, python: str | None = None) -> dict:
    comfy = resolve_vast_comfy_dir(getattr(args, "comfyui_dir", None), args)
    if not comfy:
        return {"ok": False, "error": "ComfyUI directory not found"}
    setattr(args, "comfyui_dir", str(comfy))
    result = install_rgthree(comfy, python=python)
    base = _http_base(args)
    secret = getattr(args, "secret", None)
    node_uuid = getattr(args, "node_uuid", None) or getattr(args, "instance_id", None)
    if result.get("ok"):
        post_status("nodes.install", "ok", "rgthree-comfy ready", base_url=base, secret=secret, node_uuid=node_uuid)
    else:
        post_status(
            "nodes.rgthree",
            "error",
            result.get("error") or "install failed",
            base_url=base,
            secret=secret,
            node_uuid=node_uuid,
        )
    return result


def _http_base(args: Any) -> str:
    server = getattr(args, "server", "wss://www.loboforge.com")
    if server.startswith("ws"):
        return "https://" + server.split("://", 1)[1]
    return server.replace("wss://", "https://").replace("ws://", "http://")
