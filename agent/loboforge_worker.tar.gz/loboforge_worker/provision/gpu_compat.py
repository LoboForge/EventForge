"""GPU preflight — hostname, compute capability, P100 PyTorch, Comfy import smoke.

Ports incident-driven checks from provision_gpu.sh so the Python provision path
matches the bash onstart script (P100 sm_60, docker-id hostnames, torchaudio, etc.).
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import socket
import subprocess
from pathlib import Path
from typing import Any

from .status import post_status

log = logging.getLogger("worker.provision.gpu_compat")

DEFAULT_HOSTNAME_FILE = Path("/workspace/.loboforge-hostname")
MIN_COMPUTE_MAJOR = int(os.environ.get("MIN_COMPUTE_MAJOR", "7"))
BLOCKED_GPU_SUBSTRINGS = ("k80", "m40", "m10")
PYTORCH_CU118_INDEX = "https://download.pytorch.org/whl/cu118"
COMFY_IMPORT_PROBE = (
    "import torch; "
    "assert torch.cuda.is_available(); "
    "import torchaudio; "
    "x=torch.zeros(1,device='cuda'); "
    "(x+1).item(); "
    "torch.cuda.synchronize()"
)


def sanitize_hostname_part(value: str, *, max_len: int = 48) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9\-_]", "", value.replace(" ", "-")).lower()
    return cleaned[:max_len]


def resolve_instance_suffix(
    *,
    instance_id: str | None = None,
    container_id: str | None = None,
) -> str:
    inst = (instance_id or os.environ.get("LOBO_INSTANCE_ID") or "").strip()
    if not inst or inst.lower() == "unknown":
        inst = (
            container_id
            or os.environ.get("CONTAINER_ID")
            or os.environ.get("VAST_CONTAINERLABEL")
            or socket.gethostname()
            or "unknown"
        )
    inst = sanitize_hostname_part(str(inst))
    if not inst:
        inst = "unknown"
    if inst.isdigit():
        return inst[-8:]
    return inst[:8]


def derive_agent_hostname(
    *,
    mode: str = "all",
    label: str | None = None,
    hostname_prefix: str | None = None,
    instance_id: str | None = None,
    hostname_file: Path | str | None = None,
) -> str:
    """Stable loboforge-{label}-{instance} hostname — never raw docker container ids alone."""
    path = Path(hostname_file or os.environ.get("LOBO_HOSTNAME_FILE") or DEFAULT_HOSTNAME_FILE)
    if path.is_file():
        stored = path.read_text(encoding="utf-8").strip()
        if stored and not _looks_like_docker_id(stored):
            return stored

    suffix = resolve_instance_suffix(instance_id=instance_id)
    label = label or os.environ.get("LOBO_LABEL") or ""
    prefix = hostname_prefix or os.environ.get("LOBO_HOSTNAME") or ""

    if label:
        prefix = sanitize_hostname_part(label)
    elif prefix:
        prefix = sanitize_hostname_part(prefix)
        if prefix.endswith(f"-{suffix}"):
            prefix = prefix[: -len(suffix) - 1]
    else:
        gpu = get_gpu_info().get("gpu_name") or "gpu"
        gpu_slug = sanitize_hostname_part(gpu.replace(" ", "-"), max_len=28) or "gpu"
        prefix = f"loboforge-{sanitize_hostname_part(mode.replace(',', '-'))}-{gpu_slug}"

    hn = sanitize_hostname_part(f"{prefix}-{suffix}")
    if hn and not _looks_like_docker_id(hn):
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(hn, encoding="utf-8")
        except OSError:
            pass
    return hn


def _looks_like_docker_id(value: str) -> bool:
    """12-char lowercase hex — rejected by server fleet guards as ghost identity."""
    return bool(re.fullmatch(r"[a-f0-9]{12}", value.strip()))


def get_gpu_info() -> dict[str, Any]:
    """First GPU only — multi-GPU Vast boxes return one CSV line per device."""
    try:
        r = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total,memory.free,compute_cap",
             "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if r.returncode != 0 or not r.stdout.strip():
            return {"gpu_name": "Unknown", "vram_total": 0, "vram_free": 0, "compute_cap": ""}
        first = r.stdout.strip().splitlines()[0]
        parts = [p.strip() for p in first.split(",")]
        compute = parts[3] if len(parts) > 3 else ""
        return {
            "gpu_name": parts[0] if parts else "Unknown",
            "vram_total": int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 0,
            "vram_free": int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0,
            "compute_cap": compute,
        }
    except Exception as ex:
        log.debug("nvidia-smi failed: %s", ex)
        return {"gpu_name": "Unknown", "vram_total": 0, "vram_free": 0, "compute_cap": ""}


def is_p100_gpu(gpu_name: str | None = None) -> bool:
    name = (gpu_name or get_gpu_info().get("gpu_name") or "").lower()
    return "p100" in name


def resolve_comfy_python() -> str:
    for cand in ("/venv/main/bin/python", "/venv/main/bin/python3"):
        if os.path.isfile(cand):
            return cand
    found = shutil.which("python3") or shutil.which("python")
    if found:
        return found
    raise FileNotFoundError("No Python interpreter found for Comfy/PyTorch checks")


def pytorch_cuda_kernel_works(pybin: str | None = None, *, include_torchaudio: bool = False) -> bool:
    py = pybin or resolve_comfy_python()
    probe = COMFY_IMPORT_PROBE if include_torchaudio else (
        "import torch; "
        "assert torch.cuda.is_available(); "
        "x=torch.zeros(1,device='cuda'); "
        "(x+1).item(); "
        "torch.cuda.synchronize()"
    )
    try:
        r = subprocess.run([py, "-c", probe], capture_output=True, text=True, timeout=120)
        return r.returncode == 0
    except Exception:
        return False


def fix_pytorch_for_p100(pybin: str | None = None) -> dict[str, Any]:
    """Reinstall cu118 torch + torchvision + torchaudio (sm_60 + Comfy audio_vae import)."""
    py = pybin or resolve_comfy_python()
    log.warning("P100 detected — reinstalling PyTorch cu118 stack (torch/torchvision/torchaudio)")
    try:
        subprocess.run([py, "-m", "pip", "install", "-q", "-U", "pip"], check=False, timeout=120)
        for packages in (
            ["torch", "torchvision"],
            ["torchaudio==2.7.1+cu118"],
        ):
            r = subprocess.run(
                [py, "-m", "pip", "install", "--force-reinstall", *packages,
                 "--index-url", PYTORCH_CU118_INDEX],
                capture_output=True,
                text=True,
                timeout=900,
            )
            if r.returncode != 0:
                err = (r.stderr or r.stdout or "pip failed")[-600:]
                return {"ok": False, "error": err}
        if not pytorch_cuda_kernel_works(py, include_torchaudio=True):
            return {"ok": False, "error": "CUDA/torchaudio smoke test failed after cu118 reinstall"}
        return {"ok": True, "fixed": True}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}


def assert_gpu_compatible(*, min_compute_major: int | None = None) -> dict[str, Any]:
    """Fail fast on unsupported GPUs; apply P100 fix path when applicable."""
    if shutil.which("nvidia-smi") is None:
        return {"ok": False, "error": "nvidia-smi not found — no usable NVIDIA GPU"}

    info = get_gpu_info()
    gpu_name = info.get("gpu_name") or "Unknown"
    compute_cap = str(info.get("compute_cap") or "")
    gpu_lower = gpu_name.lower()

    if not gpu_name or gpu_name == "Unknown":
        return {"ok": False, "error": "Could not detect GPU name via nvidia-smi"}

    for blocked in BLOCKED_GPU_SUBSTRINGS:
        if blocked in gpu_lower:
            return {
                "ok": False,
                "error": f"GPU '{gpu_name}' is too old for our Comfy/PyTorch stack",
            }

    if is_p100_gpu(gpu_name):
        if pytorch_cuda_kernel_works(include_torchaudio=True):
            return {"ok": True, "gpu_name": gpu_name, "compute_cap": compute_cap, "p100": True}
        fix = fix_pytorch_for_p100()
        if not fix.get("ok"):
            return {**fix, "gpu_name": gpu_name}
        return {"ok": True, "gpu_name": gpu_name, "compute_cap": compute_cap, "p100": True, "pytorch_fixed": True}

    major = min_compute_major if min_compute_major is not None else MIN_COMPUTE_MAJOR
    if compute_cap:
        try:
            cap_major = int(compute_cap.split(".")[0])
            if cap_major < major:
                return {
                    "ok": False,
                    "error": (
                        f"GPU '{gpu_name}' (compute {compute_cap}) is below minimum sm_{major}0 "
                        "for the default PyTorch build"
                    ),
                }
        except ValueError:
            pass

    if not pytorch_cuda_kernel_works():
        return {
            "ok": False,
            "error": f"PyTorch CUDA kernel test failed on {gpu_name}",
            "gpu_name": gpu_name,
        }

    return {"ok": True, "gpu_name": gpu_name, "compute_cap": compute_cap}


def run_gpu_preflight(
    args: Any | None = None,
    *,
    mode: str | None = None,
    base_url: str | None = None,
    secret: str | None = None,
    node_uuid: str | None = None,
    instance_id: str | None = None,
) -> dict[str, Any]:
    """Full pre-provision GPU gate: hostname persist, compatibility, CUDA smoke."""
    mode = mode or getattr(args, "provision_mode", None) if args else None
    mode = mode or os.environ.get("LOBO_MODE", "all")
    base = base_url or _http_base(args)
    secret = secret or (getattr(args, "secret", None) if args else None)
    node_uuid = node_uuid or (getattr(args, "node_uuid", None) if args else None)
    instance_id = instance_id or os.environ.get("LOBO_INSTANCE_ID")

    hostname = derive_agent_hostname(
        mode=mode,
        instance_id=instance_id,
        label=getattr(args, "label", None) if args else None,
    )
    if _looks_like_docker_id(hostname):
        log.warning(
            "Hostname looks like docker container id (%s) — continuing; node_uuid is fleet identity",
            hostname,
        )

    post_status(
        "gpu.preflight", "ok", f"hostname={hostname}",
        base_url=base, secret=secret, node_uuid=node_uuid, instance_id=instance_id,
    )

    compat = assert_gpu_compatible()
    if not compat.get("ok"):
        post_status(
            "gpu.check", "error", compat.get("error", "gpu incompatible"),
            base_url=base, secret=secret, node_uuid=node_uuid, instance_id=instance_id,
        )
        return {**compat, "hostname": hostname}

    detail = f"gpu={compat.get('gpu_name')} compute={compat.get('compute_cap', '?')}"
    if compat.get("pytorch_fixed"):
        detail += " p100_torch_fixed"
    post_status(
        "gpu.check", "ok", detail,
        base_url=base, secret=secret, node_uuid=node_uuid, instance_id=instance_id,
    )

    return {"ok": True, "hostname": hostname, **compat}


def _http_base(args: Any | None) -> str | None:
    if args is None:
        return None
    server = getattr(args, "server", None)
    if not server:
        return None
    if str(server).startswith("ws"):
        return "https://" + str(server).split("://", 1)[1]
    return str(server).replace("wss://", "https://").replace("ws://", "http://")
