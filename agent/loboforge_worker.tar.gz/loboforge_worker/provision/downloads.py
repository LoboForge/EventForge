"""Model artifact downloads (HuggingFace CLI + direct URLs)."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from ..manifest import Artifact
from .download_url import download_to
from .hf_cli import ensure_hf_cli

log = logging.getLogger("worker.provision.downloads")

_TRANSIENT_HINTS = (
    "timeout",
    "timed out",
    "temporarily",
    "connection",
    "reset by peer",
    "broken pipe",
    "errno",
    "unavailable",
    "too many requests",
    "429",
    "502",
    "503",
    "504",
    "ssleof",
    "unexpected eof",
)


def safetensors_header_ok(path: Path) -> bool:
    """Validate .safetensors framing (length-prefixed JSON header). Rejects truncations."""
    try:
        with path.open("rb") as f:
            raw = f.read(8)
            if len(raw) != 8:
                return False
            hdr_len = int.from_bytes(raw, "little")
            # Real headers are typically < few MB; reject nonsense / truncated files.
            if hdr_len < 2 or hdr_len > 64 * 1024 * 1024:
                return False
            hdr = f.read(hdr_len)
            if len(hdr) != hdr_len:
                return False
            meta = json.loads(hdr.decode("utf-8"))
            return isinstance(meta, dict) and bool(meta)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return False


def file_ok(path: Path, min_bytes: int) -> bool:
    """True when file exists, meets min size, and (for safetensors) has a valid header."""
    try:
        if not path.is_file():
            return False
        if path.is_symlink() and not path.resolve().is_file():
            return False
        size = path.stat().st_size
        if size < min_bytes:
            return False
        if path.suffix.lower() == ".safetensors" or path.name.endswith(".safetensors"):
            if not safetensors_header_ok(path):
                return False
        return True
    except OSError:
        return False


def _is_transient_failure(exc: BaseException) -> bool:
    msg = str(exc).lower()
    return any(h in msg for h in _TRANSIENT_HINTS)


def hf_download(artifact: Artifact, dest: Path, hf_token: str | None = None) -> None:
    from .artifact_skips import is_placeholder_repo

    if is_placeholder_repo(artifact.hf_repo):
        raise RuntimeError(f"HF repo not configured for {dest.name} ({artifact.hf_repo})")

    if not ensure_hf_cli():
        raise RuntimeError("hf CLI not available — install huggingface_hub[cli]")

    dest.parent.mkdir(parents=True, exist_ok=True)
    env = None
    if hf_token:
        env = {**os.environ, "HF_TOKEN": hf_token, "HUGGINGFACE_HUB_TOKEN": hf_token}
    with tempfile.TemporaryDirectory(prefix="hf_") as tmp:
        tmp_path = Path(tmp)
        cmd = [
            "hf", "download", artifact.hf_repo,
            "--include", artifact.hf_include,
            "--local-dir", str(tmp_path),
        ]
        log.info("Downloading %s (%s) → %s", artifact.hf_repo, artifact.hf_include, dest.name)
        subprocess.run(cmd, check=True, env=env, timeout=3600, capture_output=True, text=True)
        matches = list(tmp_path.rglob(artifact.hf_filename))
        if not matches:
            sample = [p.relative_to(tmp_path).as_posix() for p in list(tmp_path.rglob("*.safetensors"))[:8]]
            hint = f"; hf output had no {artifact.hf_filename}"
            if sample:
                hint += f" (found: {', '.join(sample)})"
            raise FileNotFoundError(f"{artifact.hf_filename} not found after hf download{hint}")
        shutil.move(str(matches[0]), str(dest))


def ensure_artifact(artifact: Artifact, models_root: Path, hf_token: str | None = None) -> bool:
    from .artifact_skips import clear_skip, is_placeholder_repo, mark_skipped, skip_reason

    dest = models_root / artifact.dest
    if file_ok(dest, artifact.min_bytes):
        return False

    # Corrupt / truncated leftovers — remove so we re-pull.
    if dest.is_file() or dest.is_symlink():
        try:
            dest.unlink(missing_ok=True)
        except OSError:
            pass

    reason = skip_reason(artifact.dest)
    if reason:
        if artifact.required:
            # Required artifacts always retry (self-heal). Skip cache is for optional only.
            clear_skip(artifact.dest)
            log.info("Retrying required artifact %s (cleared skip: %s)", artifact.dest, reason[:120])
        else:
            log.debug("Skipping %s — previously failed: %s", artifact.dest, reason)
            return False

    source_url = (artifact.url or "").strip()
    if artifact.url_env:
        source_url = (os.environ.get(artifact.url_env) or "").strip()
        if not source_url:
            msg = f"{artifact.url_env} not set — skipping {artifact.dest}"
            if not artifact.required:
                mark_skipped(artifact.dest, msg)
            raise RuntimeError(msg)

    try:
        if source_url:
            if not download_to(source_url, dest, hf_token=hf_token):
                raise RuntimeError(f"URL download failed: {source_url}")
        elif artifact.hf_repo:
            if is_placeholder_repo(artifact.hf_repo):
                mark_skipped(artifact.dest, f"repo not configured ({artifact.hf_repo})")
                raise RuntimeError(f"HF repo not configured for {artifact.dest}")
            hf_download(artifact, dest, hf_token)
        else:
            mark_skipped(artifact.dest, "no download source configured")
            raise RuntimeError(f"No download source for {artifact.dest}")
    except Exception as ex:
        # Permanent skip only for optional artifacts, or hard config errors.
        if (not artifact.required) or (
            not _is_transient_failure(ex)
            and ("not configured" in str(ex).lower() or "no download source" in str(ex).lower())
        ):
            mark_skipped(artifact.dest, str(ex))
        elif artifact.required:
            clear_skip(artifact.dest)
        raise

    if not file_ok(dest, artifact.min_bytes):
        size = dest.stat().st_size if dest.is_file() else 0
        err = f"Download incomplete or corrupt: {dest} ({size} bytes)"
        try:
            dest.unlink(missing_ok=True)
        except OSError:
            pass
        if not artifact.required:
            mark_skipped(artifact.dest, err)
        raise RuntimeError(err)

    clear_skip(artifact.dest)
    return True


def ensure_wan_diffusion_aliases(models_root: Path) -> None:
    """Comfy UNETLoader often lists top-level diffusion_models/; Wan files live under Wan2.2/."""
    dm = models_root / "diffusion_models"
    names = (
        "wan2.2_i2v_high_noise_14B_fp8_scaled.safetensors",
        "wan2.2_i2v_low_noise_14B_fp8_scaled.safetensors",
        "wan2.2_t2v_high_noise_14B_fp8_scaled.safetensors",
        "wan2.2_t2v_low_noise_14B_fp8_scaled.safetensors",
    )
    for name in names:
        src = dm / "Wan2.2" / name
        dst = dm / name
        if not src.is_file():
            continue
        if dst.is_symlink() or dst.is_file():
            # Replace broken symlink / stale empty file
            try:
                if dst.is_symlink() or (dst.is_file() and dst.stat().st_size < 1_000_000):
                    dst.unlink(missing_ok=True)
                else:
                    continue
            except OSError:
                continue
        try:
            dst.symlink_to(Path("Wan2.2") / name)
            log.info("Linked %s -> Wan2.2/%s", name, name)
        except OSError as ex:
            log.warning("Could not link %s: %s", name, ex)


def link_ltx_audio_checkpoint(models_root: Path) -> None:
    """Graph expects checkpoints/LTX2/LTX23_audio_vae_bf16.safetensors — symlink from vae/."""
    vae = models_root / "vae/LTX23_audio_vae_bf16.safetensors"
    ckpt = models_root / "checkpoints/LTX2/LTX23_audio_vae_bf16.safetensors"
    if not vae.is_file() or ckpt.is_file():
        return
    ckpt.parent.mkdir(parents=True, exist_ok=True)
    try:
        ckpt.symlink_to(Path("../../vae/LTX23_audio_vae_bf16.safetensors"))
    except OSError:
        shutil.copy2(vae, ckpt)
