"""Model artifact downloads (HuggingFace CLI + direct URLs)."""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from ..manifest import Artifact
from .download_url import download_to
from .hf_cli import ensure_hf_cli

log = logging.getLogger("worker.provision.downloads")


def file_ok(path: Path, min_bytes: int) -> bool:
    return path.is_file() and path.stat().st_size >= min_bytes


def hf_download(artifact: Artifact, dest: Path, hf_token: str | None = None) -> None:
    from .artifact_skips import is_placeholder_repo

    if is_placeholder_repo(artifact.hf_repo):
        raise RuntimeError(f"HF repo not configured for {dest.name} ({artifact.hf_repo})")

    if not ensure_hf_cli():
        raise RuntimeError("hf CLI not available — install huggingface_hub[cli]")

    dest.parent.mkdir(parents=True, exist_ok=True)
    env = None
    if hf_token:
        env = {**os.environ, "HF_TOKEN": hf_token, "HUGGINGFACE_HUB_TOKEN": hf_token}
    with tempfile.TemporaryDirectory(prefix="hf_") as tmp:
        tmp_path = Path(tmp)
        cmd = [
            "hf", "download", artifact.hf_repo,
            "--include", artifact.hf_include,
            "--local-dir", str(tmp_path),
        ]
        log.info("Downloading %s (%s) → %s", artifact.hf_repo, artifact.hf_include, dest.name)
        subprocess.run(cmd, check=True, env=env, timeout=3600, capture_output=True, text=True)
        matches = list(tmp_path.rglob(artifact.hf_filename))
        if not matches:
            sample = [p.relative_to(tmp_path).as_posix() for p in list(tmp_path.rglob("*.safetensors"))[:8]]
            hint = f"; hf output had no {artifact.hf_filename}"
            if sample:
                hint += f" (found: {', '.join(sample)})"
            raise FileNotFoundError(f"{artifact.hf_filename} not found after hf download{hint}")
        shutil.move(str(matches[0]), str(dest))


def ensure_artifact(artifact: Artifact, models_root: Path, hf_token: str | None = None) -> bool:
    from .artifact_skips import is_placeholder_repo, mark_skipped, skip_reason

    dest = models_root / artifact.dest
    if file_ok(dest, artifact.min_bytes):
        return False

    reason = skip_reason(artifact.dest)
    if reason:
        log.debug("Skipping %s — previously failed: %s", artifact.dest, reason)
        return False

    if dest.is_file() and dest.stat().st_size < artifact.min_bytes:
        dest.unlink(missing_ok=True)

    source_url = (artifact.url or "").strip()
    if artifact.url_env:
        source_url = (os.environ.get(artifact.url_env) or "").strip()
        if not source_url:
            msg = f"{artifact.url_env} not set — skipping {artifact.dest}"
            mark_skipped(artifact.dest, msg)
            raise RuntimeError(msg)

    try:
        if source_url:
            if not download_to(source_url, dest, hf_token=hf_token):
                raise RuntimeError(f"URL download failed: {source_url}")
        elif artifact.hf_repo:
            if is_placeholder_repo(artifact.hf_repo):
                mark_skipped(artifact.dest, f"repo not configured ({artifact.hf_repo})")
                raise RuntimeError(f"HF repo not configured for {artifact.dest}")
            hf_download(artifact, dest, hf_token)
        else:
            mark_skipped(artifact.dest, "no hf repo or url configured")
            raise RuntimeError(f"No download source for {artifact.dest}")
    except Exception as ex:
        mark_skipped(artifact.dest, str(ex))
        raise

    if not file_ok(dest, artifact.min_bytes):
        err = f"Download incomplete: {dest} ({dest.stat().st_size if dest.is_file() else 0} bytes)"
        mark_skipped(artifact.dest, err)
        raise RuntimeError(err)
    return True


def link_ltx_audio_checkpoint(models_root: Path) -> None:
    """Graph expects checkpoints/LTX2/LTX23_audio_vae_bf16.safetensors — symlink from vae/."""
    vae = models_root / "vae/LTX23_audio_vae_bf16.safetensors"
    ckpt = models_root / "checkpoints/LTX2/LTX23_audio_vae_bf16.safetensors"
    if not vae.is_file() or ckpt.is_file():
        return
    ckpt.parent.mkdir(parents=True, exist_ok=True)
    try:
        ckpt.symlink_to(Path("../../vae/LTX23_audio_vae_bf16.safetensors"))
    except OSError:
        shutil.copy2(vae, ckpt)
