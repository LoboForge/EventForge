"""Provision dedicated LTX 2.3 native boxes — FP8 + audio VAEs, no ComfyUI."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..bootstrap import install_agent_deps, refresh_from_server
from ..inference.ltx.gemma import GEMMA_HF_REPO, gemma_hf_dir, hf_gemma_ready
from ..inference.ltx.paths import (
    DEV_CHECKPOINT_RELS,
    DEFAULT_LTX_MODEL_ROOT,
    DEFAULT_LTX_REPO,
    DISTILLED_CHECKPOINT_REL,
    DISTILLED_LORA_REL,
    missing_artifacts,
    use_distilled_checkpoint,
    write_layout,
)
from ..manifest import Artifact, Manifest, load_local, manifests_for_mode
from .bootstrap_box import (
    BootstrapArgs,
    export_hf_token,
    launch_agent_tmux,
    resolve_hf_token,
    resolve_python,
)
from .downloads import file_ok, link_ltx_audio_checkpoint
from .gpu_compat import derive_agent_hostname, run_gpu_preflight
from .hf_cli import ensure_hf_cli
from .status import post_status
from .validate import provision_state_write

log = logging.getLogger("worker.provision.ltx_native")

PROVISION_MODE = "ltx-native"
LTX_REPO_URL = "https://github.com/Lightricks/LTX-2.git"


def download_hf_gemma(root: Path, hf_token: str | None = None) -> None:
    """HF Gemma tree for ltx-pipelines (not the Comfy FP4 single-file encoder)."""
    dest = gemma_hf_dir(root)
    if hf_gemma_ready(root):
        log.info("HF Gemma already present at %s", dest)
        return
    if not ensure_hf_cli():
        raise RuntimeError("hf CLI not available")

    env = None
    if hf_token:
        env = {**os.environ, "HF_TOKEN": hf_token, "HUGGINGFACE_HUB_TOKEN": hf_token}

    dest.mkdir(parents=True, exist_ok=True)
    cmd = ["hf", "download", GEMMA_HF_REPO, "--local-dir", str(dest)]
    log.info("Downloading HF Gemma %s → %s (~23GB)", GEMMA_HF_REPO, dest)
    subprocess.run(cmd, check=True, env=env, timeout=14_400, capture_output=True, text=True)
    if not hf_gemma_ready(root):
        raise RuntimeError(f"HF Gemma incomplete under {dest}")


def _skip_native_checkpoint_artifact(art: Artifact) -> bool:
    if use_distilled_checkpoint():
        return art.dest in DEV_CHECKPOINT_RELS or art.dest == DISTILLED_LORA_REL
    if art.dest == DISTILLED_CHECKPOINT_REL:
        return True
    from ..inference.ltx.paths import BF16_CHECKPOINT_REL, FP8_CHECKPOINT_REL, native_ltx_fp8_kernels_supported

    if art.dest == FP8_CHECKPOINT_REL and not native_ltx_fp8_kernels_supported():
        return True
    if art.dest == BF16_CHECKPOINT_REL and native_ltx_fp8_kernels_supported():
        return True
    return False


def native_hf_download(artifact: Artifact, root: Path, hf_token: str | None = None) -> None:
    """HF download into LTX_MODEL_ROOT (not Comfy models/ tree)."""
    import subprocess

    dest = root / artifact.dest
    if file_ok(dest, artifact.min_bytes):
        return
    if not ensure_hf_cli():
        raise RuntimeError("hf CLI not available")

    env = None
    if hf_token:
        env = {**os.environ, "HF_TOKEN": hf_token, "HUGGINGFACE_HUB_TOKEN": hf_token}

    cmd = [
        "hf", "download", artifact.hf_repo,
        "--include", artifact.hf_include,
        "--local-dir", str(root),
    ]
    log.info("HF %s → %s", artifact.hf_repo, dest)
    subprocess.run(cmd, check=True, env=env, timeout=7200, capture_output=True, text=True)

    matches = list(root.rglob(artifact.hf_filename))
    if not matches:
        raise FileNotFoundError(f"{artifact.hf_filename} not found under {root}")
    source = matches[0]
    if source.resolve() != dest.resolve():
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.is_file():
            dest.unlink(missing_ok=True)
        source.rename(dest)
    if not file_ok(dest, artifact.min_bytes):
        raise RuntimeError(f"incomplete {dest}")


@dataclass
class LtxNativeProvisionArgs:
    secret: str
    server: str = "wss://www.loboforge.com"
    base_url: str = "https://www.loboforge.com"
    instance_id: str = ""
    label: str = "loboforge-ltx"
    hf_token: str = ""
    agent_dir: str = "/workspace"
    ltx_model_root: str = ""
    ltx_repo: str = ""


def _models_root(args: LtxNativeProvisionArgs) -> Path:
    raw = args.ltx_model_root or os.environ.get("LTX_MODEL_ROOT", "")
    return Path(raw) if raw else DEFAULT_LTX_MODEL_ROOT


def _repo_root(args: LtxNativeProvisionArgs) -> Path:
    raw = args.ltx_repo or os.environ.get("LTX_REPO", "")
    return Path(raw) if raw else DEFAULT_LTX_REPO


def write_native_env(args: LtxNativeProvisionArgs, *, hostname: str) -> None:
    root = _models_root(args)
    repo = _repo_root(args)
    env_path = Path(args.agent_dir) / ".loboforge-env"
    lines = [
        'export LOBO_EXECUTOR="native"',
        'export LOBO_SKIP_COMFY="1"',
        'export LOBO_SKIP_LORA_PULL="1"',
        f'export LOBO_SECRET="{args.secret}"',
        f'export LOBO_SERVER="{args.server}"',
        f'export LOBO_BASE_URL="{args.base_url}"',
        f'export LOBO_MODE="{PROVISION_MODE}"',
        f'export MODE="{PROVISION_MODE}"',
        'export LOBO_WAN="0"',
        'export LOBO_LTX23="1"',
        'export LOBO_MUSIC="0"',
        'export LOBO_LTX_VARIANT="distilled"',
        f'export LTX_MODEL_ROOT="{root}"',
        f'export LTX_REPO="{repo}"',
        f'export LOBO_LABEL="{args.label}"',
        f'export LOBO_HOSTNAME="{hostname}"',
    ]
    if args.hf_token:
        lines.append(f'export HF_TOKEN="{args.hf_token}"')
        lines.append(f'export HUGGINGFACE_HUB_TOKEN="{args.hf_token}"')
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    log.info("Wrote %s", env_path)


def install_ltx_pipelines(repo: Path, python: str) -> dict[str, Any]:
    """Clone Lightricks/LTX-2 and install ltx-core + ltx-pipelines editable."""
    repo.parent.mkdir(parents=True, exist_ok=True)
    if not (repo / ".git").is_dir():
        log.info("Cloning %s -> %s", LTX_REPO_URL, repo)
        r = subprocess.run(
            ["git", "clone", "--depth", "1", LTX_REPO_URL, str(repo)],
            capture_output=True,
            text=True,
            timeout=600,
        )
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or r.stdout or "git clone failed")[:500]}

    errors: list[str] = []
    for pkg in ("ltx-core", "ltx-pipelines"):
        pkg_dir = repo / "packages" / pkg
        if not pkg_dir.is_dir():
            errors.append(f"missing {pkg_dir}")
            continue
        log.info("pip install -e %s", pkg_dir)
        r = subprocess.run(
            [python, "-m", "pip", "install", "-q", "-e", str(pkg_dir)],
            capture_output=True,
            text=True,
            timeout=900,
        )
        if r.returncode != 0:
            errors.append(f"{pkg}: {(r.stderr or r.stdout or 'pip failed')[:200]}")

    if errors:
        return {"ok": False, "error": "; ".join(errors)}

    verify = subprocess.run(
        [python, "-c", "from ltx_pipelines.distilled import DistilledPipeline"],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if verify.returncode != 0:
        detail = (verify.stderr or verify.stdout or "import failed")[:400]
        return {"ok": False, "error": f"ltx_pipelines import failed: {detail}"}
    return {"ok": True, "repo": str(repo)}


async def download_native_stack(
    args: LtxNativeProvisionArgs,
    *,
    node_uuid: str,
) -> dict[str, Any]:
    root = _models_root(args)
    root.mkdir(parents=True, exist_ok=True)
    base = args.base_url.rstrip("/")
    secret = args.secret

    manifests = manifests_for_mode(PROVISION_MODE, base, secret)
    if not manifests:
        local = load_local("ltx23_native_stack")
        manifests = [local] if local else []

    if not manifests:
        return {"ok": False, "error": "ltx23_native_stack manifest missing"}

    await asyncio.to_thread(ensure_hf_cli)
    hf_token = args.hf_token or os.environ.get("HF_TOKEN")
    downloaded: list[str] = []
    errors: list[str] = []

    total = sum(len(m.artifacts) for m in manifests)
    done = 0

    for manifest in manifests:
        for art in manifest.artifacts:
            if _skip_native_checkpoint_artifact(art):
                log.info("Skipping %s — not needed for this GPU", art.dest)
                continue
            done += 1
            pct = int(done / max(total, 1) * 85)
            post_status(
                "models.ltx_native",
                "ok",
                f"downloading {art.dest} ({done}/{total})",
                base_url=base,
                secret=secret,
                node_uuid=node_uuid,
                pct=pct,
            )
            dest = root / art.dest
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                await asyncio.to_thread(native_hf_download, art, root, hf_token)
                if file_ok(dest, art.min_bytes):
                    downloaded.append(art.dest)
                else:
                    errors.append(art.dest)
            except Exception as ex:
                log.warning("Download failed %s: %s", art.dest, ex)
                errors.append(art.dest)

    await asyncio.to_thread(link_ltx_audio_checkpoint, root)

    post_status(
        "models.gemma_hf",
        "ok",
        f"downloading HF Gemma ({GEMMA_HF_REPO})",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=88,
    )
    try:
        await asyncio.to_thread(download_hf_gemma, root, hf_token)
        downloaded.append(f"{gemma_hf_dir(root).name}/")
    except Exception as ex:
        log.warning("HF Gemma download failed: %s", ex)
        errors.append("text_encoders/gemma-hf")

    missing = missing_artifacts(root)
    try:
        write_layout(root, repo=_repo_root(args))
    except Exception as ex:
        log.warning("Could not write layout.json yet: %s", ex)
    return {
        "ok": not missing and not errors,
        "downloaded": downloaded,
        "missing": missing,
        "errors": errors,
    }


async def connect_native_box(args: LtxNativeProvisionArgs) -> dict[str, Any]:
    """Join the fleet immediately — GPU check, env, agent tmux. No model downloads."""
    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"
    python = resolve_python()

    os.environ["LOBO_EXECUTOR"] = "native"
    os.environ["LOBO_SKIP_COMFY"] = "1"
    os.environ["LTX_MODEL_ROOT"] = str(_models_root(args))
    os.environ["LTX_REPO"] = str(_repo_root(args))

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)
    install_agent_deps(python)

    hn = derive_agent_hostname(
        mode=PROVISION_MODE,
        label=args.label,
        instance_id=args.instance_id,
    )

    gpu = await asyncio.to_thread(
        run_gpu_preflight,
        args,
        mode=PROVISION_MODE,
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        instance_id=args.instance_id or None,
    )
    if not gpu.get("ok"):
        err = gpu.get("error") or "GPU preflight failed"
        post_status("gpu.preflight", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    refresh = refresh_from_server(Path(args.agent_dir), base_url=base, force_worker=True)
    if not refresh.get("worker_ok"):
        log.warning("Worker package verify: %s", refresh.get("worker_error"))

    write_native_env(args, hostname=hn)

    boot = BootstrapArgs(
        secret=secret,
        server=args.server,
        base_url=base,
        provision_mode=PROVISION_MODE,
        instance_id=args.instance_id,
        label=args.label,
        hostname=hn,
        hf_token=args.hf_token,
        agent_dir=args.agent_dir,
    )
    agent = launch_agent_tmux(boot, hostname=hn)
    if not agent.get("ok"):
        err = agent.get("error") or "agent tmux launch failed"
        post_status("agent.launch", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "gpu": gpu}

    post_status(
        "online.checkin",
        "ok",
        f"agent connected hostname={hn} — downloads continue in background",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=5,
    )
    post_status(
        "agent.launch",
        "ok",
        f"tmux session loboforge-agent hostname={hn}",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
    )
    return {"ok": True, "hostname": hn, "gpu": gpu, "agent": agent, "worker_refresh": refresh}


async def provision_ltx_native_box(
    args: LtxNativeProvisionArgs,
    *,
    connect_only: bool = False,
    skip_agent_launch: bool = False,
) -> dict[str, Any]:
    """
    Native LTX provision: connect to fleet first, then HF models + LTX-2 repo.
    Does not install or start ComfyUI.
    """
    if connect_only:
        return await connect_native_box(args)

    base = args.base_url.rstrip("/")
    secret = args.secret
    node_uuid = args.instance_id or "unknown"
    python = resolve_python()

    os.environ["LOBO_EXECUTOR"] = "native"
    os.environ["LOBO_SKIP_COMFY"] = "1"
    os.environ["LTX_MODEL_ROOT"] = str(_models_root(args))
    os.environ["LTX_REPO"] = str(_repo_root(args))

    args.hf_token = resolve_hf_token(args.hf_token)
    export_hf_token(args.hf_token)
    install_agent_deps(python)

    post_status("provision.ltx_native", "ok", "starting native LTX provision", base_url=base, secret=secret, node_uuid=node_uuid)

    hn = derive_agent_hostname(
        mode=PROVISION_MODE,
        label=args.label,
        instance_id=args.instance_id,
    )

    if not skip_agent_launch:
        connect = await connect_native_box(args)
        if not connect.get("ok"):
            return connect
        hn = connect.get("hostname") or hn
        gpu = connect.get("gpu") or {}
        refresh = connect.get("worker_refresh") or {}
    else:
        gpu = await asyncio.to_thread(
            run_gpu_preflight,
            args,
            mode=PROVISION_MODE,
            base_url=base,
            secret=secret,
            node_uuid=node_uuid,
            instance_id=args.instance_id or None,
        )
        if not gpu.get("ok"):
            err = gpu.get("error") or "GPU preflight failed"
            post_status("gpu.preflight", "error", err, base_url=base, secret=secret, node_uuid=node_uuid)
            return {"ok": False, "error": err, "gpu": gpu}

        refresh = refresh_from_server(Path(args.agent_dir), base_url=base, force_worker=True)
        if not refresh.get("worker_ok"):
            log.warning("Worker package verify: %s", refresh.get("worker_error"))

    dl = await download_native_stack(args, node_uuid=node_uuid)
    if not dl.get("ok"):
        err = f"model download incomplete missing={dl.get('missing')}"
        provision_state_write(
            mode=PROVISION_MODE,
            complete=False,
            downloaded=dl.get("downloaded", []),
            missing=dl.get("missing", []),
            errors=dl.get("errors", []),
        )
        post_status("models.ltx_native", "error", err[:500], base_url=base, secret=secret, node_uuid=node_uuid)
        return {"ok": False, "error": err, "download": dl}

    repo = _repo_root(args)
    post_status("ltx.repo", "ok", "installing Lightricks/LTX-2 packages", base_url=base, secret=secret, node_uuid=node_uuid, pct=90)
    repo_result = await asyncio.to_thread(install_ltx_pipelines, repo, python)
    if not repo_result.get("ok"):
        err = repo_result.get("error") or "LTX-2 pip install failed"
        post_status("ltx.repo", "error", err[:500], base_url=base, secret=secret, node_uuid=node_uuid)
        provision_state_write(
            mode=PROVISION_MODE,
            complete=False,
            downloaded=dl.get("downloaded", []),
            missing=[],
            errors=[err],
        )
        return {"ok": False, "error": err, "download": dl, "ltx_repo": repo_result}

    layout = write_layout(_models_root(args), repo=repo)
    log.info("Wrote layout %s", layout)

    provision_state_write(
        mode=PROVISION_MODE,
        complete=True,
        downloaded=dl.get("downloaded", []),
        missing=[],
        errors=[] if repo_result.get("ok") else [repo_result.get("error", "ltx pip")],
    )
    marker = Path(args.agent_dir) / ".loboforge-provision-done"
    if not marker.is_file():
        marker.touch()

    if skip_agent_launch:
        write_native_env(args, hostname=hn)

    post_status(
        "provision.complete",
        "ok",
        "LTX native ready (distilled-1.1 + audio, no Comfy)",
        base_url=base,
        secret=secret,
        node_uuid=node_uuid,
        pct=100,
    )

    return {
        "ok": True,
        "hostname": hn,
        "layout": str(layout),
        "download": dl,
        "ltx_repo": repo_result,
        "worker_refresh": refresh,
    }


def run_provision_ltx_native_cli(argv: list[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(description="Provision LTX 2.3 native box (FP8 + audio, no Comfy)")
    p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    p.add_argument("--server", default=os.environ.get("LOBO_SERVER", "wss://www.loboforge.com"))
    p.add_argument("--base-url", default=os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com"))
    p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", os.environ.get("CONTAINER_ID", "")))
    p.add_argument("--label", default=os.environ.get("LOBO_LABEL", "loboforge-ltx"))
    p.add_argument("--hf-token", default=os.environ.get("HF_TOKEN", ""))
    p.add_argument("--agent-dir", default="/workspace")
    p.add_argument("--models-root", default=os.environ.get("LTX_MODEL_ROOT", ""))
    p.add_argument("--ltx-repo", default=os.environ.get("LTX_REPO", ""))
    p.add_argument(
        "--connect-only",
        action="store_true",
        help="GPU check + launch agent tmux only (no downloads)",
    )
    p.add_argument(
        "--skip-agent-launch",
        action="store_true",
        help="Downloads only — agent already running from early connect",
    )
    if argv is None:
        argv = sys.argv[1:]
        if argv and argv[0] == "provision-ltx-native":
            argv = argv[1:]
    ns = p.parse_args(argv)
    if not ns.secret:
        print("ERROR: --secret or LOBO_SECRET required", file=sys.stderr)
        return 1

    args = LtxNativeProvisionArgs(
        secret=ns.secret,
        server=ns.server,
        base_url=ns.base_url,
        instance_id=ns.instance_id,
        label=ns.label,
        hf_token=ns.hf_token,
        agent_dir=ns.agent_dir,
        ltx_model_root=ns.models_root,
        ltx_repo=ns.ltx_repo,
    )
    result = asyncio.run(
        provision_ltx_native_box(
            args,
            connect_only=ns.connect_only,
            skip_agent_launch=ns.skip_agent_launch,
        )
    )
    if not result.get("ok"):
        print("FAILED:", result.get("error"), file=sys.stderr)
        return 1
    print("OK hostname=", result.get("hostname"), "layout=", result.get("layout"))
    return 0
