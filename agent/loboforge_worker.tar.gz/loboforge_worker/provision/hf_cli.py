"""Ensure HuggingFace CLI is available for model downloads."""

from __future__ import annotations

import logging
import shutil
import subprocess

log = logging.getLogger("worker.provision.hf_cli")


def ensure_hf_cli(python: str | None = None) -> bool:
    if shutil.which("hf"):
        return True
    py = python or shutil.which("python3") or "python3"
    log.info("Installing huggingface_hub CLI (hf)...")
    try:
        subprocess.run(
            [py, "-m", "pip", "install", "-q", "-U", "huggingface_hub[cli]"],
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
    except Exception as ex:
        log.warning("Could not install huggingface_hub CLI: %s", ex)
        return bool(shutil.which("hf"))
    return bool(shutil.which("hf"))
