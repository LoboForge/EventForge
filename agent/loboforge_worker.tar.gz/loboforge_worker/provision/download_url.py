"""Download a single artifact URL (curl / hf / gdown)."""

from __future__ import annotations

import logging
import re
import shutil
import subprocess
from pathlib import Path

from ..http_util import urlopen as agent_urlopen

log = logging.getLogger("worker.provision.download_url")

MIN_BYTES = 1_048_576
_HF_RE = re.compile(
    r"https?://huggingface\.co/([^/]+/[^/]+)/(resolve|blob)/[^/]+/(.+?)(\?.*)?$",
)


def normalize_lora_rel(file_path: str) -> str:
    rel = file_path.strip()
    if not rel:
        return rel
    if rel.startswith("loras/"):
        return rel
    if "/" in rel:
        return f"loras/{rel}"
    return f"loras/{rel}"


def download_to(source_url: str, dest: Path, *, hf_token: str | None = None) -> bool:
    dest.parent.mkdir(parents=True, exist_ok=True)
    url = source_url.strip()
    if not url:
        return False

    if "drive.google.com" in url or "docs.google.com" in url:
        return _gdown(url, dest)

    if "huggingface.co" in url:
        if _hf_download(url, dest, hf_token):
            return dest.is_file() and dest.stat().st_size > MIN_BYTES
        log.warning("HF download failed, trying curl: %s", url)
        return _curl(url, dest)

    return _curl(url, dest)


def _curl(url: str, dest: Path) -> bool:
    try:
        with agent_urlopen(url, timeout=600) as resp:
            data = resp.read()
        part = dest.with_suffix(dest.suffix + ".part")
        part.write_bytes(data)
        part.replace(dest)
        return dest.stat().st_size > MIN_BYTES
    except Exception as ex:
        log.warning("curl download failed %s: %s", dest.name, ex)
        dest.unlink(missing_ok=True)
        return False


def _gdown(url: str, dest: Path) -> bool:
    if not shutil.which("gdown"):
        log.warning("gdown not installed — skipping %s", url)
        return False
    try:
        subprocess.run(
            ["gdown", "--no-cookies", url, "-O", str(dest)],
            check=True,
            capture_output=True,
            text=True,
            timeout=900,
        )
        if dest.is_file() and dest.stat().st_size > MIN_BYTES:
            return True
        dest.unlink(missing_ok=True)
        return False
    except Exception as ex:
        log.warning("gdown failed %s: %s", dest.name, ex)
        dest.unlink(missing_ok=True)
        return False


def _hf_download(url: str, dest: Path, hf_token: str | None) -> bool:
    match = _HF_RE.match(url)
    if not match:
        return False
    repo, _, file_path = match.group(1), match.group(2), match.group(3)
    if not shutil.which("hf"):
        return False
    tmp = dest.parent / f".hf_tmp_{dest.name}"
    if tmp.exists():
        shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True, exist_ok=True)
    env = None
    if hf_token:
        import os

        env = os.environ.copy()
        env["HF_TOKEN"] = hf_token
    try:
        subprocess.run(
            ["hf", "download", repo, file_path, "--local-dir", str(tmp)],
            check=True,
            capture_output=True,
            text=True,
            timeout=900,
            env=env,
        )
        found = next(tmp.rglob(Path(file_path).name), None)
        if found and found.is_file():
            shutil.move(str(found), dest)
            return dest.stat().st_size > MIN_BYTES
        return False
    except Exception as ex:
        log.warning("hf download failed %s/%s: %s", repo, file_path, ex)
        return False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
