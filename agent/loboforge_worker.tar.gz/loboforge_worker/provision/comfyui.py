"""ComfyUI git upgrade for Microsoft Lens (CLIPLoader type=lens).

Vast.ai ComfyUI images ship an older ComfyUI tag without Lens support.
Image / all / both modes need origin/master before Lens workflows validate.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Callable

from ..paths import find_comfy_dir
from .status import post_status

log = logging.getLogger("worker.provision.comfyui")

DEFAULT_COMFY_HTTP = "http://127.0.0.1:18188"
DEFAULT_COMFY_PORT = 18188


def mode_needs_lens(mode: str | None) -> bool:
    """True when this box may run Microsoft Lens jobs."""
    m = (mode or "all").lower().strip()
    if m in ("image", "all", "both"):
        return True
    return "image" in m


def clip_loader_supports_lens(comfy_http: str, *, timeout: float = 8.0) -> bool:
    """Query ComfyUI object_info — Lens needs CLIPLoader type=lens."""
    url = f"{comfy_http.rstrip('/')}/object_info/CLIPLoader"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode())
        types = data["CLIPLoader"]["input"]["required"]["type"][0]
        return "lens" in types
    except (urllib.error.URLError, TimeoutError, KeyError, json.JSONDecodeError, IndexError) as ex:
        log.debug("Could not probe CLIPLoader types at %s: %s", url, ex)
        return False


def comfyui_is_up(comfy_http: str, *, timeout: float = 3.0) -> bool:
    try:
        req = urllib.request.Request(f"{comfy_http.rstrip('/')}/", method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, TimeoutError, OSError):
        return False


def resolve_comfy_python(comfy_dir: Path | None = None) -> str:
    for cand in ("/venv/main/bin/python", "/venv/main/bin/python3"):
        if os.path.isfile(cand):
            return cand
    if comfy_dir:
        for rel in ("venv/bin/python", ".venv/bin/python"):
            p = comfy_dir / rel
            if p.is_file():
                return str(p)
    found = shutil.which("python3") or shutil.which("python")
    if found:
        return found
    raise FileNotFoundError("No Python interpreter found for ComfyUI pip install")


def _git_short(comfy_dir: Path) -> str:
    try:
        out = subprocess.run(
            ["git", "-C", str(comfy_dir), "rev-parse", "--short", "HEAD"],
            check=True,
            capture_output=True,
            text=True,
        )
        return out.stdout.strip() or "unknown"
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "unknown"


def _prepare_models_symlink(comfy_dir: Path) -> str | None:
    """Drop models symlink so git pull can fast-forward (restore after)."""
    models = comfy_dir / "models"
    if models.is_symlink():
        target = os.readlink(models)
        models.unlink()
        return target
    return None


def _restore_models_symlink(comfy_dir: Path, target: str | None) -> None:
    if not target:
        return
    models = comfy_dir / "models"
    if models.exists() or models.is_symlink():
        if models.is_symlink() or models.is_file():
            models.unlink()
        elif models.is_dir():
            shutil.rmtree(models)
    models.symlink_to(target)


def pull_comfyui_master(comfy_dir: Path, python: str) -> tuple[str, str]:
    """Fetch + ff-only pull origin/master and install requirements.txt."""
    before = _git_short(comfy_dir)
    models_target = _prepare_models_symlink(comfy_dir)
    git_timeout = int(os.environ.get("LOBO_COMFY_GIT_TIMEOUT", "120"))
    try:
        subprocess.run(
            ["git", "-C", str(comfy_dir), "fetch", "origin", "master"],
            check=True,
            capture_output=True,
            text=True,
            timeout=git_timeout,
        )
        subprocess.run(
            ["git", "-C", str(comfy_dir), "pull", "--ff-only", "origin", "master"],
            check=True,
            capture_output=True,
            text=True,
            timeout=git_timeout,
        )
    finally:
        _restore_models_symlink(comfy_dir, models_target)

    req = comfy_dir / "requirements.txt"
    if req.is_file():
        subprocess.run(
            [python, "-m", "pip", "install", "-q", "-r", str(req)],
            check=False,
            capture_output=True,
            text=True,
        )

    after = _git_short(comfy_dir)
    return before, after


def restart_comfyui(comfy_dir: Path, *, port: int = DEFAULT_COMFY_PORT) -> None:
    """Bypass supervisord — run ComfyUI in tmux on loopback (matches provision_gpu.sh)."""
    subprocess.run(["supervisorctl", "stop", "comfyui"], check=False, capture_output=True)
    subprocess.run(["tmux", "kill-session", "-t", "comfyui"], check=False, capture_output=True)
    subprocess.run(["pkill", "-f", "python main.py"], check=False, capture_output=True)
    time.sleep(2)

    venv = ""
    if os.path.isfile("/venv/main/bin/activate"):
        venv = ". /venv/main/bin/activate && "

    cmd = (
        f"cd '{comfy_dir}' && {venv}"
        f"LD_PRELOAD=libtcmalloc_minimal.so.4 python main.py "
        f"--disable-auto-launch --port {port} --listen 127.0.0.1 --enable-cors-header "
        f"2>&1 | tee /tmp/comfyui.log"
    )
    subprocess.run(["tmux", "new-session", "-d", "-s", "comfyui", cmd], check=False)


def wait_for_comfyui(comfy_http: str, *, timeout_sec: int = 180, poll_sec: int = 5) -> bool:
    deadline = time.time() + timeout_sec
    while time.time() < deadline:
        if comfyui_is_up(comfy_http):
            return True
        time.sleep(poll_sec)
    return False


def ensure_lens_support(
    args: Any | None = None,
    *,
    mode: str | None = None,
    comfy_dir: Path | str | None = None,
    comfy_http: str | None = None,
    base_url: str | None = None,
    secret: str | None = None,
    node_uuid: str | None = None,
    instance_id: str | None = None,
    status_fn: Callable[..., None] | None = None,
) -> dict[str, Any]:
    """
    Check ComfyUI for Lens CLIP support; git-pull master if missing.

    Idempotent — no-op when type=lens is already registered or mode skips Lens.
    """
    if os.environ.get("LOBO_SKIP_COMFYUI_UPGRADE", "").strip() == "1":
        return {"ok": True, "skipped": True, "reason": "LOBO_SKIP_COMFYUI_UPGRADE"}

    mode = mode or (getattr(args, "provision_mode", None) if args else None) or os.environ.get("LOBO_MODE", "all")
    if not mode_needs_lens(mode):
        return {"ok": True, "skipped": True, "reason": "mode_does_not_need_lens", "mode": mode}

    comfy_http = (
        comfy_http
        or (getattr(args, "comfyui_http", None) if args else None)
        or os.environ.get("LOBO_COMFYUI_HTTP")
        or DEFAULT_COMFY_HTTP
    )

    if clip_loader_supports_lens(comfy_http):
        log.info("Lens CLIP already supported — skipping ComfyUI git upgrade")
        return {"ok": True, "skipped": True, "reason": "lens_already_supported", "comfy_http": comfy_http}

    resolved = find_comfy_dir(
        str(comfy_dir) if comfy_dir else getattr(args, "comfyui_dir", None) if args else None,
        args,
    )
    if resolved is None:
        return {"ok": False, "error": "ComfyUI install directory not found"}

    if not (resolved / ".git").is_dir():
        return {
            "ok": False,
            "error": "ComfyUI is not a git checkout — cannot pull Lens support",
            "comfy_dir": str(resolved),
        }

    def _status(step: str, level: str, detail: str, pct: int = 0) -> None:
        if status_fn:
            status_fn(step, level, detail, pct=pct)
            return
        post_status(
            step,
            level,
            detail,
            base_url=base_url or _http_base(args),
            secret=secret or (getattr(args, "secret", None) if args else None),
            node_uuid=node_uuid or (getattr(args, "node_uuid", None) if args else None),
            instance_id=instance_id,
            pct=pct,
        )

    _status("comfyui.upgrade", "ok", f"pulling master for Lens ({_git_short(resolved)})")

    try:
        python = resolve_comfy_python(resolved)
        before, after = pull_comfyui_master(resolved, python)
    except subprocess.CalledProcessError as ex:
        err = (ex.stderr or ex.stdout or str(ex)).strip()[:400]
        _status("comfyui.upgrade", "error", err)
        return {"ok": False, "error": f"git pull failed: {err}", "comfy_dir": str(resolved)}

    _status("comfyui.upgrade", "ok", f"{before}->{after}")
    restart_comfyui(resolved)

    if not wait_for_comfyui(comfy_http):
        _status("comfyui.upgrade", "warn", "ComfyUI slow to restart after upgrade")
        return {
            "ok": False,
            "error": "ComfyUI did not respond after upgrade",
            "before": before,
            "after": after,
        }

    if not clip_loader_supports_lens(comfy_http):
        _status("comfyui.upgrade", "error", "Lens CLIP type still missing after pull")
        return {
            "ok": False,
            "error": "Lens CLIP type still missing after ComfyUI upgrade",
            "before": before,
            "after": after,
        }

    _status("comfyui.upgrade", "ok", f"Lens ready ({before}->{after})")
    return {"ok": True, "upgraded": True, "before": before, "after": after, "comfy_dir": str(resolved)}


def _http_base(args: Any | None) -> str | None:
    if args is None:
        return None
    server = getattr(args, "server", None)
    if not server:
        return None
    if str(server).startswith("ws"):
        return "https://" + str(server).split("://", 1)[1]
    return str(server).replace("wss://", "https://").replace("ws://", "http://")
