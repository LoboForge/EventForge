"""Provision dedicated Ollama inference boxes — Dolphin 3.0 + forge-queue SQS agent."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..bootstrap import install_agent_deps, refresh_from_server
from .gpu_compat import derive_agent_hostname
from .status import post_status

log = logging.getLogger("worker.provision.ollama_native")

PROVISION_MODE = "ollama"
DEFAULT_MODEL = "dolphin3:8b"
DEFAULT_NUM_CTX = 65536
TMUX_OLLAMA = "loboforge-ollama-serve"
TMUX_AGENT = "loboforge-ollama-agent"
AGENT_LOG = Path("/workspace/loboforge-ollama-agent.log")


@dataclass
class OllamaNativeProvisionArgs:
    secret: str
    server: str = "wss://www.loboforge.com"
    base_url: str = "https://www.loboforge.com"
    instance_id: str = ""
    label: str = "loboforge-ollama"
    ollama_model: str = DEFAULT_MODEL
    num_ctx: int = DEFAULT_NUM_CTX
    agent_dir: str = "/workspace"


def _apply_ollama_env(args: OllamaNativeProvisionArgs) -> None:
    os.environ.setdefault("MODE", PROVISION_MODE)
    os.environ.setdefault("LOBO_MODE", PROVISION_MODE)
    os.environ.setdefault("LOBO_WAN", "0")
    os.environ.setdefault("LOBO_LTX23", "0")
    os.environ.setdefault("LOBO_MUSIC", "0")
    os.environ.setdefault("LOBO_OLLAMA_MODEL", args.ollama_model)
    os.environ.setdefault("LOBO_OLLAMA_NUM_CTX", str(args.num_ctx))
    os.environ.setdefault("OLLAMA_MAX_LOADED_MODELS", "1")
    os.environ.setdefault("OLLAMA_NUM_PARALLEL", "1")


def write_ollama_env(args: OllamaNativeProvisionArgs, *, hostname: str) -> None:
    env_path = Path(args.agent_dir) / ".loboforge-env"
    exports = {
        "LOBO_MODE": PROVISION_MODE,
        "MODE": PROVISION_MODE,
        "LOBO_SECRET": args.secret,
        "LOBO_SERVER": args.server,
        "LOBO_BASE_URL": args.base_url,
        "LOBO_LABEL": args.label or "loboforge-ollama",
        "LOBO_HOSTNAME": hostname,
        "LOBO_OLLAMA_MODEL": args.ollama_model,
        "LOBO_OLLAMA_NUM_CTX": str(args.num_ctx),
        "LOBOFORGE_AGENT_SECRET": args.secret,
        "FORGE_QUEUE_CAPABILITY": "dolphin",
        "FORGE_QUEUE_REGION": os.environ.get("FORGE_QUEUE_REGION", os.environ.get("AWS_REGION", "us-east-2")),
        "FORGE_QUEUE_BUCKET": os.environ.get("FORGE_QUEUE_BUCKET", ""),
        "FORGE_QUEUE_PREFIX": os.environ.get("FORGE_QUEUE_PREFIX", "fq"),
    }
    for key in ("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "FORGE_QUEUE_ACCESS_KEY", "FORGE_QUEUE_SECRET_KEY"):
        if os.environ.get(key):
            exports[key] = os.environ[key]
    lines = [f'export {k}="{v}"' for k, v in exports.items() if v is not None]
    try:
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as ex:
        log.warning("Could not write %s: %s", env_path, ex)


def resolve_python() -> str:
    for cand in ("/venv/main/bin/python3", shutil.which("python3"), sys.executable):
        if cand and Path(cand).is_file():
            return cand
    return sys.executable


def ensure_tmux() -> None:
    if shutil.which("tmux"):
        return
    subprocess.run(["apt-get", "update", "-qq"], check=False, capture_output=True)
    subprocess.run(["apt-get", "install", "-y", "-qq", "tmux", "curl"], check=False, capture_output=True)


def install_ollama() -> dict[str, Any]:
    if shutil.which("ollama"):
        return {"ok": True, "installed": False}
    log.info("Installing Ollama via install.sh")
    r = subprocess.run(
        ["bash", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if r.returncode != 0:
        return {"ok": False, "error": (r.stderr or r.stdout or "ollama install failed")[:400]}
    if not shutil.which("ollama"):
        return {"ok": False, "error": "ollama binary missing after install"}
    return {"ok": True, "installed": True}


def launch_ollama_serve_tmux() -> dict[str, Any]:
    ensure_tmux()
    subprocess.run(["tmux", "kill-session", "-t", TMUX_OLLAMA], capture_output=True, check=False)
    loop = (
        'while true; do '
        'echo "[$(date -Is)] starting ollama serve..." | tee -a /workspace/ollama-serve.log; '
        "ollama serve 2>&1 | tee -a /workspace/ollama-serve.log; "
        'echo "[$(date -Is)] ollama serve exited, restart in 5s" | tee -a /workspace/ollama-serve.log; '
        "sleep 5; done"
    )
    r = subprocess.run(["tmux", "new-session", "-d", "-s", TMUX_OLLAMA, loop], capture_output=True, text=True)
    if r.returncode != 0:
        return {"ok": False, "error": r.stderr or "tmux ollama serve failed"}
    return {"ok": True, "session": TMUX_OLLAMA}


async def wait_for_ollama(timeout_s: int = 90) -> bool:
    import aiohttp

    host = os.environ.get("OLLAMA_HOST", "127.0.0.1:11434").strip()
    if host.startswith("http://") or host.startswith("https://"):
        base = host.rstrip("/")
    else:
        base = f"http://{host}"
    url = f"{base}/api/tags"
    for _ in range(timeout_s):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=3)) as resp:
                    if resp.ok:
                        return True
        except Exception:
            pass
        await asyncio.sleep(1)
    return False


def pull_ollama_model(model: str) -> dict[str, Any]:
    log.info("Pulling Ollama model %s (may take several minutes)...", model)
    r = subprocess.run(
        ["ollama", "pull", model],
        capture_output=True,
        text=True,
        timeout=3600,
    )
    if r.returncode != 0:
        return {"ok": False, "error": (r.stderr or r.stdout or "pull failed")[:500]}
    return {"ok": True}


def _aws_creds_present() -> bool:
    return bool(
        (os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY"))
        or (os.environ.get("FORGE_QUEUE_ACCESS_KEY") and os.environ.get("FORGE_QUEUE_SECRET_KEY"))
    )


def _install_forge_queue_sdk(py: str) -> None:
    sdk_dir = Path(os.environ.get("FORGE_QUEUE_SDK_DIR", "/workspace/forge-queue/sdk"))
    if not sdk_dir.joinpath("pyproject.toml").is_file():
        base = os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com").rstrip("/")
        tar = Path("/tmp/forge-queue-sdk.tar.gz")
        r = subprocess.run(
            ["curl", "-fsSL", "-A", "LoboForge-Worker/1.1", f"{base}/agent/forge-queue-sdk.tar.gz", "-o", str(tar)],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if r.returncode == 0 and tar.is_file():
            subprocess.run(["tar", "-xzf", str(tar), "-C", "/workspace"], check=False)
            tar.unlink(missing_ok=True)
    if sdk_dir.joinpath("pyproject.toml").is_file():
        subprocess.run([py, "-m", "pip", "install", "-q", "-U", "-e", str(sdk_dir)], check=False)


def fetch_ollama_agent_script(agent_dir: Path, base_url: str) -> dict[str, Any]:
    agent_dir.mkdir(parents=True, exist_ok=True)
    dest = agent_dir / "loboforge_ollama_agent_sqs.py"
    url = f"{base_url.rstrip('/')}/agent/loboforge_ollama_agent_sqs.py"
    loop_url = f"{base_url.rstrip('/')}/agent/vast-ollama-sqs-agent-loop.sh"
    loop_dest = agent_dir / "vast-ollama-sqs-agent-loop.sh"
    r = subprocess.run(
        ["curl", "-fsSL", "-A", "LoboForge-Worker/1.1", url, "-o", str(dest)],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if r.returncode != 0 or not dest.is_file():
        return {"ok": False, "error": f"Could not fetch loboforge_ollama_agent_sqs.py from {url}"}
    dest.chmod(dest.stat().st_mode | 0o111)
    subprocess.run(
        ["curl", "-fsSL", "-A", "LoboForge-Worker/1.1", loop_url, "-o", str(loop_dest)],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if loop_dest.is_file():
        loop_dest.chmod(loop_dest.stat().st_mode | 0o111)
    return {"ok": True, "path": str(dest)}


def launch_ollama_agent_tmux(args: OllamaNativeProvisionArgs, *, hostname: str, node_uuid: str) -> dict[str, Any]:
    ensure_tmux()
    py = resolve_python()
    agent_dir = Path(args.agent_dir).resolve()
    loop_script = agent_dir / "vast-ollama-sqs-agent-loop.sh"
    agent_script = agent_dir / "loboforge_ollama_agent_sqs.py"
    if not agent_script.is_file():
        return {"ok": False, "error": f"Missing {agent_script}"}
    if not _aws_creds_present():
        return {"ok": False, "error": "AWS IAM creds missing (ForgeQueueWorker policy)"}
    _install_forge_queue_sdk(py)
    subprocess.run([py, "-m", "pip", "install", "-q", "-U", "aiohttp", "boto3"], check=False)

    subprocess.run(["tmux", "kill-session", "-t", TMUX_AGENT], capture_output=True, check=False)

    env_file = agent_dir / ".loboforge-env"
    source_env = f'[[ -f "{env_file}" ]] && . "{env_file}"; '
    refresh = (
        f'curl -fsSL -A "LoboForge-Worker/1.1" "{args.base_url.rstrip("/")}/agent/loboforge_ollama_agent_sqs.py" '
        f'-o "{agent_script}" 2>/dev/null || true; '
        f'curl -fsSL -A "LoboForge-Worker/1.1" "{args.base_url.rstrip("/")}/agent/vast-ollama-sqs-agent-loop.sh" '
        f'-o "{loop_script}" 2>/dev/null || true; '
    )
    if loop_script.is_file():
        agent_cmd = f'bash "{loop_script}"'
    else:
        merged_roleplay = agent_dir / "models" / "dolphin-roleplay-merged"
        ollama_url = (
            "http://127.0.0.1:11435"
            if merged_roleplay.is_dir() and "roleplay" in args.ollama_model.lower()
            else "http://127.0.0.1:11434"
        )
        cmd_parts = [
            py,
            str(agent_script),
            "--secret",
            args.secret,
            "--hostname",
            hostname,
            "--node-uuid",
            node_uuid,
            "--preferred-model",
            args.ollama_model,
            "--ollama-url",
            ollama_url,
        ]
        agent_cmd = " ".join(_shell_quote(p) for p in cmd_parts)
    loop = (
        f"{source_env}{refresh}"
        f'while true; do '
        f'echo "[$(date -Is)] starting ollama SQS agent..." | tee -a "{AGENT_LOG}"; '
        f"{agent_cmd} 2>&1 | tee -a \"{AGENT_LOG}\"; "
        f'echo "[$(date -Is)] agent exited, restart in 5s" | tee -a "{AGENT_LOG}"; '
        f"sleep 5; done"
    )
    r = subprocess.run(["tmux", "new-session", "-d", "-s", TMUX_AGENT, loop], capture_output=True, text=True)
    if r.returncode != 0:
        return {"ok": False, "error": r.stderr or "tmux agent failed"}
    return {"ok": True, "session": TMUX_AGENT, "log": str(AGENT_LOG)}


def _shell_quote(value: str) -> str:
    if not value:
        return '""'
    if all(c.isalnum() or c in "/._-:" for c in value):
        return value
    return '"' + value.replace('"', '\\"') + '"'


async def provision_ollama_box(
    args: OllamaNativeProvisionArgs,
    *,
    skip_agent_launch: bool = False,
) -> dict[str, Any]:
    base = args.base_url.rstrip("/")
    node_uuid = args.instance_id or os.environ.get("LOBO_INSTANCE_ID") or str(uuid.uuid4())
    hn = derive_agent_hostname(mode=PROVISION_MODE, label=args.label, instance_id=args.instance_id or None)

    _apply_ollama_env(args)
    write_ollama_env(args, hostname=hn)

    post_status(
        "provision.start",
        "ok",
        f"mode={PROVISION_MODE} model={args.ollama_model} hostname={hn}",
        base_url=base,
        secret=args.secret,
        node_uuid=node_uuid,
    )

    py = resolve_python()
    install_agent_deps(py)
    refresh = refresh_from_server(Path(args.agent_dir), base_url=base, force_worker=True)
    if refresh.get("error"):
        log.warning("Worker refresh: %s", refresh.get("error"))

    inst = await asyncio.to_thread(install_ollama)
    if not inst.get("ok"):
        post_status("ollama.install", "error", inst.get("error", ""), base_url=base, secret=args.secret, node_uuid=node_uuid)
        return inst

    if await wait_for_ollama(timeout_s=15):
        log.info("Ollama already serving — skipping tmux serve launch")
    else:
        serve = await asyncio.to_thread(launch_ollama_serve_tmux)
        if not serve.get("ok"):
            post_status("ollama.serve", "error", serve.get("error", ""), base_url=base, secret=args.secret, node_uuid=node_uuid)
            return serve

        if not await wait_for_ollama():
            err = "Ollama did not respond within timeout"
            post_status("ollama.wait", "error", err, base_url=base, secret=args.secret, node_uuid=node_uuid)
            return {"ok": False, "error": err}

    post_status("ollama.pull", "ok", f"pulling {args.ollama_model}", base_url=base, secret=args.secret, node_uuid=node_uuid, pct=40)
    pull = await asyncio.to_thread(pull_ollama_model, args.ollama_model)
    if not pull.get("ok"):
        post_status("ollama.pull", "error", pull.get("error", ""), base_url=base, secret=args.secret, node_uuid=node_uuid)
        return pull

    agent_fetch = await asyncio.to_thread(fetch_ollama_agent_script, Path(args.agent_dir), base)
    if not agent_fetch.get("ok"):
        post_status("ollama.agent", "error", agent_fetch.get("error", ""), base_url=base, secret=args.secret, node_uuid=node_uuid)
        return agent_fetch

    if skip_agent_launch:
        post_status("provision.complete", "ok", "Ollama ready (agent launch skipped)", base_url=base, secret=args.secret, node_uuid=node_uuid, pct=100)
        return {"ok": True, "hostname": hn, "model": args.ollama_model}

    launch = await asyncio.to_thread(launch_ollama_agent_tmux, args, hostname=hn, node_uuid=node_uuid)
    if not launch.get("ok"):
        post_status("ollama.agent", "error", launch.get("error", ""), base_url=base, secret=args.secret, node_uuid=node_uuid)
        return launch

    post_status(
        "provision.complete",
        "ok",
        f"Ollama agent live model={args.ollama_model} ctx={args.num_ctx}",
        base_url=base,
        secret=args.secret,
        node_uuid=node_uuid,
        pct=100,
    )
    return {"ok": True, "hostname": hn, "model": args.ollama_model, "node_uuid": node_uuid, "agent_log": str(AGENT_LOG)}


def run_provision_ollama_native_cli(argv: list[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(description="Provision Ollama + Dolphin box (forge-queue SQS)")
    p.add_argument("--secret", default=os.environ.get("LOBO_SECRET", ""))
    p.add_argument("--server", default=os.environ.get("LOBO_SERVER", "wss://www.loboforge.com"))
    p.add_argument("--base-url", default=os.environ.get("LOBO_BASE_URL", "https://www.loboforge.com"))
    p.add_argument("--instance-id", default=os.environ.get("LOBO_INSTANCE_ID", os.environ.get("CONTAINER_ID", "")))
    p.add_argument("--label", default=os.environ.get("LOBO_LABEL", "loboforge-ollama"))
    p.add_argument("--model", default=os.environ.get("LOBO_OLLAMA_MODEL", DEFAULT_MODEL))
    p.add_argument("--num-ctx", type=int, default=int(os.environ.get("LOBO_OLLAMA_NUM_CTX", str(DEFAULT_NUM_CTX))))
    p.add_argument("--agent-dir", default="/workspace")
    p.add_argument("--skip-agent-launch", action="store_true")
    if argv is None:
        argv = sys.argv[1:]
        if argv and argv[0] == "provision-ollama-native":
            argv = argv[1:]
    ns = p.parse_args(argv)
    if not ns.secret:
        print("ERROR: --secret or LOBO_SECRET required", file=sys.stderr)
        return 1

    args = OllamaNativeProvisionArgs(
        secret=ns.secret,
        server=ns.server,
        base_url=ns.base_url,
        instance_id=ns.instance_id,
        label=ns.label,
        ollama_model=ns.model,
        num_ctx=max(4096, ns.num_ctx),
        agent_dir=ns.agent_dir,
    )
    result = asyncio.run(provision_ollama_box(args, skip_agent_launch=ns.skip_agent_launch))
    if not result.get("ok"):
        print("FAILED:", result.get("error"), file=sys.stderr)
        return 1
    print("OK hostname=", result.get("hostname"), "model=", result.get("model"))
    return 0
