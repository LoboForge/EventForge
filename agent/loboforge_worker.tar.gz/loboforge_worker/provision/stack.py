"""ComfyUI + custom nodes preflight — mirrors provision_gpu.sh before model downloads."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from .comfyui import ensure_lens_support
from .custom_nodes import ensure_power_lora_loader, install_rgthree_for_args
from .disk import mode_flags
from .gpu_compat import resolve_comfy_python
from .status import post_status

log = logging.getLogger("worker.provision.stack")


async def ensure_comfy_stack_ready(
    args: Any,
    *,
    mode: str,
    base_url: str,
    secret: str,
    node_uuid: str | None = None,
) -> dict[str, Any]:
    """
    Order matches provision_gpu.sh:
      Comfy serving → rgthree clone → Lens git pull → Power Lora Loader → ACE index (music).
    Never blocks pool join — callers log warnings and continue.
    """
    from loboforge_agent import comfyui_is_healthy, ensure_comfyui_running  # type: ignore

    steps: dict[str, Any] = {}

    if not await ensure_comfyui_running(args):
        steps["comfy.start"] = "failed"
        log.warning("ComfyUI not running — stack preflight continues")
    else:
        steps["comfy.start"] = "ok"

    rg = await asyncio.to_thread(
        install_rgthree_for_args, args, python=resolve_comfy_python()
    )
    steps["nodes.rgthree"] = rg
    if not rg.get("ok"):
        log.warning("rgthree install failed: %s", rg.get("error"))

    lens_result = await asyncio.to_thread(ensure_lens_support, args, mode=mode)
    steps["comfyui.upgrade"] = lens_result
    if not lens_result.get("ok"):
        msg = lens_result.get("error") or "ComfyUI Lens upgrade failed"
        log.warning("ComfyUI upgrade failed (non-fatal): %s", msg)
        post_status(
            "comfyui.upgrade", "warn", msg,
            base_url=base_url, secret=secret, node_uuid=node_uuid,
        )

    plora = await ensure_power_lora_loader(args)
    steps["power_lora"] = plora
    if not plora.get("ok"):
        log.warning("Power Lora Loader not registered: %s", plora.get("error"))

    comfy_healthy = await comfyui_is_healthy(getattr(args, "comfyui_http", "http://127.0.0.1:18188"))
    steps["comfy.healthy"] = comfy_healthy
    # Never block model downloads on Power Lora — missing node fails wan jobs at runtime,
    # but blocking here has repeatedly left boxes at ~0GB models forever.
    return {"ok": bool(comfy_healthy), "steps": steps}
