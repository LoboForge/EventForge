"""HTTP helpers for worker/agent scripts.

Cloudflare (and some CDNs) return 403 to Python urllib's default empty User-Agent.
Always send a stable agent UA on outbound fetches to LoboForge + cdn.loboforge.com.
"""

from __future__ import annotations

import urllib.request

USER_AGENT = "LoboForge-Worker/1.1"


def urlopen(
    url: str,
    *,
    timeout: float = 120,
    method: str = "GET",
    data: bytes | None = None,
    headers: dict[str, str] | None = None,
):
    hdrs = {"User-Agent": USER_AGENT}
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers=hdrs,
    )
    return urllib.request.urlopen(req, timeout=timeout)
