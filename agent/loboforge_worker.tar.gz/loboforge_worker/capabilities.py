"""Agent capability flags reported to LoboForge.Api on hello / models_update."""

from __future__ import annotations

import os


def _env_flag(name: str, default: bool) -> bool:
    raw = (os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    return raw not in ("0", "false", "no", "off")


def forge_queue_capabilities_for_mode(mode: str | None = None) -> tuple[str, ...]:
    """Keep in sync with GenQueueCapabilities.cs and loboforge_agent_sqs.capabilities_for_mode."""
    mode_l = (mode or os.environ.get("LOBO_MODE") or os.environ.get("MODE") or "all").strip().lower()
    if "," in mode_l:
        mode_l = mode_l.split(",")[0].strip()
    if mode_l == "both":
        mode_l = "all"

    wan = _env_flag("LOBO_WAN", mode_l not in ("image", "music"))
    ltx23 = _env_flag("LOBO_LTX23", mode_l in ("all", "ltx-native", "ltx"))
    music = _env_flag("LOBO_MUSIC", mode_l not in ("image",))

    if mode_l == "image":
        return ("flux-klein", "flux-klein-edit", "zimage", "chroma")
    if mode_l == "video":
        caps: list[str] = []
        if wan:
            caps.append("wan")
        if ltx23 or music:
            caps.append("ltx")
        return tuple(caps or ("wan",))
    if mode_l == "music":
        return ("ltx",)
    if mode_l == "all":
        caps = ["flux-klein", "flux-klein-edit", "zimage", "chroma"]
        if wan:
            caps.append("wan")
        if ltx23 or music:
            caps.append("ltx")
        return tuple(caps)
    if mode_l in ("ltx-native", "ltx"):
        return ("ltx",)
    if mode_l == "wan-native":
        return ("wan",)
    if mode_l == "dolphin":
        return ("dolphin",)
    return ("flux-klein",)


def native_executor_caps() -> dict[str, object]:
    from .executor_mode import is_native_wan_hostname

    mode = (os.environ.get("LOBO_MODE") or os.environ.get("MODE") or "").strip().lower()
    if mode == "wan-native" or is_native_wan_hostname():
        from .inference.wan.paths import i2v_ready, missing_artifacts, wan_model_root

        root = wan_model_root()
        return {
            "executor": "native",
            "native_wan_ready": not missing_artifacts(root),
            "native_wan_i2v": i2v_ready(root),
            "native_wan_precision": "fp16",
        }
    from .inference.ltx.paths import missing_artifacts, native_ltx_fp8_kernels_supported, resolve_native_checkpoint

    _, _, precision = resolve_native_checkpoint()
    return {
        "executor": "native",
        "native_ltx_ready": not missing_artifacts(),
        "native_ltx_fp8": native_ltx_fp8_kernels_supported(),
        "native_ltx_precision": precision,
    }
