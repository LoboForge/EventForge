"""Find ComfyUI install + models root (vast.ai boxes and local dev)."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

COMFY_CANDIDATES = (
    lambda: os.environ.get("COMFYUI_DIR"),
    lambda: os.environ.get("COMFY_DIR"),
    "/opt/workspace-internal/ComfyUI",
    "/opt/workspace-internal/comfyui",
    "/workspace/comfyui",
    "/workspace/ComfyUI",
    "/opt/ComfyUI",
    "/ComfyUI",
    "/comfyui",
    "/root/comfyui",
    "/root/ComfyUI",
    os.path.expanduser("~/comfyui"),
    os.path.expanduser("~/ComfyUI"),
)

MODELS_CANDIDATES = (
    lambda: os.environ.get("MODELS"),
    "/opt/workspace-internal/ComfyUI/models",
    "/workspace/comfyui/models",
    "/workspace/ComfyUI/models",
    "/root/comfyui/models",
    "/root/ComfyUI/models",
    os.path.expanduser("~/comfyui/models"),
    os.path.expanduser("~/ComfyUI/models"),
)


def _is_comfy_root(p: Path) -> bool:
    try:
        return (p / "main.py").is_file() or (p / "models").is_dir()
    except OSError:
        return False


def resolve_vast_comfy_dir(explicit: str | None = None, args: Any | None = None) -> Path | None:
    """Prefer the supervisord Comfy tree on vast.ai images over /workspace stubs."""
    internal = Path("/opt/workspace-internal/ComfyUI")
    if internal.is_dir() and _is_comfy_root(internal):
        return internal
    return find_comfy_dir(explicit, args)


def find_comfy_dir(explicit: str | None = None, args: Any | None = None) -> Path | None:
    """ComfyUI install directory (contains main.py and/or models/)."""
    if args is not None:
        explicit = explicit or getattr(args, "comfyui_dir", None) or None
        models = getattr(args, "comfyui_models", None) or None
        if models:
            mp = Path(models)
            if mp.is_dir():
                if mp.name == "models":
                    return mp.parent
                # Some callers pass the install root by mistake.
                if _is_comfy_root(mp):
                    return mp

    if explicit:
        p = Path(explicit)
        if _is_comfy_root(p):
            return p

    models_env = os.environ.get("MODELS")
    if models_env:
        mp = Path(models_env)
        if mp.is_dir():
            return mp.parent if mp.name == "models" else mp

    for cand in COMFY_CANDIDATES:
        raw = cand() if callable(cand) else cand
        if not raw:
            continue
        p = Path(raw)
        if _is_comfy_root(p):
            return p

    cwd_models = Path.cwd() / "models"
    if cwd_models.is_dir():
        return Path.cwd()

    return None


def find_models_root(args: Any | None = None) -> Path | None:
    """ComfyUI models/ directory for downloads and LoRA sync."""
    if args is not None:
        explicit = getattr(args, "comfyui_models", None) or None
        if explicit:
            p = Path(explicit)
            if p.is_dir():
                return p

    comfy = find_comfy_dir(getattr(args, "comfyui_dir", None) if args else None, args)
    if comfy:
        root = comfy / "models"
        if root.is_dir():
            return root

    for cand in MODELS_CANDIDATES:
        raw = cand() if callable(cand) else cand
        if not raw:
            continue
        p = Path(raw)
        if p.is_dir():
            return p

    return None


def resolve_comfy_paths(args: Any | None = None) -> tuple[Path | None, Path | None]:
    """Return (comfy_install_dir, models_root)."""
    models = find_models_root(args)
    comfy = find_comfy_dir(getattr(args, "comfyui_dir", None) if args else None, args)
    if comfy is None and models is not None and models.name == "models":
        comfy = models.parent
    return comfy, models


def models_dir(comfy_dir: Path | None = None, explicit: str | None = None, args: Any | None = None) -> Path:
    if args is not None:
        root = find_models_root(args)
        if root:
            return root
    if comfy_dir:
        return comfy_dir / "models"
    found = find_comfy_dir(explicit, args)
    if not found:
        raise FileNotFoundError("ComfyUI models directory not found")
    return found / "models"
