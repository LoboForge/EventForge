"""Built-in worker commands."""

from __future__ import annotations

import asyncio
import logging
import shutil
import subprocess

from ..paths import find_comfy_dir

log = logging.getLogger("worker.commands")
from ..protocol import models_update, worker_event
from .registry import CommandRegistry, WorkerContext


async def cmd_ping(_args: dict, _ctx: WorkerContext) -> dict:
    return {"pong": True}


async def cmd_get_status(_args: dict, ctx: WorkerContext) -> dict:
    from loboforge_agent import get_disk_free_mb, get_gpu_info, get_vram_free  # type: ignore

    gpu = get_gpu_info()
    prov = ctx.provision.status_dict() if ctx.provision else {}
    models = ctx.agent_state.get("models") or {}
    return {
        "hostname": ctx.args.hostname,
        "node_uuid": ctx.args.node_uuid,
        "gpu": gpu,
        "vram_free": get_vram_free(),
        "disk_free_mb": get_disk_free_mb(),
        "busy": ctx.agent_state.get("current_job") is not None,
        "current_job": ctx.agent_state.get("current_job"),
        "known_loras": len(ctx.agent_state.get("known_loras") or []),
        "model_counts": {k: len(v) if isinstance(v, list) else 0 for k, v in models.items()},
        "provision": prov,
        "comfy_dir": str(find_comfy_dir(getattr(ctx.args, "comfyui_dir", None)) or ""),
    }


async def cmd_sync_loras(args: dict, ctx: WorkerContext) -> dict:
    if not ctx.provision:
        raise RuntimeError("Provision runner not initialized")
    mode = args.get("mode") or ctx.provision.state.mode
    include_tools = bool(args.get("include_tools"))
    result = await ctx.provision.sync_loras(mode, include_tools=include_tools)
    if ctx.get_models:
        models = await ctx.get_models()
        ctx.agent_state["models"] = models
        ctx.agent_state["known_loras"] = list(models.get("loras", []))
        await ctx.session.send_json(models_update(models))
    return result


async def cmd_sync_tool_loras(_args: dict, ctx: WorkerContext) -> dict:
    if not ctx.provision:
        raise RuntimeError("Provision runner not initialized")
    result = await ctx.provision.sync_tool_loras()
    if ctx.get_models:
        models = await ctx.get_models()
        ctx.agent_state["models"] = models
        ctx.agent_state["known_loras"] = list(models.get("loras", []))
        await ctx.session.send_json(models_update(models))
    return result


async def cmd_provision_run(args: dict, ctx: WorkerContext) -> dict:
    if not ctx.provision:
        raise RuntimeError("Provision runner not initialized")
    names = args.get("manifests")
    if isinstance(names, str):
        names = [names]
    result = await ctx.provision.run_once(names if names else None)
    if result.get("ok") and ctx.get_models:
        models = await ctx.get_models()
        ctx.agent_state["models"] = models
        await ctx.session.send_json(models_update(models))
    return result


async def cmd_provision_status(_args: dict, ctx: WorkerContext) -> dict:
    if not ctx.provision:
        return {"initialized": False}
    return {"initialized": True, **ctx.provision.status_dict()}


async def cmd_restart_comfy(_args: dict, ctx: WorkerContext) -> dict:
    if ctx.restart_comfy:
        ok = await ctx.restart_comfy()
        return {"restarted": ok}
    comfy = find_comfy_dir(getattr(ctx.args, "comfyui_dir", None))
    if not comfy:
        raise FileNotFoundError("ComfyUI dir not found")
    subprocess.run(["tmux", "kill-session", "-t", "comfyui"], check=False)
    subprocess.run(
        [
            "tmux", "new-session", "-d", "-s", "comfyui",
            f"cd '{comfy}' && . /venv/main/bin/activate && "
            "LD_PRELOAD=libtcmalloc_minimal.so.4 python main.py "
            "--disable-auto-launch --port 18188 --listen 127.0.0.1 --enable-cors-header "
            "2>&1 | tee /tmp/comfyui.log",
        ],
        check=False,
    )
    return {"restarted": True, "method": "tmux"}


async def cmd_disk_cleanup(args: dict, ctx: WorkerContext) -> dict:
    from loboforge_agent import maybe_free_comfy_disk  # type: ignore

    min_mb = int(args.get("min_free_mb", 2048))
    before = shutil.disk_usage("/").free // (1024 * 1024)
    maybe_free_comfy_disk(ctx.args, min_mb)
    after = shutil.disk_usage("/").free // (1024 * 1024)
    return {"disk_free_mb_before": before, "disk_free_mb_after": after}


async def cmd_models_refresh(_args: dict, ctx: WorkerContext) -> dict:
    if not ctx.get_models:
        raise RuntimeError("Model scanner not available")
    models = await ctx.get_models()
    ctx.agent_state["models"] = models
    ctx.agent_state["known_loras"] = list(models.get("loras", []))
    await ctx.session.send_json(models_update(models))
    await ctx.session.send_json(worker_event("models.refreshed", {"counts": {
        k: len(v) if isinstance(v, list) else 0 for k, v in models.items()
    }}))
    return {"ok": True}


async def cmd_comfyui_ensure_lens(args: dict, ctx: WorkerContext) -> dict:
    from ..provision.comfyui import ensure_lens_support

    mode = args.get("mode") or (ctx.provision.state.mode if ctx.provision else None)
    return await asyncio.to_thread(ensure_lens_support, ctx.args, mode=mode)


async def cmd_restart_agent(args: dict, ctx: WorkerContext) -> dict:
    """Restart the agent tmux session after refreshing worker bundle from server."""
    from ..bootstrap import refresh_from_server, http_base

    session = str(args.get("session") or "loboforge-agent")
    agent_dir = str(args.get("agent_dir") or "/workspace")
    base = args.get("base_url") or http_base(getattr(ctx.args, "server", None))
    await asyncio.to_thread(refresh_from_server, agent_dir, base_url=base, force_worker=True)

    async def _delayed_restart() -> None:
        await asyncio.sleep(1.0)
        subprocess.run(["tmux", "kill-session", "-t", session], check=False)

    asyncio.create_task(_delayed_restart())
    return {"restarting": True, "session": session, "worker_refreshed": True}


async def cmd_reprovision(args: dict, ctx: WorkerContext) -> dict:
    """Pull latest worker bundle, upgrade Comfy, then background model sync."""
    from ..provision.artifact_skips import SKIP_CACHE
    from ..provision.runner import PROVISION_DONE

    if not ctx.provision:
        raise RuntimeError("Provision runner not initialized")

    PROVISION_DONE.unlink(missing_ok=True)
    SKIP_CACHE.unlink(missing_ok=True)

    upgrade = await cmd_worker_upgrade({"force_worker": True, **args}, ctx)

    async def _run() -> None:
        ctx.agent_state["provisioning"] = True
        ctx.agent_state["provision_step"] = "starting"
        ctx.agent_state["provision_pct"] = 0
        try:
            await ctx.provision.run_once()
        except Exception as ex:
            log.warning("Background reprovision failed: %s", ex)

    asyncio.create_task(_run())
    return {"ok": True, "reprovision_started": True, "upgrade": upgrade}


async def cmd_worker_upgrade(args: dict, ctx: WorkerContext) -> dict:
    from ..bootstrap import refresh_from_server, verify_hardened

    agent_dir = args.get("agent_dir") or "/workspace"
    force = bool(args.get("force_worker", True))
    base = args.get("base_url")
    if not base:
        from ..bootstrap import http_base
        base = http_base(getattr(ctx.args, "server", None))
    result = refresh_from_server(agent_dir, base_url=base, force_worker=force)
    result["verify"] = verify_hardened(agent_dir)

    if args.get("restart", True):
        session = str(args.get("session") or "loboforge-agent")

        async def _restart_after_upgrade() -> None:
            await asyncio.sleep(2.0)
            subprocess.run(["tmux", "kill-session", "-t", session], check=False)

        asyncio.create_task(_restart_after_upgrade())
        result["restarting"] = True

    return result


def build_registry() -> CommandRegistry:
    reg = CommandRegistry()
    reg.register("ping", cmd_ping)
    reg.register("get_status", cmd_get_status)
    reg.register("sync_loras", cmd_sync_loras)
    reg.register("sync_tool_loras", cmd_sync_tool_loras)
    reg.register("provision.run", cmd_provision_run)
    reg.register("provision.status", cmd_provision_status)
    reg.register("restart_comfy", cmd_restart_comfy)
    reg.register("restart_agent", cmd_restart_agent)
    reg.register("reprovision", cmd_reprovision)
    reg.register("disk.cleanup", cmd_disk_cleanup)
    reg.register("models.refresh", cmd_models_refresh)
    reg.register("comfyui.ensure_lens", cmd_comfyui_ensure_lens)
    reg.register("worker.upgrade", cmd_worker_upgrade)
    reg.register("release_stuck_job", cmd_release_stuck_job)
    return reg


async def cmd_release_stuck_job(_args: dict, ctx: WorkerContext) -> dict:
    """Clear local busy latch — server sends after force requeue."""
    job = ctx.agent_state.get("current_job")
    ctx.agent_state["current_job"] = None
    ctx.agent_state.pop("current_job_since", None)
    ctx.agent_state.pop("job_started", None)
    return {"released": job}

DEFAULT_REGISTRY = build_registry()
