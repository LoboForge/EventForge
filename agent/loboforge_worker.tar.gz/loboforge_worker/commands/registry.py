"""Remote command dispatch from LoboForge server."""

from __future__ import annotations

import logging
from typing import Any, Awaitable, Callable

log = logging.getLogger("worker.commands")

CommandHandler = Callable[[dict, "WorkerContext"], Awaitable[dict]]


class WorkerContext:
    """Shared runtime state passed to command handlers."""

    def __init__(
        self,
        args: Any,
        agent_state: dict,
        session: Any,
        provision: Any | None = None,
        get_models: Callable[[], Awaitable[dict]] | None = None,
        restart_comfy: Callable[[], Awaitable[bool]] | None = None,
    ) -> None:
        self.args = args
        self.agent_state = agent_state
        self.session = session
        self.provision = provision
        self.get_models = get_models
        self.restart_comfy = restart_comfy


class CommandRegistry:
    def __init__(self) -> None:
        self._handlers: dict[str, CommandHandler] = {}

    def register(self, name: str, handler: CommandHandler) -> None:
        self._handlers[name] = handler

    async def dispatch(self, command: str, args: dict, ctx: WorkerContext) -> dict:
        handler = self._handlers.get(command)
        if not handler:
            raise KeyError(f"Unknown command: {command}")
        return await handler(args, ctx)
