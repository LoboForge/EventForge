"""WebSocket message types shared with LoboForge.Api."""

from __future__ import annotations

from typing import Any


def command_result(command_id: str, ok: bool, result: dict | None = None, error: str | None = None) -> dict:
    return {
        "type": "command_result",
        "command_id": command_id,
        "ok": ok,
        "result": result or {},
        "error": error or "",
    }


def worker_event(event: str, payload: dict | None = None) -> dict:
    return {"type": "worker_event", "event": event, "payload": payload or {}}


def models_update(models: dict[str, Any], capabilities: dict[str, Any] | None = None) -> dict:
    msg: dict[str, Any] = {"type": "models_update", "models": models}
    if capabilities:
        msg["capabilities"] = capabilities
    return msg
