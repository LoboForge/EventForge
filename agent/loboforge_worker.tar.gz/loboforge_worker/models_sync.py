"""Refresh Comfy inventory and push models_update to the server."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from .protocol import models_update

log = logging.getLogger("worker.models_sync")


def build_native_ltx_inventory(root: Path | None = None) -> dict[str, list[str]]:
    """Disk-based inventory for native LTX boxes — names must match server dispatch heuristics."""
    from .inference.ltx.paths import load_layout, ltx_model_root, missing_artifacts

    base = root or ltx_model_root()
    if missing_artifacts(base):
        return {}

    layout = load_layout(base)
    if not layout:
        return {}

    def names(path_key: str, subdir: str) -> list[str]:
        raw = layout.get(path_key)
        if not raw:
            return []
        name = Path(str(raw)).name
        return [name, f"{subdir}/{name}"]

    ckpt = names("checkpoint", "checkpoints")
    lora = names("distilled_lora", "loras")
    loras_dir = base / "loras"
    if loras_dir.is_dir():
        for f in sorted(loras_dir.glob("*.safetensors")):
            if f.is_file():
                lora.extend([f.name, f"loras/{f.name}"])
    # dedupe preserving order
    lora = list(dict.fromkeys(lora))
    te = names("gemma", "text_encoders")
    up = names("spatial_upsampler", "latent_upscale_models")
    vaes: list[str] = []
    for key, sub in (("video_vae", "vae"), ("audio_vae", "vae")):
        vaes.extend(names(key, sub))

    return {
        "unets": [],
        "checkpoints": ckpt,
        "loras": lora,
        "vaes": vaes,
        "clips": te,
        "text_encoders": te,
        "latent_upscale_models": up,
        "ggufs": [],
    }


def build_native_wan_inventory(root: Path | None = None) -> dict[str, list[str]]:
    """Disk-based inventory for native Wan boxes."""
    from .inference.wan.paths import (
        I2V_HIGH_INVENTORY,
        I2V_LOW_INVENTORY,
        i2v_ready,
        load_layout,
        missing_artifacts,
        wan_model_root,
    )

    base = root or wan_model_root()
    if missing_artifacts(base) or not i2v_ready(base):
        return {}

    layout = load_layout(base) or {}
    unets = [I2V_HIGH_INVENTORY, I2V_LOW_INVENTORY, f"Wan2.2/{I2V_HIGH_INVENTORY}", f"Wan2.2/{I2V_LOW_INVENTORY}"]
    loras: list[str] = []
    for key in ("lightning_high", "lightning_low"):
        raw = layout.get(key)
        if raw:
            name = Path(str(raw)).name
            loras.extend([name, f"loras/{name}"])
    loras_dir = base / "loras"
    if loras_dir.is_dir():
        for f in sorted(loras_dir.glob("*.safetensors")):
            if f.is_file():
                loras.extend([f.name, f"loras/{f.name}"])
    loras = list(dict.fromkeys(loras))
    return {
        "unets": list(dict.fromkeys(unets)),
        "checkpoints": [],
        "loras": loras,
        "vaes": ["wan_2.1_vae.safetensors"],
        "clips": ["umt5_xxl_fp8_e4m3fn_scaled.safetensors"],
        "text_encoders": ["umt5_xxl_fp8_e4m3fn_scaled.safetensors"],
        "ggufs": [],
    }


async def refresh_and_push(session: Any, args: Any, agent_state: dict) -> dict:
    from loboforge_agent import get_available_models, model_count  # type: ignore

    models = await get_available_models(args.comfyui_http)
    agent_state["models"] = models
    known = agent_state.setdefault("known_loras", [])
    for name in models.get("loras", []):
        if name and name not in known:
            known.append(name)
    import os

    caps = None
    if os.environ.get("LOBO_EXECUTOR", "").strip().lower() == "native":
        from .capabilities import native_executor_caps

        caps = native_executor_caps()
    payload = models_update(models, caps)
    payload["node_uuid"] = getattr(args, "node_uuid", "")
    await session.send_json(payload)
    log.info("Pushed models_update (%d assets, %d loras)", model_count(models), len(models.get("loras", [])))
    return models
