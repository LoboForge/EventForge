"""Load provision manifests (bundled JSON + server override)."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .http_util import urlopen as agent_urlopen
from .provision.disk import mode_flags

log = logging.getLogger("worker.manifest")

DATA_DIR = Path(__file__).resolve().parent / "data"

MODE_MANIFESTS: dict[str, list[str]] = {
    "image": ["image_stack", "music_stack"],
    "video": ["wan_stack", "music_stack"],
    "music": ["music_stack"],
    "all": ["image_stack", "wan_stack", "music_stack", "ltx23_stack"],
    "both": ["image_stack", "wan_stack", "music_stack", "ltx23_stack"],
    "wan-native": ["wan22_native_stack"],
    "ltx-native": ["ltx23_native_stack"],
}


@dataclass
class Artifact:
    dest: str
    min_bytes: int
    hf_repo: str = ""
    hf_include: str = ""
    hf_filename: str = ""
    url: str = ""
    url_env: str = ""
    required: bool = False


@dataclass
class Manifest:
    name: str
    description: str
    artifacts: list[Artifact]


def _parse_manifest(raw: dict[str, Any]) -> Manifest:
    arts: list[Artifact] = []
    for item in raw.get("artifacts", []):
        dest = str(item.get("dest") or "").strip()
        if not dest:
            continue
        raw_hf = item.get("hf")
        hf = raw_hf if isinstance(raw_hf, dict) else {}
        arts.append(
            Artifact(
                dest=dest,
                min_bytes=int(item.get("min_bytes", 1024)),
                hf_repo=str(hf.get("repo") or ""),
                hf_include=str(hf.get("include") or ""),
                hf_filename=str(hf.get("filename") or Path(item["dest"]).name),
                url=str(item.get("url") or ""),
                url_env=str(item.get("url_env") or ""),
                required=bool(item.get("required", False)),
            )
        )
    return Manifest(
        name=raw.get("name", "unknown"),
        description=raw.get("description", ""),
        artifacts=arts,
    )


def load_local(name: str) -> Manifest | None:
    path = DATA_DIR / f"{name}.json"
    if not path.is_file():
        return None
    with path.open(encoding="utf-8") as f:
        return _parse_manifest(json.load(f))


def fetch_server_manifest(base_url: str, mode: str, secret: str) -> list[Manifest]:
    url = f"{base_url.rstrip('/')}/api/agent/provision-manifest?mode={mode}&secret={secret}"
    try:
        with agent_urlopen(url, timeout=60) as resp:
            raw = json.loads(resp.read().decode())
    except Exception as ex:
        log.warning("Could not fetch server manifest: %s", ex)
        return []
    out: list[Manifest] = []
    for block in raw if isinstance(raw, list) else raw.get("manifests", []):
        if isinstance(block, dict):
            out.append(_parse_manifest(block))
    return out


def _env_enabled(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or not str(raw).strip():
        return default
    return str(raw).strip().lower() in ("1", "true", "yes")


def _default_ltx23_for_mode(mode: str) -> bool:
    parts = [p.strip().lower() for p in (mode or "").split(",") if p.strip()]
    return "all" in parts or "both" in parts


def _filter_manifests(manifests: list[Manifest], mode: str) -> list[Manifest]:
    want_image, want_video, want_music = mode_flags(mode)
    out: list[Manifest] = []
    for manifest in manifests:
        name = manifest.name
        if name == "image_stack" and not want_image:
            continue
        if name == "wan_stack" and not _env_enabled("LOBO_WAN", want_video):
            log.info("wan_stack omitted — set LOBO_WAN=1 to download Wan models")
            continue
        if name == "ltx23_stack" and not _env_enabled("LOBO_LTX23", _default_ltx23_for_mode(mode)):
            log.info("ltx23_stack omitted — set LOBO_LTX23=1 (default on for mode=all)")
            continue
        if name == "music_stack" and not _env_enabled("LOBO_MUSIC", want_music):
            log.info("music_stack omitted — set LOBO_MUSIC=1 to download ACE-Step")
            continue
        out.append(manifest)
    return out


def manifests_for_mode(mode: str, base_url: str | None = None, secret: str | None = None) -> list[Manifest]:
    mode = (mode or "all").strip().lower()
    if base_url and secret:
        server = fetch_server_manifest(base_url, mode, secret)
        if server:
            return _filter_manifests(server, mode)
    key = mode if mode in MODE_MANIFESTS else "all"
    names = MODE_MANIFESTS.get(key, MODE_MANIFESTS["all"])
    out: list[Manifest] = []
    for name in names:
        m = load_local(name)
        if m:
            out.append(m)
    return _filter_manifests(out, mode)


def manifest_names_for_mode(mode: str) -> list[str]:
    mode = (mode or "all").strip().lower()
    return list(MODE_MANIFESTS.get(mode, MODE_MANIFESTS["all"]))
